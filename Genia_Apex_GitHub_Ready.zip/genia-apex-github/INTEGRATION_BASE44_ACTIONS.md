# Raccordement Base44 — compléments nécessaires (sans toucher au moteur)

Les fichiers originaux Python et React sont conservés. `geniaApexApi.ts` contient seulement une méthode client supplémentaire `activatePlan()` pour la route déjà présente dans le backend.

## 1. Fonction serveur `genia-apex-token`

Créer dans le projet Base44 une fonction serveur appelée `genia-apex-token` (ce fichier n’est pas livré dans cette archive car le runtime exact du projet doit être vérifié). Elle doit :
- exiger une session Base44 authentifiée ;
- récupérer l'identifiant utilisateur depuis la session vérifiée côté serveur (jamais depuis le corps envoyé par le navigateur) ;
- signer un JWT HS256 avec `GENIA_AUTH_SECRET` ;
- émettre `{sub, iss:"base44", aud:"genia-apex", iat, exp}` avec `exp` à 15 minutes ;
- retourner `{token}`.

Le runtime/API exact de la fonction dépend de la version Base44 et de son SDK disponible dans le projet. Ne pas coller un exemple utilisant une méthode d'authentification non vérifiée. Utiliser le helper officiel de session/utilisateur côté serveur de TON projet Base44. Le secret doit être stocké dans les secrets serveur Base44 et dans Secret Manager/Cloud Run, jamais dans React.

Le composant fourni s'attend à ce contrat côté client :

```ts
const result = await base44.functions.invoke("genia-apex-token", {});
return result.data.token;
```

## 2. Paiements et crédits — flux sûr

Le backend accepte `POST /api/v1/billing/activate-plan` avec :

```json
{
  "plan_id": "plan_20",
  "payment_reference": "REFERENCE_UNIQUE_DU_PRESTATAIRE",
  "payment_proof": "HMAC_HEX"
}
```

La preuve attendue par le backend est exactement :

`HMAC_SHA256(GENIA_AUTH_SECRET, user_id + ":" + plan_id + ":" + payment_reference)`

IMPORTANT : cette preuve doit être créée uniquement côté serveur Base44, après vérification cryptographique du webhook de paiement du prestataire (et vérification montant/devise/statut). Le navigateur ne doit jamais pouvoir appeler directement une fonction qui signe une référence de paiement arbitraire. La fonction serveur doit obtenir `user_id` depuis la session, vérifier le paiement auprès du webhook/registre serveur, calculer le HMAC, puis appeler Cloud Run avec un JWT utilisateur valide et le corps ci-dessus. Utiliser une référence unique et conserver l'idempotence du backend.

Le client TypeScript fourni expose maintenant `activatePlan(...)`, mais l'action d'achat doit appeler une fonction serveur de confirmation, pas fabriquer `payment_proof` dans le navigateur.

## 3. Variables Base44

- `GENIA_AUTH_SECRET` : même valeur aléatoire d'au moins 32 caractères que Cloud Run, secret serveur uniquement.
- `GENIA_APEX_API_URL` ou variable publique de configuration d'URL : URL HTTPS Cloud Run. L'URL n'est pas un secret.

Le composant existant lit `VITE_GENIA_APEX_API_URL` si `apiBaseUrl` n'est pas fourni. Selon le mécanisme de variables Base44, injecter cette URL au build ou passer `apiBaseUrl` depuis la configuration de l'application.

## 4. Variables Cloud Run

Reprendre la liste complète de `CONFIGURATION_GENIA_BASE44_GOOGLE_CLOUD.md`. Obligatoires à valider avant trafic :
- `GCP_PROJECT_ID`, `GCP_LOCATION`, `GCS_BUCKET_NAME` ;
- `GENIA_AUTH_SECRET`, `GENIA_JWT_ISSUER=base44`, `GENIA_JWT_AUDIENCE=genia-apex` ;
- `CORS_ALLOWED_ORIGINS` avec le domaine exact de l'application Base44 ;
- `REQUIRE_CLOUD_STATE=true` ;
- `PUBLIC_BASE_URL`, `CLOUD_TASKS_SERVICE_URL`, `CLOUD_TASKS_QUEUE`, `CLOUD_TASKS_LOCATION`, `CLOUD_TASKS_SERVICE_ACCOUNT`.

Activer les API Google et attribuer les rôles IAM décrits dans le guide de configuration. Ne pas activer `ENABLE_GEMINI_LIVE_AVATAR` sans autorisation Google.

## 5. Docker / Cloud Run

Le Dockerfile fourni installe FFmpeg et FFprobe et lance le module FastAPI original sans le modifier. Construire depuis ce dossier, avec le nom `Genia_Apex_GoogleCloud_Base44.py` présent à côté du Dockerfile.

Exemple :

```bash
gcloud builds submit --tag REGION-docker.pkg.dev/PROJECT_ID/genia/genia-apex:1.0.0

gcloud run deploy genia-apex \
  --image REGION-docker.pkg.dev/PROJECT_ID/genia/genia-apex:1.0.0 \
  --region us-central1 \
  --port 8080 \
  --no-allow-unauthenticated
```

Le service Cloud Run doit être appelé par les utilisateurs avec le JWT Genia de l'application; l'accès réseau Cloud Run doit toutefois permettre le trafic API public authentifié par ce JWT si aucun proxy privé n'est mis en place. `--no-allow-unauthenticated` nécessite un proxy/une passerelle d'identité en amont qui ajoute l'identité Google; ne l'utiliser que si cette architecture est réellement configurée. Pour l'architecture navigateur → FastAPI avec JWT applicatif, le service doit généralement accepter les requêtes HTTP non authentifiées au niveau Cloud Run, tandis que FastAPI valide strictement le JWT applicatif. Dans ce cas, utiliser `--allow-unauthenticated` et garder `verify_api_token` actif sur toutes les routes utilisateur.

## 6. Tests d'acceptation après déploiement

1. `GET /health` retourne `alive`.
2. `genia-apex-token` retourne un JWT de 15 minutes pour un utilisateur connecté.
3. `GET /api/v1/billing/wallet` retourne le portefeuille de cet utilisateur.
4. Les catalogues avatars/voix/templates se chargent.
5. Un rendu de test crée un job, Cloud Tasks le traite, le statut passe à terminé/échec et le média est accessible.
6. Test d'achat en environnement de test : webhook valide → activation une fois → solde crédité une fois ; rejouer le même webhook ne double pas les crédits.
7. Vérifier les journaux Cloud Run, Firestore, GCS et Cloud Tasks.

Ce pack prépare les fichiers et les contrats d'intégration. Il ne peut pas activer les API, créer les secrets, déployer sur le compte Google, modifier le projet Base44 ni vérifier un paiement réel sans accès autorisé à ces comptes. La mise en production à 100 % ne peut être certifiée qu'après ces tests sur les projets réels.
