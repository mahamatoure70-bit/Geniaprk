export type TokenProvider = () => Promise<string>;

export class GeniaApexApi {
  private baseUrl: string;
  private getToken: TokenProvider;

  constructor(baseUrl: string, getToken: TokenProvider) {
    this.baseUrl = (baseUrl || "").trim().replace(/\/+$/, "");
    if (!this.baseUrl) {
      throw new Error("URL du moteur Genia Apex manquante. Configurez VITE_GENIA_APEX_API_URL dans Base44.");
    }
    this.getToken = getToken;
  }

  private async request<T>(path: string, init: RequestInit = {}): Promise<T> {
    const token = await this.getToken();
    if (!token) throw new Error("Session Genia/Base44 introuvable. Reconnectez-vous.");
    const headers = new Headers(init.headers || {});
    headers.set("Authorization", `Bearer ${token}`);
    if (!(init.body instanceof FormData) && init.body !== undefined) {
      headers.set("Content-Type", "application/json");
    }
    const response = await fetch(`${this.baseUrl}${path}`, { ...init, headers });
    const raw = await response.text();
    let data: any = {};
    try { data = raw ? JSON.parse(raw) : {}; } catch { data = { detail: raw }; }
    if (!response.ok) {
      throw new Error(data?.detail || data?.message || `Erreur API ${response.status}`);
    }
    return data as T;
  }

  get<T>(path: string) { return this.request<T>(path); }
  post<T>(path: string, payload: unknown) {
    return this.request<T>(path, { method: "POST", body: JSON.stringify(payload) });
  }
  upload<T>(path: string, form: FormData) {
    return this.request<T>(path, { method: "POST", body: form });
  }

  health() { return this.get<any>("/health"); }
  readiness() { return this.get<any>("/api/v1/system/readiness"); }
  wallet() { return this.get<any>("/api/v1/billing/wallet"); }
  activatePlan(payload: { plan_id: "plan_20" | "plan_40" | "plan_80"; payment_reference: string; payment_proof: string }) {
    return this.post<any>("/api/v1/billing/activate-plan", payload);
  }
  avatars() { return this.get<any>("/api/v1/avatars"); }
  voices() { return this.get<any>("/api/v1/voices"); }
  cameraPresets() { return this.get<any>("/api/v1/camera/presets"); }
  photoModels() { return this.get<any>("/api/v1/photo-models"); }
  filters() { return this.get<any>("/api/v1/filters"); }
  stickers() { return this.get<any>("/api/v1/stickers"); }
  templates() { return this.get<any>("/api/v1/templates?limit=100"); }
  startRender(payload: unknown) { return this.post<any>("/api/v1/render/start", payload); }
  applyTemplate(payload: unknown) { return this.post<any>("/api/v1/templates/apply", payload); }
  applyPhotoModel(payload: unknown) { return this.post<any>("/api/v1/photo-models/apply", payload); }
  cameraUpload(file: File) {
    const form = new FormData(); form.append("file", file);
    return this.upload<any>("/api/v1/camera/upload-recording", form);
  }
  cameraProcess(payload: unknown) { return this.post<any>("/api/v1/camera/record-studio", payload); }
  songPhoto(payload: unknown) { return this.post<any>("/api/v1/song-photo/render", payload); }
  splitVideo(payload: unknown) { return this.post<any>("/api/v1/video/split-scenes", payload); }
  estimateViews(payload: unknown) { return this.post<any>("/api/v1/video/estimate-views", payload); }
  job(jobId: string) { return this.get<any>(`/api/v1/render/status/${encodeURIComponent(jobId)}`); }
  cancel(jobId: string) { return this.post<any>(`/api/v1/render/cancel/${encodeURIComponent(jobId)}`, {}); }
  generateTemplates(count = 3) { return this.post<any>(`/api/v1/templates/generate-daily?count=${count}`, {}); }
  createVoice(source: File, consent: File, displayName: string) {
    const form = new FormData();
    form.append("source_audio", source);
    form.append("consent_audio", consent);
    form.append("display_name", displayName);
    return this.upload<any>("/api/v1/voices/clone", form);
  }
}
