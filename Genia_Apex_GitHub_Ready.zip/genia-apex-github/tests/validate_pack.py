from pathlib import Path
import ast, re, sys
ROOT = Path(__file__).resolve().parents[1]
errors=[]
def check(ok, msg):
    if not ok: errors.append(msg)

# Python syntax for both runtime processes.
for name in ("Genia_Apex_GoogleCloud_Base44.py", "genia_local_worker.py"):
    try: ast.parse((ROOT/name).read_text(encoding="utf-8"), filename=name)
    except SyntaxError as exc: errors.append(f"{name}: {exc}")

# Every internal route called by the API must exist on the local worker.
api=(ROOT/"Genia_Apex_GoogleCloud_Base44.py").read_text(encoding="utf-8")
worker=(ROOT/"genia_local_worker.py").read_text(encoding="utf-8")
called=set(re.findall(r'"(/v1/[a-zA-Z0-9_/{}/.-]+)"', api))
served=set(re.findall(r'@APP\.(?:get|post|put|delete)\("([^"]+)"', worker))
for route in sorted(called-served):
    # Dynamic route strings are not worker routes; only fixed path calls are asserted.
    if "{" not in route: errors.append(f"Worker route missing: {route}")

# Docker COPY sources must exist in the build context.
docker=(ROOT/"Dockerfile").read_text(encoding="utf-8")
for src in re.findall(r'^COPY\s+([^\s]+)\s+', docker, re.M):
    check((ROOT/src).exists(), f"Docker COPY source missing: {src}")

# The UI and integration guide must use the same function slug.
page=(ROOT/"Base44GeniaApexPage.tsx").read_text(encoding="utf-8")
check('functions.invoke("genia-apex-token"' in page, "Base44 page function slug mismatch")
for name in ("README.md", "INTEGRATION_BASE44_ACTIONS.md", "RACCORDEMENT_FINAL_BASE44_GOOGLE_CLOUD.md"):
    doc=(ROOT/name).read_text(encoding="utf-8")
    check("geniaApexToken" not in doc, f"Old camelCase function name remains in {name}")

# Startup and model bootstrap scripts are present and executable in the archive.
for name in ("start_genia_one_service.sh", "bootstrap_models.sh", "deploy_genia_one_service.sh"):
    check((ROOT/name).is_file(), f"Missing shell script: {name}")

if errors:
    print("FAIL")
    for e in errors: print(" -", e)
    sys.exit(1)
print("PASS: Python AST, internal worker route coverage, Docker COPY sources, Base44 function slug, deployment files")


# GCS-backed model cache and deployment defaults.
helper = ROOT / "genia_model_cache.py"
assert helper.is_file()
ast.parse(helper.read_text(encoding="utf-8"))
bootstrap = (ROOT / "bootstrap_models.sh").read_text(encoding="utf-8")
for prefix in ("genia-model-cache/wan2.2-ti2v-5b", "genia-model-cache/openvoice-v2",
               "genia-model-cache/latentsync-1.5", "genia-model-cache/qwen2.5-3b-instruct",
               "genia-model-cache/sdxl-base-1.0", "genia-model-cache/faster-whisper-small",
               "genia-model-cache/kokoro-82m"):
    assert prefix in bootstrap
worker = (ROOT / "genia_local_worker.py").read_text(encoding="utf-8")
for name in ("QWEN_MODEL_PATH", "SDXL_MODEL_PATH", "WHISPER_MODEL_PATH", "KOKORO_MODEL_PATH"):
    assert name in worker
deploy = (ROOT / "deploy_genia_one_service.sh").read_text(encoding="utf-8")
assert 'MODEL_DISK_SIZE="${MODEL_DISK_SIZE:-100Gi}"' in deploy
assert "GENIA_MODEL_CACHE=/opt/genia-models" in deploy
print("PASS: GCS durable model cache, local model paths, and 100Gi deployment default")

for marker in ("qwen.complete", "sdxl.complete", "whisper.complete", "kokoro.complete"):
    assert f"/.bootstrap/{marker}" in bootstrap, f"Bootstrap does not create worker readiness marker: {marker}"
assert 'KModel(repo_id="hexgrad/Kokoro-82M"' in worker
print("PASS: all readiness markers and local Kokoro initialization are wired")

# Production wiring: warm-up retries, scale-to-zero, duration cap and GitHub hygiene.
start_script = (ROOT/"start_genia_one_service.sh").read_text(encoding="utf-8")
assert "bootstrap_models.sh" in start_script and "BOOTSTRAP_PID" in start_script
assert "tentative ${attempt}/3" in bootstrap and "cache_model --repo" in bootstrap
assert 'wait "$API_PID"' in start_script
assert "health/deep" in api and "Cloud Tasks réessaiera" in api
deploy = (ROOT/"deploy_genia_one_service.sh").read_text(encoding="utf-8")
for token in ("--min 0", "--max-attempts=100", "--max-retry-duration=86400s",
              "MAX_VIDEO_DURATION_SEC=30", "MAX_CONCURRENT_RENDERS=1", "--gpu-type nvidia-l4"):
    assert token in deploy, f"Missing production deployment setting: {token}"
gitignore = (ROOT/".gitignore").read_text(encoding="utf-8")
for token in (".env", "service-account*.json", "*.safetensors", "*.pth", "*.pt"):
    assert token in gitignore
print("PASS: startup lifecycle, model warm-up retry, scale-to-zero, 30-second cap and GitHub secret/model exclusions")

ui = (ROOT/"GeniaApexStudio.tsx").read_text(encoding="utf-8")
assert 'value="latentsync">LatentSync 1.5' in ui
assert 'value="native_omni">Native Omni' not in ui and 'value="google_tts">Google TTS' not in ui
print("PASS: Base44 UI only exposes the supported local lip-sync modes")
