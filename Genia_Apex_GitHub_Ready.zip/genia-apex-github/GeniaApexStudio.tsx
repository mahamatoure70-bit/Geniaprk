import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  Activity, Aperture, AudioLines, BadgeCheck, Camera, Check, ChevronDown,
  CircleAlert, Clapperboard, Cloud, Download, Film, Gauge, Image as ImageIcon,
  LayoutDashboard, Loader2, Mic2, Music2, Play, Plus, RefreshCw, Scissors,
  Settings2, ShieldCheck, Sparkles, Square, WandSparkles, X
} from "lucide-react";
import { GeniaApexApi, TokenProvider } from "./geniaApexApi";

type Props = { apiBaseUrl?: string; getAccessToken: TokenProvider };
type Tab = "overview" | "create" | "templates" | "photo" | "camera" | "music" | "split" | "voices" | "health";
const NAV: { id: Tab; label: string; icon: any; group: string }[] = [
  { id: "overview", label: "Vue d'ensemble", icon: LayoutDashboard, group: "WORKSPACE" },
  { id: "create", label: "Créer une vidéo", icon: Clapperboard, group: "CRÉATION" },
  { id: "templates", label: "Templates", icon: Film, group: "CRÉATION" },
  { id: "photo", label: "Photo & modèles", icon: ImageIcon, group: "CRÉATION" },
  { id: "camera", label: "Camera Studio", icon: Camera, group: "CRÉATION" },
  { id: "music", label: "Photo + Musique", icon: Music2, group: "CRÉATION" },
  { id: "split", label: "Découpage vidéo", icon: Scissors, group: "INTELLIGENCE IA" },
  { id: "voices", label: "Voix & profils", icon: Mic2, group: "INTELLIGENCE IA" },
  { id: "health", label: "Centre système", icon: Activity, group: "SYSTÈME" },
];

const cx = (...v: (string | false | null | undefined)[]) => v.filter(Boolean).join(" ");
const Panel = ({ children, className = "" }: any) => <section className={cx("rounded-2xl border border-white/[0.08] bg-[#11101a] shadow-[0_18px_60px_rgba(0,0,0,.22)]", className)}>{children}</section>;
const Field = ({ label, children, hint }: any) => <label className="block space-y-2"><span className="text-[11px] font-semibold uppercase tracking-[.16em] text-white/45">{label}</span>{children}{hint && <span className="block text-xs text-white/35">{hint}</span>}</label>;
const Input = (p: React.InputHTMLAttributes<HTMLInputElement>) => <input {...p} className={cx("w-full rounded-xl border border-white/10 bg-[#0b0a12] px-3.5 py-3 text-sm text-white outline-none transition placeholder:text-white/25 focus:border-violet-400/70 focus:ring-2 focus:ring-violet-500/15", p.className)} />;
const Select = (p: React.SelectHTMLAttributes<HTMLSelectElement>) => <select {...p} className={cx("w-full rounded-xl border border-white/10 bg-[#0b0a12] px-3.5 py-3 text-sm text-white outline-none focus:border-violet-400/70", p.className)} />;
const Textarea = (p: React.TextareaHTMLAttributes<HTMLTextAreaElement>) => <textarea {...p} className={cx("w-full min-h-28 rounded-xl border border-white/10 bg-[#0b0a12] px-3.5 py-3 text-sm text-white outline-none placeholder:text-white/25 focus:border-violet-400/70", p.className)} />;
const Button = ({ children, variant = "primary", ...p }: any) => <button {...p} className={cx("inline-flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-45", variant === "primary" ? "bg-violet-500 text-white shadow-[0_8px_28px_rgba(139,92,246,.25)] hover:bg-violet-400" : variant === "quiet" ? "border border-white/10 bg-white/[0.04] text-white/80 hover:bg-white/[0.08]" : "text-white/50 hover:bg-white/[0.06] hover:text-white", p.className)}>{children}</button>;
const Pill = ({ children, tone = "violet" }: any) => <span className={cx("inline-flex items-center rounded-full border px-2.5 py-1 text-[10px] font-bold uppercase tracking-[.12em]", tone === "green" ? "border-emerald-400/20 bg-emerald-400/10 text-emerald-300" : tone === "red" ? "border-rose-400/20 bg-rose-400/10 text-rose-300" : "border-violet-400/20 bg-violet-400/10 text-violet-200")}>{children}</span>;
const Stat = ({ label, value, detail, icon: Icon }: any) => <Panel className="p-5"><div className="flex items-start justify-between"><div><div className="text-xs text-white/40">{label}</div><div className="mt-2 text-2xl font-semibold tracking-tight text-white">{value}</div><div className="mt-1 text-xs text-white/35">{detail}</div></div><div className="rounded-xl border border-violet-400/20 bg-violet-400/10 p-2.5 text-violet-200"><Icon size={18}/></div></div></Panel>;

export default function GeniaApexStudio({ apiBaseUrl, getAccessToken }: Props) {
  const api = useMemo(() => new GeniaApexApi(apiBaseUrl || (import.meta as any).env?.VITE_GENIA_APEX_API_URL || "", getAccessToken), [apiBaseUrl, getAccessToken]);
  const [tab, setTab] = useState<Tab>("overview");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{kind:"ok"|"error"; text:string}|null>(null);
  const [readiness, setReadiness] = useState<any>(null);
  const [wallet, setWallet] = useState<any>(null);
  const [catalog, setCatalog] = useState<any>({avatars:[], voices:[], presets:[], photoModels:[], filters:[], stickers:[], templates:[]});
  const [jobId, setJobId] = useState("");
  const [job, setJob] = useState<any>(null);
  const [script, setScript] = useState("");
  const [avatarId, setAvatarId] = useState("leo_express");
  const [voiceId, setVoiceId] = useState("");
  const [duration, setDuration] = useState(30);
  const [ratio, setRatio] = useState("9:16");
  const [lipSync, setLipSync] = useState("auto");
  const [sceneCount, setSceneCount] = useState(3);
  const [title, setTitle] = useState("");
  const [subtitles, setSubtitles] = useState(true);
  const [filterId, setFilterId] = useState("");
  const [stickerIds, setStickerIds] = useState<string[]>([]);
  const [stickerPosition, setStickerPosition] = useState("top_right");
  const [textStyle, setTextStyle] = useState("pop_sticker_box");
  const [subtitlePosition, setSubtitlePosition] = useState("bottom");
  const [voiceRate, setVoiceRate] = useState(1.06);
  const [bgmUrl, setBgmUrl] = useState("");
  const [bgmVolume, setBgmVolume] = useState(0.15);
  const [templateId, setTemplateId] = useState("");
  const [mediaUrls, setMediaUrls] = useState("");
  const [photoModelId, setPhotoModelId] = useState("");
  const [photoUrls, setPhotoUrls] = useState("");
  const [insertionMode, setInsertionMode] = useState("add_model_to_photos");
  const [cameraFile, setCameraFile] = useState<File|null>(null);
  const [cameraPreset, setCameraPreset] = useState("cam_zoom_hook");
  const [cameraSpeed, setCameraSpeed] = useState(1);
  const [photoUrl, setPhotoUrl] = useState("");
  const [songUrl, setSongUrl] = useState("");
  const [lyrics, setLyrics] = useState("");
  const [extractLyrics, setExtractLyrics] = useState(true);
  const [motion, setMotion] = useState("zoom_in");
  const [splitUrl, setSplitUrl] = useState("");
  const [splitCount, setSplitCount] = useState(3);
  const [clipDuration, setClipDuration] = useState(8);
  const [followers, setFollowers] = useState(1000);
  const [avgViews, setAvgViews] = useState(800);
  const [platform, setPlatform] = useState("tiktok");
  const [estimate, setEstimate] = useState<any>(null);
  const [voiceName, setVoiceName] = useState("Ma voix");
  const [sourceAudio, setSourceAudio] = useState<File|null>(null);
  const [consentAudio, setConsentAudio] = useState<File|null>(null);
  const [lastRefresh, setLastRefresh] = useState("");

  const run = useCallback(async (fn:()=>Promise<any>, success?:string) => {
    setBusy(true); setNotice(null);
    try { const result = await fn(); if (success) setNotice({kind:"ok",text:success}); return result; }
    catch(e:any) { setNotice({kind:"error",text:e?.message || "Une erreur est survenue."}); }
    finally { setBusy(false); }
  }, []);

  const loadCore = useCallback(async () => {
    const [r,w] = await Promise.allSettled([api.readiness(), api.wallet()]);
    if (r.status === "fulfilled") setReadiness(r.value);
    if (w.status === "fulfilled") setWallet(w.value?.wallet || null);
    const failures = [r,w].filter(x => x.status === "rejected");
    if (failures.length) throw new Error("Une partie des informations système ou du portefeuille est indisponible. Vérifiez la connexion et les autorisations.");
    setLastRefresh(new Date().toLocaleTimeString());
  }, [api]);

  const loadCatalog = useCallback(async () => {
    const results = await Promise.allSettled([
      api.avatars(), api.voices(), api.cameraPresets(), api.photoModels(), api.filters(), api.stickers(), api.templates()
    ]);
    const value = (index:number) => results[index].status === "fulfilled" ? (results[index] as PromiseFulfilledResult<any>).value : {};
    setCatalog({
      avatars:value(0).avatars||[], voices:value(1).voices||[], presets:value(2).camera_presets||[],
      photoModels:value(3).photo_models||[], filters:value(4).filters||[], stickers:value(5).stickers||[], templates:value(6).templates||[]
    });
    if (results.some(x=>x.status==="rejected")) throw new Error("Certains catalogues sont indisponibles. Les autres modules restent accessibles.");
  }, [api]);

  useEffect(() => { run(async()=>{await Promise.all([loadCore(),loadCatalog()]);}, "Connexion au moteur Genia Apex établie."); }, [loadCore,loadCatalog,run]);
  useEffect(() => { if (catalog.templates.length && !templateId) setTemplateId(catalog.templates[0]?.template_id || catalog.templates[0]?.id || ""); }, [catalog.templates,templateId]);
  useEffect(() => { if (catalog.photoModels.length && !photoModelId) setPhotoModelId(catalog.photoModels[0]?.photo_model_id || catalog.photoModels[0]?.id || ""); }, [catalog.photoModels,photoModelId]);

  const submitJob = (res:any) => { if(res?.job_id){setJobId(res.job_id);setJob(res);setNotice({kind:"ok",text:`Tâche envoyée. Identifiant : ${res.job_id}`});} };
  const refreshJob = async () => { if(!jobId) return; const j=await run(()=>api.job(jobId)); if(j) setJob(j); };
  const startRender = async () => {
    const r=await run(()=>api.startRender({
      raw_script_input:script, avatar_mode:"single_avatar", avatar_id:avatarId,
      voice_profile_id:voiceId || null, lip_sync_mode:lipSync, auto_multi_scenes_count:sceneCount,
      aspect_ratio:ratio, max_total_duration_sec:duration, show_subtitles:subtitles,
      overlay_title:title || null, subtitle_position:subtitlePosition, transition_style:"cut",
      voice_speaking_rate:voiceRate, text_style_id:textStyle, filter_id:filterId||null,
      sticker_ids:stickerIds, sticker_position:stickerPosition, bgm_url:bgmUrl||null, bgm_volume:bgmVolume
    }));
    if(r) submitJob(r);
  };
  const applyTemplate = async () => {
    const items=mediaUrls.split(/\n|,/).map(x=>x.trim()).filter(Boolean).map(media_url=>({media_url,media_type:/\.(mp4|mov|webm)(\?|$)/i.test(media_url)?"video":"image"}));
    const r=await run(()=>api.applyTemplate({template_id:templateId,media_items:items,aspect_ratio:ratio,transition_style:"cut",show_subtitles:subtitles,voice_profile_id:voiceId||null,voice_speaking_rate:voiceRate,text_style_id:textStyle,filter_id:filterId||null,sticker_ids:stickerIds,sticker_position:stickerPosition,bgm_url:bgmUrl||null,bgm_volume:bgmVolume,subtitle_position:subtitlePosition}));
    if(r) submitJob(r);
  };
  const applyPhoto = async () => {
    const urls=photoUrls.split(/\n|,/).map(x=>x.trim()).filter(Boolean);
    const r=await run(()=>api.applyPhotoModel({photo_model_id:photoModelId,user_photo_urls:urls,insertion_mode:insertionMode,voice_enabled:true,personnage:"narrateur",aspect_ratio:ratio,show_subtitles:subtitles,subtitle_position:subtitlePosition,voice_speaking_rate:voiceRate,text_style_id:textStyle,filter_id:filterId||null,sticker_ids:stickerIds,sticker_position:stickerPosition,bgm_url:bgmUrl||null,bgm_volume:bgmVolume}));
    if(r) submitJob(r);
  };
  const processCamera = async () => {
    if (!cameraFile) {
      setNotice({kind:"error", text:"Sélectionnez d'abord une vidéo enregistrée."});
      return;
    }
    const r = await run(async () => {
      const uploaded = await api.cameraUpload(cameraFile);
      if (!uploaded?.video_url) throw new Error("Le téléversement est terminé sans URL vidéo exploitable.");
      return await api.cameraProcess({
        recorded_video_url: uploaded.video_url,
        camera_preset_id: cameraPreset,
        playback_speed: cameraSpeed,
        aspect_ratio: ratio,
        show_subtitles: subtitles,
        subtitle_position: "bottom",
        text_style_id: "pop_sticker_box",
        sticker_ids: []
      });
    }, "Vidéo envoyée au Camera Studio.");
    if (r) submitJob(r);
  };
  const createSongPhoto = async () => {
    const r=await run(()=>api.songPhoto({photo_url:photoUrl,song_url:songUrl,lyrics_text:lyrics||null,auto_extract_lyrics:extractLyrics,motion,lyrics_position:subtitlePosition,show_lyrics:true,aspect_ratio:ratio,text_style_id:textStyle,filter_id:filterId||null,sticker_ids:stickerIds,sticker_position:stickerPosition,bgm_url:bgmUrl||null,bgm_volume:bgmVolume}));
    if(r) submitJob(r);
  };
  const split = async () => {
    const r=await run(()=>api.splitVideo({source_video_url:splitUrl,num_clips:splitCount,clip_duration:clipDuration,topic_context:"Moment fort",add_hook_voice:false,personnage:"narrateur"}));
    if(r) submitJob(r);
  };
  const estimatePotential = async () => {
    const r=await run(()=>api.estimateViews({followers_count:followers,average_views_per_video:avgViews,platform,scenes_count:sceneCount,script_or_captions:script||null}));
    if(r) setEstimate(r);
  };
  const cloneVoice = async () => {
    if(!sourceAudio||!consentAudio) throw new Error("Ajoutez l'audio source et l'enregistrement de consentement.");
    const r=await run(()=>api.createVoice(sourceAudio,consentAudio,voiceName),"Demande de création de profil vocal envoyée.");
    if(r) await loadCatalog();
  };

  const advancedOptions = <details className="rounded-xl border border-white/[.08] bg-white/[.02] p-4"><summary className="flex cursor-pointer list-none items-center justify-between text-xs font-semibold text-violet-200"><span className="flex items-center gap-2"><Settings2 size={14}/> Réglages avancés de montage</span><ChevronDown size={14}/></summary><div className="mt-4 grid gap-4 sm:grid-cols-2"><Field label="Filtre"><Select value={filterId} onChange={e=>setFilterId(e.target.value)}><option value="">Aucun filtre</option>{catalog.filters.map((f:any)=><option key={f.filter_id||f.id} value={f.filter_id||f.id}>{f.name||f.label||f.filter_id||f.id}</option>)}</Select></Field><Field label="Style de texte"><Select value={textStyle} onChange={e=>setTextStyle(e.target.value)}><option value="pop_sticker_box">Pop sticker box</option><option value="neon_glow">Neon glow</option><option value="gradient_fire">Gradient fire</option></Select></Field><Field label="Position des sous-titres"><Select value={subtitlePosition} onChange={e=>setSubtitlePosition(e.target.value)}><option value="top">Haut</option><option value="center">Centre</option><option value="bottom">Bas</option></Select></Field><Field label={`Vitesse de la voix · ${voiceRate.toFixed(2)}x`}><input type="range" min="0.75" max="1.45" step="0.01" value={voiceRate} onChange={e=>setVoiceRate(Number(e.target.value))} className="w-full accent-violet-400"/></Field><Field label="Position des stickers"><Select value={stickerPosition} onChange={e=>setStickerPosition(e.target.value)}><option value="top_left">Haut gauche</option><option value="top_right">Haut droite</option><option value="bottom_left">Bas gauche</option><option value="bottom_right">Bas droite</option><option value="center">Centre</option></Select></Field><Field label={`Volume musique de fond · ${Math.round(bgmVolume*100)}%`}><input type="range" min="0" max="0.6" step="0.01" value={bgmVolume} onChange={e=>setBgmVolume(Number(e.target.value))} className="w-full accent-violet-400"/></Field><div className="sm:col-span-2"><Field label="URL musique de fond (facultatif)"><Input value={bgmUrl} onChange={e=>setBgmUrl(e.target.value)} placeholder="https://…/musique.mp3"/></Field></div><div className="sm:col-span-2"><div className="mb-2 text-[11px] font-semibold uppercase tracking-[.16em] text-white/45">Stickers (maximum 4)</div><div className="flex flex-wrap gap-2">{catalog.stickers.map((st:any)=>{const id=st.sticker_id||st.id;const active=stickerIds.includes(id);return <button type="button" key={id} onClick={()=>setStickerIds(old=>active?old.filter(x=>x!==id):old.length<4?[...old,id]:old)} className={cx("rounded-lg border px-3 py-2 text-[11px]",active?"border-violet-400/40 bg-violet-500/15 text-violet-100":"border-white/10 bg-black/20 text-white/50")}>{st.name||st.label||id}</button>})}{!catalog.stickers.length&&<span className="text-xs text-white/30">Aucun sticker renvoyé par le catalogue.</span>}</div></div></div></details>;

  const titleByTab:Record<Tab,string> = {overview:"Votre studio de création",create:"Génération vidéo IA",templates:"Templates intelligents",photo:"Studio photo & modèles",camera:"Camera Studio",music:"Photo + Musique",split:"Découpage intelligent",voices:"Voix & profils",health:"Centre de contrôle"};
  const checkEntries = Object.entries(readiness?.checks || {});
  const healthyCount = checkEntries.filter(([,v])=>v===true).length;
  const checkCount = checkEntries.length;
  const statusLabel = readiness?.status === "configured" ? "Système opérationnel" : readiness ? "Configuration partielle" : "Connexion…";

  return <div className="min-h-screen bg-[#090811] text-white" style={{fontFamily:"Inter, ui-sans-serif, system-ui"}}>
    <div className="pointer-events-none fixed inset-0 overflow-hidden"><div className="absolute -top-48 left-[28%] h-[440px] w-[440px] rounded-full bg-violet-700/15 blur-[130px]"/><div className="absolute right-[-160px] top-[36%] h-[380px] w-[380px] rounded-full bg-fuchsia-700/10 blur-[130px]"/></div>
    <div className="relative flex min-h-screen">
      <aside className="hidden w-[258px] shrink-0 border-r border-white/[0.07] bg-[#0d0b15]/95 px-4 py-5 lg:flex lg:flex-col">
        <div className="flex items-center gap-3 px-2 pb-7">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-violet-400 to-fuchsia-600 shadow-lg shadow-violet-900/40"><Aperture size={21}/></div>
          <div><div className="text-[15px] font-black tracking-[.18em]">GENIA<span className="text-violet-300"> APEX</span></div><div className="mt-0.5 text-[9px] font-bold tracking-[.28em] text-white/35">AI CREATIVE ENGINE</div></div>
        </div>
        {["WORKSPACE","CRÉATION","INTELLIGENCE IA","SYSTÈME"].map(group=><div key={group} className="mb-5"><div className="mb-2 px-3 text-[9px] font-bold tracking-[.2em] text-white/25">{group}</div><div className="space-y-1">{NAV.filter(n=>n.group===group).map(n=>{const Icon=n.icon;return <button key={n.id} onClick={()=>setTab(n.id)} className={cx("flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-[12px] font-medium transition",tab===n.id?"bg-violet-500/15 text-violet-200 ring-1 ring-violet-400/20":"text-white/50 hover:bg-white/[.04] hover:text-white/85")}><Icon size={16}/>{n.label}{tab===n.id&&<span className="ml-auto h-1.5 w-1.5 rounded-full bg-violet-300 shadow-[0_0_10px_#a78bfa]"/>}</button>})}</div></div>)}
        <div className="mt-auto rounded-2xl border border-violet-400/15 bg-gradient-to-br from-violet-500/10 to-fuchsia-500/[0.04] p-4"><div className="flex items-center gap-2 text-xs font-semibold text-violet-200"><ShieldCheck size={15}/> Moteur protégé</div><p className="mt-2 text-[11px] leading-5 text-white/40">Diagnostic et récupération automatique des erreurs récupérables.</p><button onClick={()=>setTab("health")} className="mt-3 text-[11px] font-semibold text-violet-300 hover:text-white">Voir l'état système →</button></div>
      </aside>

      <main className="min-w-0 flex-1">
        <header className="sticky top-0 z-20 flex items-center justify-between border-b border-white/[0.07] bg-[#090811]/85 px-5 py-4 backdrop-blur-xl md:px-8">
          <div className="flex items-center gap-3"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-violet-500/15 text-violet-200 lg:hidden"><Aperture size={18}/></div><div><div className="text-sm font-semibold">{titleByTab[tab]}</div><div className="mt-0.5 text-[10px] text-white/35">Genia Apex Studio <span className="px-1.5 text-violet-300">/</span> {statusLabel}</div></div></div>
          <div className="flex items-center gap-2"><div className="hidden items-center gap-2 rounded-full border border-white/10 bg-white/[.03] px-3 py-2 text-[11px] text-white/50 sm:flex"><span className={cx("h-1.5 w-1.5 rounded-full",readiness?.status==="configured"?"bg-emerald-400":"bg-amber-400")}/>{statusLabel}</div><Button variant="quiet" onClick={()=>run(async()=>{await Promise.all([loadCore(),loadCatalog()]);},"Données actualisées.")} disabled={busy}><RefreshCw size={14}/></Button></div>
        </header>

        <nav className="relative z-10 flex gap-2 overflow-x-auto border-b border-white/[.06] bg-[#0d0b15]/80 px-4 py-3 lg:hidden">{NAV.map(n=>{const Icon=n.icon;return <button key={n.id} onClick={()=>setTab(n.id)} className={cx("flex shrink-0 items-center gap-2 rounded-full border px-3 py-2 text-[11px]",tab===n.id?"border-violet-400/30 bg-violet-500/15 text-violet-100":"border-white/10 text-white/50")}><Icon size={13}/>{n.label}</button>})}</nav>
        <div className="relative z-10 mx-auto max-w-[1500px] space-y-6 px-4 py-6 md:px-8 md:py-8">
          {notice&&<div className={cx("flex items-start gap-3 rounded-xl border px-4 py-3 text-sm",notice.kind==="ok"?"border-emerald-400/20 bg-emerald-400/[.07] text-emerald-200":"border-rose-400/20 bg-rose-400/[.07] text-rose-200")}><span className="mt-0.5">{notice.kind==="ok"?<Check size={16}/>:<CircleAlert size={16}/>}</span><span className="flex-1">{notice.text}</span><button onClick={()=>setNotice(null)}><X size={15}/></button></div>}
          {jobId&&<Panel className="flex flex-wrap items-center justify-between gap-3 border-violet-400/20 bg-violet-500/[.06] p-4"><div className="flex items-center gap-3"><div className="rounded-xl bg-violet-400/10 p-2.5 text-violet-200"><Clapperboard size={18}/></div><div><div className="text-xs font-semibold">Dernière tâche envoyée</div><div className="mt-1 font-mono text-[10px] text-white/40">{jobId}</div><div className="mt-1 text-[11px] text-violet-200">{job?.step || job?.status || "En attente de statut"}</div></div></div><div className="flex gap-2"><Button variant="quiet" onClick={refreshJob} disabled={busy}><RefreshCw size={13}/> Actualiser</Button><Button variant="quiet" onClick={()=>run(()=>api.cancel(jobId),"Demande d'annulation transmise.")} disabled={busy}><Square size={12}/> Annuler</Button></div></Panel>}

          {tab==="overview"&&<div className="space-y-6">
            <div className="relative overflow-hidden rounded-3xl border border-violet-400/15 bg-gradient-to-br from-[#21133e] via-[#17112b] to-[#100e19] p-7 md:p-9"><div className="absolute right-[-25px] top-[-80px] h-64 w-64 rounded-full border border-violet-300/10"/><div className="absolute right-8 top-8 h-40 w-40 rounded-full border border-fuchsia-300/10"/><div className="relative max-w-2xl"><Pill>GENIA APEX · CREATIVE INTELLIGENCE</Pill><h1 className="mt-5 text-3xl font-semibold leading-tight tracking-tight md:text-4xl">Donnez vie à vos idées.<br/><span className="bg-gradient-to-r from-violet-200 via-fuchsia-200 to-violet-400 bg-clip-text text-transparent">L'IA s'occupe du reste.</span></h1><p className="mt-4 max-w-xl text-sm leading-6 text-white/50">Un espace de création complet pour générer, transformer, analyser et découper vos contenus vidéo.</p><div className="mt-6 flex flex-wrap gap-3"><Button onClick={()=>setTab("create")}><Sparkles size={15}/> Créer une vidéo</Button><Button variant="quiet" onClick={()=>setTab("templates")}>Explorer les templates</Button></div></div></div>
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4"><Stat label="Crédits disponibles" value={wallet?.credits_balance ?? "—"} detail={wallet?.plan_id || "Portefeuille Genia"} icon={Gauge}/><Stat label="Moteurs disponibles" value={`${healthyCount}/${checkCount||"—"}`} detail="Contrôles système remontés par l'API" icon={Cloud}/><Stat label="Templates chargés" value={catalog.templates.length} detail="Catalogue renvoyé par le moteur" icon={Film}/><Stat label="Profils vocaux" value={catalog.voices.length} detail="Voix liées au compte connecté" icon={AudioLines}/></div>
            <div className="grid gap-4 xl:grid-cols-[1.25fr_.75fr]"><Panel className="p-5"><div className="flex items-center justify-between"><div><div className="text-sm font-semibold">Votre espace de création</div><div className="mt-1 text-xs text-white/35">Accès direct aux modules du moteur</div></div><Pill>8 modules</Pill></div><div className="mt-5 grid gap-3 sm:grid-cols-2">{NAV.filter(x=>!["overview","health"].includes(x.id)).map(n=>{const Icon=n.icon;return <button key={n.id} onClick={()=>setTab(n.id)} className="group flex items-center gap-3 rounded-xl border border-white/[.07] bg-white/[.02] p-3 text-left transition hover:border-violet-400/25 hover:bg-violet-500/[.06]"><span className="rounded-lg bg-violet-500/10 p-2.5 text-violet-200"><Icon size={17}/></span><span className="min-w-0 flex-1"><span className="block text-xs font-semibold">{n.label}</span><span className="mt-1 block text-[10px] text-white/35">Ouvrir le module</span></span><span className="text-white/20 group-hover:text-violet-200">↗</span></button>})}</div></Panel><Panel className="p-5"><div className="text-sm font-semibold">État du moteur</div><div className="mt-1 text-xs text-white/35">Dernière actualisation : {lastRefresh||"—"}</div><div className="mt-5 space-y-3">{checkEntries.slice(0,7).map(([k,v])=><div key={k} className="flex items-center justify-between gap-3"><span className="truncate text-[11px] text-white/50">{k.replaceAll("_"," ")}</span><Pill tone={v===true?"green":"red"}>{v===true?"OK":"À vérifier"}</Pill></div>)}</div><Button variant="quiet" className="mt-5 w-full" onClick={()=>setTab("health")}>Ouvrir le diagnostic complet</Button></Panel></div>
          </div>}

          {tab==="create"&&<div className="grid gap-5 xl:grid-cols-[1fr_340px]"><Panel className="p-5 md:p-7"><div className="mb-6"><Pill>STUDIO 01 · VIDEO GENERATION</Pill><h2 className="mt-3 text-xl font-semibold">Créer une vidéo avec un avatar IA</h2><p className="mt-1 text-xs text-white/40">Le moteur accepte un script, un avatar, une voix et les paramètres de rendu.</p></div><div className="space-y-5"><Field label="Votre script"><Textarea value={script} onChange={e=>setScript(e.target.value)} placeholder="Écrivez le texte que votre avatar doit prononcer…" maxLength={4000}/></Field><div className="grid gap-4 sm:grid-cols-2"><Field label="Avatar"><Select value={avatarId} onChange={e=>setAvatarId(e.target.value)}>{catalog.avatars.map((a:any)=><option key={a.avatar_id||a.id} value={a.avatar_id||a.id}>{a.name||a.label||a.avatar_id||a.id}</option>)}</Select></Field><Field label="Profil vocal"><Select value={voiceId} onChange={e=>setVoiceId(e.target.value)}><option value="">Voix par défaut</option>{catalog.voices.map((v:any)=><option key={v.voice_profile_id} value={v.voice_profile_id}>{v.display_name} · {v.status}</option>)}</Select></Field><Field label="Synchronisation labiale"><Select value={lipSync} onChange={e=>setLipSync(e.target.value)}><option value="auto">Automatique · moteurs locaux</option><option value="latentsync">LatentSync 1.5 · synchronisation locale</option></Select></Field><Field label="Nombre de scènes automatiques"><Select value={sceneCount} onChange={e=>setSceneCount(Number(e.target.value))}>{[2,3,4,5,6,8,10,12].map(n=><option key={n} value={n}>{n} scènes</option>)}</Select></Field><Field label={`Durée maximale · ${duration}s`}><input type="range" min="3" max="30" value={duration} onChange={e=>setDuration(Number(e.target.value))} className="w-full accent-violet-400"/><div className="flex justify-between text-[10px] text-white/30"><span>3 sec</span><span>30 sec</span></div></Field><Field label="Format vidéo"><Select value={ratio} onChange={e=>setRatio(e.target.value)}><option>9:16</option><option>1:1</option><option>16:9</option></Select></Field></div><Field label="Titre incrusté (facultatif)"><Input value={title} onChange={e=>setTitle(e.target.value)} maxLength={40} placeholder="Votre accroche…"/></Field><label className="flex items-center gap-3 text-xs text-white/60"><input type="checkbox" checked={subtitles} onChange={e=>setSubtitles(e.target.checked)} className="accent-violet-400"/> Ajouter les sous-titres</label>{advancedOptions}<Button onClick={startRender} disabled={busy||!script.trim()} className="w-full py-3.5">{busy?<Loader2 className="animate-spin" size={16}/>:<WandSparkles size={16}/>} Lancer la génération</Button></div></Panel><div className="space-y-4"><Panel className="p-5"><div className="flex items-center gap-2 text-sm font-semibold"><Sparkles size={16} className="text-violet-300"/> Analyse de potentiel</div><p className="mt-2 text-xs text-white/40">Estimez le potentiel éditorial de votre script à partir des données fournies au moteur.</p><div className="mt-4 space-y-3"><Field label="Plateforme"><Select value={platform} onChange={e=>setPlatform(e.target.value)}><option value="tiktok">TikTok</option><option value="reels">Instagram Reels</option><option value="shorts">YouTube Shorts</option></Select></Field><Field label="Abonnés"><Input type="number" value={followers} onChange={e=>setFollowers(Number(e.target.value))}/></Field><Field label="Vues moyennes par vidéo"><Input type="number" value={avgViews} onChange={e=>setAvgViews(Number(e.target.value))}/></Field><Button variant="quiet" className="w-full" onClick={estimatePotential} disabled={busy}>Analyser le potentiel</Button>{estimate&&<pre className="max-h-64 overflow-auto rounded-xl bg-black/30 p-3 text-[10px] text-violet-100">{JSON.stringify(estimate,null,2)}</pre>}</div></Panel><Panel className="p-5"><div className="flex items-center gap-2 text-sm font-semibold"><ShieldCheck size={16} className="text-emerald-300"/> Génération sécurisée</div><p className="mt-2 text-xs leading-5 text-white/40">Les erreurs récupérables peuvent déclencher des tentatives avec temporisation. Les erreurs d'accès, de quota ou de configuration restent signalées pour intervention.</p></Panel></div></div>}

          {tab==="templates"&&<Panel className="p-5 md:p-7"><div className="flex flex-wrap items-start justify-between gap-3"><div><Pill>STUDIO 02 · TEMPLATES</Pill><h2 className="mt-3 text-xl font-semibold">Templates intelligents</h2><p className="mt-1 text-xs text-white/40">Choisissez un template renvoyé par le moteur puis fournissez les médias à utiliser.</p></div><Button variant="quiet" onClick={()=>run(async()=>{const r=await api.generateTemplates(3);await loadCatalog();return r;},"Génération de templates demandée.")} disabled={busy}><Sparkles size={14}/> Générer des templates</Button></div><div className="mt-6 grid gap-5 lg:grid-cols-2"><Field label="Template disponible"><Select value={templateId} onChange={e=>setTemplateId(e.target.value)}>{catalog.templates.map((t:any)=><option key={t.template_id||t.id} value={t.template_id||t.id}>{t.name||t.title||t.template_id||t.id}</option>)}</Select></Field><Field label="Format"><Select value={ratio} onChange={e=>setRatio(e.target.value)}><option>9:16</option><option>1:1</option><option>16:9</option></Select></Field></div><div className="mt-5"><Field label="URLs des photos ou vidéos (une par ligne)" hint="Utilisez des URL accessibles au moteur, par exemple les URL de médias hébergés par votre espace Base44."><Textarea value={mediaUrls} onChange={e=>setMediaUrls(e.target.value)} placeholder={"https://…/photo-1.jpg\nhttps://…/clip-2.mp4"}/></Field></div><div className="mt-5">{advancedOptions}</div><Button className="mt-5" onClick={applyTemplate} disabled={busy||!templateId||!mediaUrls.trim()}><WandSparkles size={15}/> Appliquer le template</Button></Panel>}

          {tab==="photo"&&<Panel className="p-5 md:p-7"><Pill>STUDIO 03 · PHOTO MODELS</Pill><h2 className="mt-3 text-xl font-semibold">Photo & modèles IA</h2><p className="mt-1 text-xs text-white/40">Associez vos photos à un modèle du catalogue.</p><div className="mt-6 grid gap-4 sm:grid-cols-2"><Field label="Modèle photo"><Select value={photoModelId} onChange={e=>setPhotoModelId(e.target.value)}>{catalog.photoModels.map((m:any)=><option key={m.photo_model_id||m.id} value={m.photo_model_id||m.id}>{m.name||m.label||m.photo_model_id||m.id}</option>)}</Select></Field><Field label="Mode d'insertion"><Select value={insertionMode} onChange={e=>setInsertionMode(e.target.value)}><option value="add_model_to_photos">Ajouter le modèle à mes photos</option><option value="add_photos_to_model">Ajouter mes photos au modèle</option></Select></Field></div><div className="mt-5"><Field label="URLs de vos photos (une par ligne)"><Textarea value={photoUrls} onChange={e=>setPhotoUrls(e.target.value)} placeholder={"https://…/image-1.jpg\nhttps://…/image-2.jpg"}/></Field></div><div className="mt-4 max-w-xs"><Field label="Format"><Select value={ratio} onChange={e=>setRatio(e.target.value)}><option>9:16</option><option>1:1</option><option>16:9</option></Select></Field></div><div className="mt-5">{advancedOptions}</div><Button className="mt-5" onClick={applyPhoto} disabled={busy||!photoModelId||!photoUrls.trim()}><ImageIcon size={15}/> Générer avec le modèle</Button></Panel>}

          {tab==="camera"&&<Panel className="p-5 md:p-7"><Pill>STUDIO 04 · CAMERA</Pill><h2 className="mt-3 text-xl font-semibold">Camera Studio</h2><p className="mt-1 text-xs text-white/40">Importez une vidéo enregistrée, puis appliquez un préréglage de caméra.</p><div className="mt-6 grid gap-4 sm:grid-cols-2"><Field label="Fichier vidéo"><Input type="file" accept="video/mp4,video/webm,video/quicktime" onChange={e=>setCameraFile(e.target.files?.[0]||null)}/></Field><Field label="Préréglage caméra"><Select value={cameraPreset} onChange={e=>setCameraPreset(e.target.value)}>{catalog.presets.map((p:any)=><option key={p.camera_preset_id||p.id} value={p.camera_preset_id||p.id}>{p.name||p.label||p.camera_preset_id||p.id}</option>)}</Select></Field><Field label={`Vitesse de lecture · ${cameraSpeed}x`}><input type="range" min=".5" max="1.75" step=".05" value={cameraSpeed} onChange={e=>setCameraSpeed(Number(e.target.value))} className="w-full accent-violet-400"/></Field><Field label="Format"><Select value={ratio} onChange={e=>setRatio(e.target.value)}><option>9:16</option><option>1:1</option><option>16:9</option></Select></Field></div><div className="mt-5">{advancedOptions}</div><Button className="mt-6" onClick={()=>run(processCamera)} disabled={busy||!cameraFile}>{busy?<Loader2 className="animate-spin" size={15}/>:<Camera size={15}/>} Importer et traiter la vidéo</Button></Panel>}

          {tab==="music"&&<Panel className="p-5 md:p-7"><Pill>STUDIO 05 · MUSIC & LYRICS</Pill><h2 className="mt-3 text-xl font-semibold">Photo + Musique</h2><p className="mt-1 text-xs text-white/40">Animez une photo sur une piste audio, avec extraction facultative des paroles.</p><div className="mt-6 grid gap-4 sm:grid-cols-2"><Field label="URL de la photo"><Input value={photoUrl} onChange={e=>setPhotoUrl(e.target.value)} placeholder="https://…/photo.jpg"/></Field><Field label="URL de la chanson"><Input value={songUrl} onChange={e=>setSongUrl(e.target.value)} placeholder="https://…/audio.mp3"/></Field><Field label="Animation"><Select value={motion} onChange={e=>setMotion(e.target.value)}><option value="zoom_in">Zoom avant</option><option value="zoom_out">Zoom arrière</option><option value="pan_right">Panoramique droite</option><option value="pan_left">Panoramique gauche</option><option value="static">Statique</option></Select></Field><Field label="Format"><Select value={ratio} onChange={e=>setRatio(e.target.value)}><option>9:16</option><option>1:1</option><option>16:9</option></Select></Field></div><label className="mt-5 flex items-center gap-3 text-xs text-white/60"><input type="checkbox" checked={extractLyrics} onChange={e=>setExtractLyrics(e.target.checked)} className="accent-violet-400"/> Extraire automatiquement les paroles</label><div className="mt-4"><Field label="Paroles (facultatif)"><Textarea value={lyrics} onChange={e=>setLyrics(e.target.value)} placeholder="Collez les paroles si vous ne souhaitez pas l'extraction automatique…"/></Field></div><div className="mt-5">{advancedOptions}</div><Button className="mt-5" onClick={createSongPhoto} disabled={busy||!photoUrl.trim()||!songUrl.trim()}><Music2 size={15}/> Créer la vidéo musicale</Button></Panel>}

          {tab==="split"&&<div className="grid gap-5 xl:grid-cols-[1fr_340px]"><Panel className="p-5 md:p-7"><Pill>STUDIO 06 · SMART CLIPS</Pill><h2 className="mt-3 text-xl font-semibold">Découpage vidéo intelligent</h2><p className="mt-1 text-xs text-white/40">Envoyez une vidéo source pour générer plusieurs extraits.</p><div className="mt-6 space-y-4"><Field label="URL de la vidéo source"><Input value={splitUrl} onChange={e=>setSplitUrl(e.target.value)} placeholder="https://…/video.mp4"/></Field><div className="grid gap-4 sm:grid-cols-2"><Field label="Nombre de clips"><Select value={splitCount} onChange={e=>setSplitCount(Number(e.target.value))}>{[1,2,3,4,5,6,8,10].map(n=><option key={n}>{n}</option>)}</Select></Field><Field label="Durée de chaque clip (sec)"><Input type="number" min={2} max={600} value={clipDuration} onChange={e=>setClipDuration(Number(e.target.value))}/></Field></div><Button onClick={split} disabled={busy||!splitUrl.trim()}><Scissors size={15}/> Découper la vidéo</Button></div></Panel><Panel className="p-5"><div className="text-sm font-semibold">Conseil de préparation</div><p className="mt-3 text-xs leading-6 text-white/45">Utilisez une URL vidéo accessible au moteur. Le traitement est asynchrone : l'identifiant de tâche apparaît après l'envoi et son état peut être actualisé depuis la barre de suivi.</p></Panel></div>}

          {tab==="voices"&&<div className="grid gap-5 xl:grid-cols-[.9fr_1.1fr]"><Panel className="p-5 md:p-7"><Pill>VOICE LAB</Pill><h2 className="mt-3 text-xl font-semibold">Créer un profil vocal</h2><p className="mt-1 text-xs text-white/40">Le backend exige l'audio source et un enregistrement de consentement du propriétaire de la voix.</p><div className="mt-6 space-y-4"><Field label="Nom du profil"><Input value={voiceName} onChange={e=>setVoiceName(e.target.value)}/></Field><Field label="Audio source"><Input type="file" accept="audio/*" onChange={e=>setSourceAudio(e.target.files?.[0]||null)}/></Field><Field label="Audio de consentement"><Input type="file" accept="audio/*" onChange={e=>setConsentAudio(e.target.files?.[0]||null)}/></Field><Button onClick={cloneVoice} disabled={busy||!sourceAudio||!consentAudio}><Mic2 size={15}/> Créer le profil vocal</Button></div></Panel><Panel className="p-5 md:p-7"><div className="flex items-center justify-between"><div><div className="text-sm font-semibold">Mes profils vocaux</div><div className="mt-1 text-xs text-white/35">Données renvoyées par votre compte</div></div><Button variant="quiet" onClick={()=>run(loadCatalog)}><RefreshCw size={13}/> Actualiser</Button></div><div className="mt-5 space-y-2">{catalog.voices.length?catalog.voices.map((v:any)=><div key={v.voice_profile_id} className="flex items-center justify-between rounded-xl border border-white/[.07] bg-white/[.025] p-3"><div className="flex items-center gap-3"><div className="rounded-lg bg-violet-500/10 p-2 text-violet-200"><AudioLines size={16}/></div><div><div className="text-xs font-semibold">{v.display_name}</div><div className="mt-1 font-mono text-[10px] text-white/30">{v.voice_profile_id}</div></div></div><Pill tone={v.status==="ready"?"green":"violet"}>{v.status||"en cours"}</Pill></div>):<div className="rounded-xl border border-dashed border-white/10 p-8 text-center text-xs text-white/35">Aucun profil vocal renvoyé pour ce compte.</div>}</div></Panel></div>}

          {tab==="health"&&<div className="space-y-5"><div className="grid gap-3 sm:grid-cols-3"><Stat label="Statut global" value={readiness?.status||"—"} detail="Réponse de /system/readiness" icon={Activity}/><Stat label="Diagnostics effectués" value={readiness?.checks?.self_healing_engine?.diagnosed??"—"} detail="Erreurs analysées" icon={ShieldCheck}/><Stat label="Réparations enregistrées" value={readiness?.checks?.self_healing_engine?.repaired??"—"} detail="Réparations confirmées" icon={BadgeCheck}/></div><Panel className="p-5 md:p-7"><div className="flex flex-wrap items-center justify-between gap-3"><div><Pill>SYSTEM TELEMETRY</Pill><h2 className="mt-3 text-xl font-semibold">État des moteurs & auto-diagnostic</h2><p className="mt-1 text-xs text-white/40">Lecture des contrôles exposés par l'API. Cette page n'effectue aucune réparation manuelle.</p></div><Button variant="quiet" onClick={()=>run(loadCore)}><RefreshCw size={14}/> Relancer les contrôles</Button></div><div className="mt-6 grid gap-2 md:grid-cols-2">{checkEntries.map(([k,v])=><div key={k} className="flex items-center justify-between gap-4 rounded-xl border border-white/[.07] bg-white/[.02] px-4 py-3"><div className="min-w-0"><div className="break-all text-xs font-medium text-white/75">{k.replaceAll("_"," ")}</div><div className="mt-1 text-[10px] text-white/30">{typeof v==="object"?JSON.stringify(v):String(v)}</div></div>{v===true?<Pill tone="green">OK</Pill>:v===false?<Pill tone="red">À vérifier</Pill>:<Pill>Info</Pill>}</div>)}</div><div className="mt-6 rounded-xl border border-violet-400/15 bg-violet-500/[.05] p-4"><div className="flex items-center gap-2 text-xs font-semibold text-violet-200"><ShieldCheck size={15}/> Auto-Diagnostic & Self-Healing</div><div className="mt-3 grid gap-3 sm:grid-cols-4">{["diagnosed","repaired","unrecoverable","retries"].map(k=><div key={k}><div className="text-[10px] uppercase tracking-wider text-white/35">{k}</div><div className="mt-1 text-xl font-semibold">{readiness?.checks?.self_healing_engine?.[k]??0}</div></div>)}</div><div className="mt-3 text-[10px] leading-5 text-white/35">Mode : {readiness?.checks?.self_healing_engine?.mode||"non communiqué"}. Les réparations personnalisées ne sont disponibles que si elles ont été explicitement enregistrées dans le moteur.</div></div></Panel></div>}
        </div>
      </main>
    </div>
  </div>;
}
