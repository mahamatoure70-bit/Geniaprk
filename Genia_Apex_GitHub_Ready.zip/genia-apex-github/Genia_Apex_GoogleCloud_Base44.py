"""
Genia Apex Studio — Backend Google Cloud / Base44 (FastAPI).

Base44 fournit l'interface SaaS; Cloud Run exécute l'API et le worker local GPU.
Les chemins de génération actifs utilisent les modèles ouverts hébergés dans le projet :
Wan 2.2, Qwen 2.5, OpenVoice V2, LatentSync 1.5, SDXL, Faster-Whisper et Kokoro.
Google Cloud fournit l'infrastructure (Cloud Run, GCS, Firestore, Cloud Tasks).
Les anciens chemins Gemini/Live/Omni restent désactivés dans cette configuration.
Le rendu est plafonné côté serveur à 30 secondes par la configuration de déploiement.
"""

import asyncio
import base64
import hashlib
import hmac
import ipaddress
import socket
import threading
import urllib.parse
import urllib.request
import urllib.error
import difflib
import json
import io
import logging
import math
import os
import re
import shutil
import subprocess
import time
import uuid
from datetime import datetime, timedelta, timezone
from functools import partial
from typing import Any, Dict, List, Literal, Optional, Tuple

from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, Request, UploadFile, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from google import genai
from google.genai import types as genai_types
from google.cloud import firestore, speech, storage, texttospeech, tasks_v2
from google.oauth2 import id_token
from google.auth import default as google_auth_default
from google.auth.transport.requests import Request as GoogleAuthRequest
from google.auth.transport.requests import Request as GoogleCredentialsRequest
from PIL import Image, ImageDraw, ImageFont, ImageOps
from pydantic import BaseModel, Field, field_validator

# =========================================================================
# CONFIGURATION & LOGGING STRUCTURÉ
# =========================================================================
logging.basicConfig(
    level=logging.INFO,
    format='{"time": "%(asctime)s", "level": "%(levelname)s", "logger": "%(name)s", "message": "%(message)s"}',
)
logger = logging.getLogger("genia-apex-core")


class DialogueTranscriptMismatchError(RuntimeError):
    """Échec explicite uniquement après transcription Google réussie mais fortement différente."""


GCP_PROJECT_ID = os.getenv("GCP_PROJECT_ID", os.getenv("GOOGLE_CLOUD_PROJECT", "genia-apex-prod"))
GCP_LOCATION = os.getenv("GCP_LOCATION", "us-central1")
GCS_BUCKET_NAME = os.getenv("GCS_BUCKET_NAME", f"{GCP_PROJECT_ID}-genia-media")
FIRESTORE_COLLECTION_JOBS = os.getenv("FIRESTORE_COLLECTION_JOBS", "genia_jobs")
FIRESTORE_COLLECTION_WALLETS = os.getenv("FIRESTORE_COLLECTION_WALLETS", "genia_wallets")
FIRESTORE_COLLECTION_TEMPLATES = os.getenv("FIRESTORE_COLLECTION_TEMPLATES", "genia_templates")

GEMINI_TEXT_MODEL = os.getenv("GEMINI_TEXT_MODEL", "")  # désactivé: modèles locaux
GEMINI_VIDEO_ANALYSIS_MODEL = os.getenv("GEMINI_VIDEO_ANALYSIS_MODEL", "")  # désactivé
GEMINI_VIRALITY_MODEL = os.getenv("GEMINI_VIRALITY_MODEL", "")  # désactivé
GEMINI_OMNI_VIDEO_MODEL = os.getenv("GEMINI_OMNI_VIDEO_MODEL", "")  # remplacé par Wan
ENABLE_GEMINI_OMNI_NATIVE_AVATAR = False  # chemin payant désactivé; génération locale Wan
# Google réserve Live Avatar et les voix personnalisées à des projets autorisés.
ENABLE_GEMINI_LIVE_AVATAR = False  # chemin payant désactivé
GEMINI_LIVE_AVATAR_MODEL = os.getenv("GEMINI_LIVE_AVATAR_MODEL", "gemini-3.8-live")
GEMINI_OMNI_VIDEO_RESOLUTION = os.getenv("GEMINI_OMNI_VIDEO_RESOLUTION", "720p")
GEMINI_IMAGE_MODEL = "local-sdxl"
VOICE_TTS_MODEL = "local-kokoro-openvoice"
VOICE_SOURCE_MAX_BYTES = int(os.getenv("VOICE_SOURCE_MAX_BYTES", str(25 * 1024 * 1024)))
ENABLE_GOOGLE_SEARCH_GROUNDING = False  # pas de requête Gemini/Google Search payante
ENABLE_GEMINI_VIDEO_HIGHLIGHTS = False  # analyse locale à utiliser; pas de modèle Gemini
ENABLE_GEMINI_PHOTO_EDITING = True  # édition locale SDXL
VEO_VIDEO_MODEL = "Wan2.2-TI2V-5B"
GENIA_AUTH_SECRET = os.getenv("GENIA_AUTH_SECRET", "")
GENIA_JWT_ISSUER = os.getenv("GENIA_JWT_ISSUER", "base44")
GENIA_JWT_AUDIENCE = os.getenv("GENIA_JWT_AUDIENCE", "genia-apex")

MAX_CONCURRENT_RENDERS = int(os.getenv("MAX_CONCURRENT_RENDERS", "4"))
MAX_VIDEO_DURATION_SEC = float(os.getenv("MAX_VIDEO_DURATION_SEC", "600.0"))
MAX_DOWNLOAD_BYTES = int(os.getenv("MAX_DOWNLOAD_BYTES", str(120 * 1024 * 1024)))
CREDIT_VALIDITY_DAYS = int(os.getenv("CREDIT_VALIDITY_DAYS", "30"))
FREE_DAILY_FREE_RENDERS = int(os.getenv("FREE_DAILY_FREE_RENDERS", "15"))
FREE_TIER_MAX_DURATION_SEC = float(os.getenv("FREE_TIER_MAX_DURATION_SEC", "45.0"))
LOCAL_MEDIA_ROOT = os.getenv("LOCAL_MEDIA_ROOT", "/tmp/genia_media_vault")
CORS_ALLOWED_ORIGINS = [x.strip() for x in os.getenv("CORS_ALLOWED_ORIGINS", "").split(",") if x.strip()]
REQUIRE_CLOUD_STATE = os.getenv("REQUIRE_CLOUD_STATE", "true").lower() == "true"
FFMPEG_TIMEOUT_SECONDS = int(os.getenv("FFMPEG_TIMEOUT_SECONDS", "900"))
MAX_SCENES_PER_REQUEST = int(os.getenv("MAX_SCENES_PER_REQUEST", "20"))
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "").rstrip("/")
CLOUD_TASKS_QUEUE = os.getenv("CLOUD_TASKS_QUEUE", "genia-render-queue")
CLOUD_TASKS_LOCATION = os.getenv("CLOUD_TASKS_LOCATION", GCP_LOCATION)
CLOUD_TASKS_SERVICE_URL = os.getenv("CLOUD_TASKS_SERVICE_URL", "").rstrip("/")
CLOUD_TASKS_SERVICE_ACCOUNT = os.getenv("CLOUD_TASKS_SERVICE_ACCOUNT", "")
if not PUBLIC_BASE_URL and CLOUD_TASKS_SERVICE_URL:
    PUBLIC_BASE_URL = CLOUD_TASKS_SERVICE_URL

os.makedirs(LOCAL_MEDIA_ROOT, exist_ok=True)

RENDER_SEMAPHORE = asyncio.Semaphore(MAX_CONCURRENT_RENDERS)

_LOCAL_JOB_STORE: Dict[str, dict] = {}
_LOCAL_WALLET_STORE: Dict[str, dict] = {}
_LOCAL_TEMPLATES_STORE: List[dict] = []

app = FastAPI(
    title="Genia Apex Studio",
    version="2026.11.23-gcp3",
    description="Moteur vidéo Google Cloud : Gemini, Gemini Omni, Veo, TTS, Speech-to-Text, édition photo générative, analyse vidéo agentique, montage et stockage.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _utc_now_iso() -> str:
    return _utc_now().isoformat()


async def run_in_executor(func, *args, **kwargs):
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, partial(func, *args, **kwargs))


class ApexCloudTelemetry:
    """Émet des événements JSON structurés pour le suivi d'exécution."""

    @staticmethod
    def emit(severity: str, event: str, job_id: Optional[str] = None, user_id: Optional[str] = None, **extra):
        payload = {
            "severity": severity.upper(),
            "event": event,
            "job_id": job_id,
            "user_id": user_id,
            "timestamp": _utc_now_iso(),
            **extra,
        }
        line = json.dumps(payload, ensure_ascii=False)
        sev = severity.upper()
        if sev in ("ERROR", "CRITICAL"):
            logger.error(line)
        elif sev == "WARNING":
            logger.warning(line)
        else:
            logger.info(line)


class ApexSelfHealingEngine:
    """Diagnostic et auto-récupération prudente des opérations Genia.

    Par sécurité, le moteur ne modifie jamais le code, les modèles, les fichiers
    utilisateur, les crédits ou la configuration cloud. Il classe les erreurs,
    applique uniquement des réparations explicitement enregistrées par le code,
    puis vérifie le résultat en réexécutant l'opération.
    """

    _repair_handlers: Dict[str, Any] = {}
    _stats = {"diagnosed": 0, "repaired": 0, "unrecoverable": 0, "retries": 0}

    @classmethod
    def register_repair(cls, error_code: str, handler):
        """Enregistre une réparation locale, déterministe et approuvée par le développeur."""
        if not re.fullmatch(r"[a-z][a-z0-9_]{1,63}", error_code):
            raise ValueError("Code de réparation invalide.")
        if not callable(handler):
            raise TypeError("Le gestionnaire de réparation doit être appelable.")
        cls._repair_handlers[error_code] = handler

    @staticmethod
    def diagnose(exc: Exception) -> dict:
        message = str(exc).lower()
        name = type(exc).__name__.lower()
        text_value = f"{name}: {message}"
        # Erreurs transitoires seulement : une nouvelle tentative peut réussir sans
        # changer les données ni les paramètres de l'utilisateur.
        transient_terms = (
            "timeout", "timed out", "temporarily unavailable", "temporary failure",
            "connection reset", "connection aborted", "connection refused",
            "service unavailable", "internal server error", "429", "503", "504",
            "resource exhausted", "rate limit", "deadline exceeded",
        )
        if any(term in text_value for term in transient_terms):
            return {"code": "transient_service_error", "recoverable": True,
                    "action": "retry_with_backoff", "reason": "Erreur réseau, surcharge ou indisponibilité temporaire."}
        if "permission" in text_value or "unauthorized" in text_value or "forbidden" in text_value or "401" in text_value or "403" in text_value:
            return {"code": "permission_or_auth_error", "recoverable": False,
                    "action": "manual_configuration", "reason": "Vérifier IAM, les identifiants et les autorisations Google Cloud."}
        if "quota" in text_value or "billing" in text_value or "insufficient" in text_value:
            return {"code": "quota_or_billing_error", "recoverable": False,
                    "action": "manual_configuration", "reason": "Vérifier les quotas, la facturation et les limites du projet."}
        if isinstance(exc, (ValueError, TypeError, KeyError)):
            return {"code": "invalid_input_or_configuration", "recoverable": False,
                    "action": "validate_request", "reason": "Une donnée ou un paramètre est invalide; aucune correction automatique sûre n'est déductible."}
        return {"code": "unknown_error", "recoverable": False,
                "action": "manual_review", "reason": "Cause non reconnue; intervention requise pour éviter une modification risquée."}

    @classmethod
    def _record_failure(cls, exc: Exception, label: str, attempt: int, max_attempts: int):
        diagnosis = cls.diagnose(exc)
        cls._stats["diagnosed"] += 1
        ApexCloudTelemetry.emit(
            "WARNING" if diagnosis["recoverable"] else "ERROR",
            "self_healing_diagnosis", label=label, attempt=attempt,
            max_attempts=max_attempts, error_code=diagnosis["code"],
            recoverable=diagnosis["recoverable"], suggested_action=diagnosis["action"],
            reason=diagnosis["reason"], error=str(exc)[:220],
        )
        return diagnosis

    @classmethod
    def status(cls) -> dict:
        return {**cls._stats, "registered_repairs": sorted(cls._repair_handlers.keys()),
                "mode": "safe_diagnosis_retry_and_verified_registered_repairs"}

    @classmethod
    def _try_repair(cls, diagnosis: dict, exc: Exception, context: dict) -> bool:
        handler = cls._repair_handlers.get(diagnosis["code"])
        if handler is None:
            return False
        try:
            result = handler(exc=exc, context=context)
            if result is False:
                return False
            cls._stats["repaired"] += 1
            ApexCloudTelemetry.emit("WARNING", "self_healing_repair_applied",
                                    error_code=diagnosis["code"], context=context)
            return True
        except Exception as repair_exc:
            ApexCloudTelemetry.emit("ERROR", "self_healing_repair_failed",
                                    error_code=diagnosis["code"], error=str(repair_exc)[:220])
            return False


class ApexResilienceGuard:
    """Exécution résiliente pilotée par le diagnostic Self-Healing."""

    @staticmethod
    def retry_sync(func, retries: int = 3, delay_sec: float = 1.0, label: str = "op"):
        attempts = max(1, min(int(retries), 5))
        last_exc = None
        for attempt in range(1, attempts + 1):
            try:
                result = func()
                ApexCloudTelemetry.emit("INFO", "self_healing_operation_verified", label=label, attempt=attempt)
                return result
            except Exception as exc:
                last_exc = exc
                diagnosis = ApexSelfHealingEngine._record_failure(exc, label, attempt, attempts)
                repaired = ApexSelfHealingEngine._try_repair(diagnosis, exc, {"label": label, "attempt": attempt})
                if not diagnosis["recoverable"] and not repaired:
                    ApexSelfHealingEngine._stats["unrecoverable"] += 1
                    raise
                if attempt < attempts:
                    ApexSelfHealingEngine._stats["retries"] += 1
                    sleep_for = min(max(0.1, float(delay_sec)) * (2 ** (attempt - 1)), 20.0)
                    ApexCloudTelemetry.emit("WARNING", "self_healing_retry", label=label,
                                            attempt=attempt, retries=attempts, sleep_sec=sleep_for,
                                            repair_applied=repaired, error=str(exc)[:220])
                    time.sleep(sleep_for)
                elif not repaired:
                    ApexSelfHealingEngine._stats["unrecoverable"] += 1
        raise last_exc

    @staticmethod
    async def retry_async(func, retries: int = 3, delay_sec: float = 1.0, label: str = "op_async"):
        attempts = max(1, min(int(retries), 5))
        last_exc = None
        for attempt in range(1, attempts + 1):
            try:
                result = await func()
                ApexCloudTelemetry.emit("INFO", "self_healing_operation_verified", label=label, attempt=attempt)
                return result
            except Exception as exc:
                last_exc = exc
                diagnosis = ApexSelfHealingEngine._record_failure(exc, label, attempt, attempts)
                repaired = ApexSelfHealingEngine._try_repair(diagnosis, exc, {"label": label, "attempt": attempt})
                if not diagnosis["recoverable"] and not repaired:
                    ApexSelfHealingEngine._stats["unrecoverable"] += 1
                    raise
                if attempt < attempts:
                    ApexSelfHealingEngine._stats["retries"] += 1
                    sleep_for = min(max(0.1, float(delay_sec)) * (2 ** (attempt - 1)), 20.0)
                    ApexCloudTelemetry.emit("WARNING", "self_healing_retry", label=label,
                                            attempt=attempt, retries=attempts, sleep_sec=sleep_for,
                                            repair_applied=repaired, error=str(exc)[:220])
                    await asyncio.sleep(sleep_for)
                elif not repaired:
                    ApexSelfHealingEngine._stats["unrecoverable"] += 1
        raise last_exc


# =========================================================================
# FOURNISSEUR IA LOCAL (aucune API IA tierce facturée à la génération)
# =========================================================================
GENIA_LOCAL_AI_URL = os.getenv("GENIA_LOCAL_AI_URL", "http://127.0.0.1:8090").rstrip("/")
GENIA_LOCAL_AI_TOKEN = os.getenv("GENIA_LOCAL_AI_TOKEN", "")
GENIA_LOCAL_AI_TIMEOUT = float(os.getenv("GENIA_LOCAL_AI_TIMEOUT", "3600"))


def _local_ai_headers() -> dict:
    headers = {}
    if GENIA_LOCAL_AI_TOKEN:
        headers["Authorization"] = f"Bearer {GENIA_LOCAL_AI_TOKEN}"
    return headers


def _local_ai_json(path: str, payload: dict, timeout: Optional[float] = None) -> dict:
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        GENIA_LOCAL_AI_URL + path, data=body,
        headers={"Content-Type": "application/json", **_local_ai_headers()}, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout or GENIA_LOCAL_AI_TIMEOUT) as response:
            data = json.loads(response.read().decode("utf-8"))
    except Exception as exc:
        raise RuntimeError(f"Moteur IA local indisponible ({path}): {exc}") from exc
    if not isinstance(data, dict):
        raise RuntimeError(f"Réponse invalide du moteur IA local ({path}).")
    return data


def _local_ai_multipart(path: str, fields: dict, file_field: str, file_path: str,
                        file_name: Optional[str] = None, timeout: Optional[float] = None) -> dict:
    boundary = "----GeniaApex" + uuid.uuid4().hex
    chunks = []
    for key, value in fields.items():
        chunks.extend([f"--{boundary}\r\n".encode(),
                       f'Content-Disposition: form-data; name="{key}"\r\n\r\n'.encode(),
                       str(value).encode("utf-8"), b"\r\n"])
    mime = "application/octet-stream"
    ext = os.path.splitext(file_path)[1].lower()
    if ext in {".png"}: mime = "image/png"
    elif ext in {".jpg", ".jpeg"}: mime = "image/jpeg"
    elif ext in {".wav"}: mime = "audio/wav"
    elif ext in {".mp3"}: mime = "audio/mpeg"
    elif ext in {".mp4"}: mime = "video/mp4"
    name = file_name or os.path.basename(file_path)
    with open(file_path, "rb") as handle:
        raw = handle.read()
    chunks.extend([f"--{boundary}\r\n".encode(),
                   f'Content-Disposition: form-data; name="{file_field}"; filename="{name}"\r\n'.encode(),
                   f"Content-Type: {mime}\r\n\r\n".encode(), raw, b"\r\n",
                   f"--{boundary}--\r\n".encode()])
    req = urllib.request.Request(GENIA_LOCAL_AI_URL + path, data=b"".join(chunks),
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}", **_local_ai_headers()}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout or GENIA_LOCAL_AI_TIMEOUT) as response:
            return json.loads(response.read().decode("utf-8"))
    except Exception as exc:
        raise RuntimeError(f"Moteur IA local indisponible ({path}): {exc}") from exc


def _local_ai_multipart_two_files(path: str, fields: dict, file1_field: str, file1_path: str,
                                 file2_field: str, file2_path: str, timeout: Optional[float] = None) -> dict:
    boundary = "----GeniaApex" + uuid.uuid4().hex
    chunks = []
    for key, value in fields.items():
        chunks.extend([f"--{boundary}\r\n".encode(),
                       f'Content-Disposition: form-data; name="{key}"\r\n\r\n'.encode(),
                       str(value).encode("utf-8"), b"\r\n"])
    def add_file(field, file_path):
        ext=os.path.splitext(file_path)[1].lower()
        mime={".mp4":"video/mp4",".wav":"audio/wav",".mp3":"audio/mpeg"}.get(ext,"application/octet-stream")
        with open(file_path,"rb") as handle: raw=handle.read()
        chunks.extend([f"--{boundary}\r\n".encode(),
                       f'Content-Disposition: form-data; name="{field}"; filename="{os.path.basename(file_path)}"\r\n'.encode(),
                       f"Content-Type: {mime}\r\n\r\n".encode(), raw, b"\r\n"])
    add_file(file1_field,file1_path); add_file(file2_field,file2_path)
    chunks.append(f"--{boundary}--\r\n".encode())
    req=urllib.request.Request(GENIA_LOCAL_AI_URL+path,data=b"".join(chunks),
        headers={"Content-Type":f"multipart/form-data; boundary={boundary}",**_local_ai_headers()},method="POST")
    try:
        with urllib.request.urlopen(req,timeout=timeout or GENIA_LOCAL_AI_TIMEOUT) as response:
            return json.loads(response.read().decode("utf-8"))
    except Exception as exc:
        raise RuntimeError(f"Moteur IA local indisponible ({path}): {exc}") from exc


def _copy_local_artifact(response: dict, output_path: str) -> str:
    """Fetch a worker output from the shared GCS bucket (or same-host path in dev)."""
    local_path = response.get("artifact_path") or response.get("audio_path") or response.get("image_path") or response.get("video_path")
    if local_path and os.path.isfile(str(local_path)):
        shutil.copyfile(str(local_path), output_path)
        return output_path
    uri = str(response.get("gcs_uri") or "")
    parsed = urllib.parse.urlparse(uri)
    if parsed.scheme == "gs" and parsed.netloc and parsed.path.lstrip("/") and storage_client:
        blob = storage_client.bucket(parsed.netloc).blob(parsed.path.lstrip("/"))
        blob.download_to_filename(output_path)
        if not os.path.isfile(output_path) or os.path.getsize(output_path) < 64:
            raise RuntimeError("Le fichier téléchargé depuis le worker local est vide.")
        # Worker outputs are temporary; voice-profile embeddings use a separate permanent prefix.
        try:
            _local_ai_json("/v1/artifacts/delete", {"gcs_uri": uri}, timeout=30)
        except Exception as cleanup_error:
            logger.warning("temporary worker artifact cleanup failed: %s", str(cleanup_error)[:180])
        return output_path
    raise RuntimeError("Le worker local n'a pas retourné un chemin local accessible ou un URI GCS valide.")


def _local_chat_text(prompt: str, temperature: float = 0.4, max_tokens: int = 1800) -> str:
    data = _local_ai_json("/v1/chat/completions", {
        "model": "Qwen2.5-3B-Instruct", "messages": [{"role": "user", "content": prompt}],
        "temperature": temperature, "max_tokens": max_tokens
    })
    choices = data.get("choices") or []
    if not choices:
        raise RuntimeError("Qwen local n'a retourné aucune réponse.")
    return str((choices[0].get("message") or {}).get("content") or "").strip()


# =========================================================================
# INITIALISATION DES CLIENTS CLOUD
# =========================================================================
def _init_genai_client() -> Optional[genai.Client]:
    """Client Gemini/Imagen/Veo via Vertex AI dans le projet Google Cloud Genia."""
    try:
        return genai.Client(vertexai=True, project=GCP_PROJECT_ID, location=GCP_LOCATION)
    except Exception as exc:
        ApexCloudTelemetry.emit("WARNING", "vertex_ai_client_init_warning", error=str(exc)[:240])
        return None


def _init_search_genai_client():
    """Client Gemini en région globale pour le grounding Google Search."""
    try:
        return genai.Client(vertexai=True, project=GCP_PROJECT_ID, location="global")
    except Exception as exc:
        ApexCloudTelemetry.emit("WARNING", "search_genai_client_init_warning", error=str(exc)[:220])
        return None


def _init_voice_genai_client():
    """Client Gemini TTS/Voice Replication, API v1beta1 en location global."""
    try:
        return genai.Client(enterprise=True, project=GCP_PROJECT_ID, location="global")
    except Exception as exc:
        ApexCloudTelemetry.emit("WARNING", "voice_genai_client_init_warning", error=str(exc)[:220])
        return None


def _init_firestore_client() -> Optional[firestore.Client]:
    try:
        return firestore.Client(project=GCP_PROJECT_ID)
    except Exception as exc:
        ApexCloudTelemetry.emit("WARNING", "firestore_init_warning", error=str(exc)[:240])
        return None


def _init_storage_client() -> Optional[storage.Client]:
    try:
        return storage.Client(project=GCP_PROJECT_ID)
    except Exception as exc:
        ApexCloudTelemetry.emit("WARNING", "storage_init_warning", error=str(exc)[:240])
        return None


def _init_tts_client() -> Optional[texttospeech.TextToSpeechClient]:
    try:
        return texttospeech.TextToSpeechClient()
    except Exception as exc:
        ApexCloudTelemetry.emit("WARNING", "tts_init_warning", error=str(exc)[:240])
        return None


def _init_stt_client() -> Optional[speech.SpeechClient]:
    try:
        return speech.SpeechClient()
    except Exception as exc:
        ApexCloudTelemetry.emit("WARNING", "stt_init_warning", error=str(exc)[:240])
        return None


# Google Gemini/Live/Omni/voice-replication are intentionally not initialized:
# all user-facing generation paths are routed to the local worker in this build.
genai_client = None
search_genai_client = None
voice_genai_client = None
firestore_client = _init_firestore_client()
storage_client = _init_storage_client()
tts_client = None
stt_client = None
try:
    cloud_tasks_client = tasks_v2.CloudTasksClient()
except Exception as _tasks_init_error:
    cloud_tasks_client = None
    ApexCloudTelemetry.emit("WARNING", "cloud_tasks_init_warning", error=str(_tasks_init_error)[:200])


def _validate_media_file(path: str) -> None:
    if not os.path.isfile(path) or os.path.getsize(path) <= 0:
        raise RuntimeError("Fichier média absent ou vide.")
    ext=os.path.splitext(path)[1].lower()
    if ext in (".mp4",".mov",".m4v",".webm"):
        proc=subprocess.run(["ffprobe","-v","error","-show_entries","stream=codec_type,width,height","-show_entries","format=duration","-of","json",path],
                            capture_output=True,text=True,timeout=45)
        if proc.returncode!=0: raise RuntimeError("Le fichier vidéo final n'est pas décodable par FFprobe.")
        data=json.loads(proc.stdout or "{}")
        streams=data.get("streams") or []
        if not any(x.get("codec_type")=="video" for x in streams): raise RuntimeError("Le fichier final ne contient aucun flux vidéo.")
        duration=float((data.get("format") or {}).get("duration") or 0)
        if duration<=0: raise RuntimeError("Durée vidéo finale invalide.")
    elif ext in (".jpg",".jpeg",".png",".webp"):
        with Image.open(path) as im: im.verify()
    elif ext in (".mp3",".wav",".m4a",".aac"):
        proc=subprocess.run(["ffprobe","-v","error","-select_streams","a:0","-show_entries","stream=codec_type","-of","csv=p=0",path],capture_output=True,text=True,timeout=30)
        if proc.returncode!=0 or not proc.stdout.strip(): raise RuntimeError("Fichier audio invalide ou sans piste audio.")


def ensure_bucket_and_upload(local_path: str, blob_name: str, job_id: str) -> str:
    """Valide le fichier final puis l'enregistre dans le bucket privé Google Cloud Storage."""
    _validate_media_file(local_path)
    safe_rel = os.path.normpath(blob_name).lstrip("/").replace("..", "")
    vault_path = os.path.join(LOCAL_MEDIA_ROOT, safe_rel)
    os.makedirs(os.path.dirname(vault_path), exist_ok=True)
    if os.path.abspath(local_path) != os.path.abspath(vault_path) and os.path.exists(local_path):
        shutil.copyfile(local_path, vault_path)

    if not storage_client:
        if REQUIRE_CLOUD_STATE: raise RuntimeError("Cloud Storage indisponible; aucun stockage local éphémère ne sera utilisé en production.")
        local_route = f"/api/v1/media/{safe_rel}"
        return f"{PUBLIC_BASE_URL}{local_route}" if PUBLIC_BASE_URL else local_route

    def _upload():
        bucket = storage_client.bucket(GCS_BUCKET_NAME)
        try:
            if not bucket.exists():
                bucket.create(location=GCP_LOCATION)
        except Exception:
            pass
        blob = bucket.blob(blob_name)
        blob.upload_from_filename(vault_path)
        return blob

    try:
        blob = ApexResilienceGuard.retry_sync(_upload, retries=3, delay_sec=1.2, label="gcs_upload")
        return generate_media_url(blob, job_id)
    except Exception as exc:
        ApexCloudTelemetry.emit(
            "WARNING",
            "gcs_upload_local_vault_fallback",
            job_id=job_id,
            blob_name=safe_rel,
            error=str(exc)[:200],
        )
        if REQUIRE_CLOUD_STATE:
            raise RuntimeError("Échec d'envoi vers Google Cloud Storage; média non publié.") from exc
        local_route = f"/api/v1/media/{safe_rel}"
        return f"{PUBLIC_BASE_URL}{local_route}" if PUBLIC_BASE_URL else local_route


def generate_media_url(blob, job_id: str) -> str:
    """Lien de lecture signé par Genia; le bucket GCS reste privé."""
    if not GENIA_AUTH_SECRET:
        raise RuntimeError("GENIA_AUTH_SECRET requis pour signer les liens médias.")
    expiry=int(time.time())+7*24*3600
    signature=hmac.new(GENIA_AUTH_SECRET.encode(),f"{blob.name}:{expiry}".encode(),hashlib.sha256).hexdigest()
    route=f"/api/v1/media/gcs/{urllib.parse.quote(blob.name,safe='/')}?exp={expiry}&sig={signature}"
    return f"{PUBLIC_BASE_URL}{route}" if PUBLIC_BASE_URL else route


# =========================================================================
# CATALOGUES : AVATARS (3D & HUMAINS), VOIX, FILTRES, STICKERS, MODÈLES
# =========================================================================
AVATAR_MODELS_CATALOG: Dict[str, dict] = {
    "leo_express": {
        "avatar_id": "leo_express",
        "name": "Léo Express",
        "category": "avatar_3d",
        "role": "narrateur",
        "style_badge": "3D Dynamique",
        "voice_name": "fr-FR-Chirp3-HD-Puck",
        "fallback_voice": "fr-FR-Neural2-B",
        "default_gesture": "Gestes énergiques des mains, expression vive et dynamique, idéal storytelling et astuces",
        "avatar_description": (
            "Expressive stylized 3D animated male narrator character with tousled dark hair, modern casual jacket, "
            "warm studio rim lighting, natural lip-sync talking motion, and energetic hand gestures"
        ),
    },
    "ines_studio": {
        "avatar_id": "ines_studio",
        "name": "Inès Studio",
        "category": "avatar_3d",
        "role": "expert",
        "style_badge": "3D Éditorial",
        "voice_name": "fr-FR-Chirp3-HD-Leda",
        "fallback_voice": "fr-FR-Neural2-A",
        "default_gesture": "Posture claire et confiante, gestes pédagogiques mesurés, idéal business et conseils",
        "avatar_description": (
            "Polished stylized 3D female expert host with sleek bob haircut, smart modern blazer, "
            "clean studio lighting, attentive eye contact, natural speaking expressions and explanatory hand movements"
        ),
    },
    "kofi_coach": {
        "avatar_id": "kofi_coach",
        "name": "Kofi Coach",
        "category": "avatar_3d",
        "role": "proche",
        "style_badge": "3D Motivant",
        "voice_name": "fr-FR-Chirp3-HD-Charon",
        "fallback_voice": "fr-FR-Neural2-D",
        "default_gesture": "Sourire encourageant, mouvements amples et motivants, idéal fitness et dépassement de soi",
        "avatar_description": (
            "Charismatic stylized 3D male coach character with athletic build, short fade haircut, sporty hoodie, "
            "bright uplifting studio lighting, animated facial reactions and motivating gestures"
        ),
    },
    "nadia_crea": {
        "avatar_id": "nadia_crea",
        "name": "Nadia Créa",
        "category": "avatar_3d",
        "role": "femme",
        "style_badge": "3D Pop",
        "voice_name": "fr-FR-Chirp3-HD-Aoede",
        "fallback_voice": "fr-FR-Neural2-C",
        "default_gesture": "Réactions expressives, sourire spontané et gestes vivants, idéal lifestyle et tendances",
        "avatar_description": (
            "Vibrant stylized 3D female creator avatar with curly dark hair, trendy streetwear, "
            "colorful soft studio lighting, expressive eyebrows and lively talking gestures"
        ),
    },
    "marc_tech": {
        "avatar_id": "marc_tech",
        "name": "Marc Tech",
        "category": "avatar_3d",
        "role": "mari",
        "style_badge": "3D Minimal",
        "voice_name": "fr-FR-Chirp3-HD-Fenrir",
        "fallback_voice": "fr-FR-Neural2-E",
        "default_gesture": "Ton calme et précis, gestes structurés, idéal tutoriels, tech et explications claires",
        "avatar_description": (
            "Clean stylized 3D male tech presenter with neat hair, minimalist dark crew-neck sweater, "
            "balanced studio lighting, calm articulate lip movement and clear explanatory gestures"
        ),
    },
    "camille_humain": {
        "avatar_id": "camille_humain",
        "name": "Camille Réaliste",
        "category": "human_avatar",
        "role": "femme",
        "style_badge": "Humain Réaliste",
        "voice_name": "fr-FR-Chirp3-HD-Kore",
        "fallback_voice": "fr-FR-Neural2-A",
        "default_gesture": "Présence humaine naturelle, regard caméra direct, sourires et gestes subtils",
        "avatar_description": (
            "Photorealistic young French woman speaking directly to camera in a warm modern studio, "
            "natural skin texture, authentic micro-expressions, subtle hand gestures, shallow depth of field, 4K realistic look"
        ),
    },
    "idriss_humain": {
        "avatar_id": "idriss_humain",
        "name": "Idriss Réaliste",
        "category": "human_avatar",
        "role": "narrateur",
        "style_badge": "Humain Réaliste",
        "voice_name": "fr-FR-Chirp3-HD-Orus",
        "fallback_voice": "fr-FR-Neural2-B",
        "default_gesture": "Discours posé et percutant, gestes naturels, idéal storytelling et témoignages",
        "avatar_description": (
            "Photorealistic West African male presenter in a contemporary creative room, natural warm lighting, "
            "authentic talking lip-sync, expressive eyes and natural conversational hand gestures, realistic film look"
        ),
    },
    "claire_humain": {
        "avatar_id": "claire_humain",
        "name": "Claire Experte",
        "category": "human_avatar",
        "role": "expert",
        "style_badge": "Humain Réaliste",
        "voice_name": "fr-FR-Chirp3-HD-Zephyr",
        "fallback_voice": "fr-FR-Neural2-C",
        "default_gesture": "Communication claire et rassurante, posture professionnelle, idéal formation et marque",
        "avatar_description": (
            "Photorealistic woman in her early 30s wearing a clean linen shirt in a sunlit studio, "
            "articulate natural speech, warm smile, subtle hand movements, realistic camera framing"
        ),
    },
}

ROLE_VOICE_MAP: Dict[str, Tuple[str, str]] = {
    "narrateur": ("fr-FR-Chirp3-HD-Puck", "fr-FR-Neural2-B"),
    "femme": ("fr-FR-Chirp3-HD-Aoede", "fr-FR-Neural2-A"),
    "mari": ("fr-FR-Chirp3-HD-Fenrir", "fr-FR-Neural2-D"),
    "proche": ("fr-FR-Chirp3-HD-Charon", "fr-FR-Neural2-E"),
    "expert": ("fr-FR-Chirp3-HD-Leda", "fr-FR-Neural2-C"),
}

CAMERA_PRESETS_CATALOG: Dict[str, dict] = {
    "cam_zoom_hook": {
        "camera_preset_id": "cam_zoom_hook",
        "name": "Zoom Accroche CapCut",
        "category": "zoom",
        "zoom_factor": 1.24,
        "description": "Recadrage numérique rapproché; pas de détection automatique du hook",
    },
    "cam_pulse_beat": {
        "camera_preset_id": "cam_pulse_beat",
        "name": "Zoom Pulsé Rythme",
        "category": "zoom",
        "zoom_factor": 1.18,
        "description": "Niveau de zoom numérique fixe; pas de synchronisation au rythme audio",
    },
    "cam_cinematic_breath": {
        "camera_preset_id": "cam_cinematic_breath",
        "name": "Mouvement Vlog Doux",
        "category": "vlog",
        "zoom_factor": 1.12,
        "description": "Zoom numérique léger et fixe pour un cadrage vlog",
    },
    "cam_dramatic_punch": {
        "camera_preset_id": "cam_dramatic_punch",
        "name": "Punch Zoom Direct",
        "category": "impact",
        "zoom_factor": 1.32,
        "description": "Zoom numérique marqué et fixe",
    },
    "cam_shake_energy": {
        "camera_preset_id": "cam_shake_energy",
        "name": "Caméra Énergie Live",
        "category": "fun",
        "zoom_factor": 1.16,
        "description": "Zoom numérique fixe; aucun tremblement de caméra simulé",
    },
    "cam_smooth_pullback": {
        "camera_preset_id": "cam_smooth_pullback",
        "name": "Dézoom Ouverture",
        "category": "vlog",
        "zoom_factor": 1.15,
        "description": "Zoom numérique fixe; le dézoom progressif n'est pas activé dans ce moteur",
    },
}

PHOTO_MODELS_CATALOG: Dict[str, dict] = {
    "pm_snap_neon_frame": {"photo_model_id": "pm_snap_neon_frame", "name": "Cadre Néon Street", "category": "snap_style", "border_color": (168, 85, 247, 255)},
    "pm_polaroid_souvenir": {"photo_model_id": "pm_polaroid_souvenir", "name": "Album Polaroid Souvenir", "category": "souvenirs", "border_color": (248, 250, 252, 255)},
    "pm_hype_flash_beat": {"photo_model_id": "pm_hype_flash_beat", "name": "Flash Hype Rapide", "category": "viral_beat", "border_color": (236, 72, 153, 255)},
    "pm_cinema_dore": {"photo_model_id": "pm_cinema_dore", "name": "Écrin Cinéma Or", "category": "editorial", "border_color": (245, 158, 11, 255)},
    "pm_arcade_score": {"photo_model_id": "pm_arcade_score", "name": "Arène Jeu & Score", "category": "gaming", "border_color": (56, 189, 248, 255)},
    "pm_glow_beaute": {"photo_model_id": "pm_glow_beaute", "name": "Studio Éclat Beauté", "category": "beaute", "border_color": (244, 114, 182, 255)},
    "pm_bd_bulle_fun": {"photo_model_id": "pm_bd_bulle_fun", "name": "BD Fun & Réactions", "category": "fun", "border_color": (250, 204, 21, 255)},
    "pm_story_journal": {"photo_model_id": "pm_story_journal", "name": "Carnet du Jour", "category": "storytelling", "border_color": (52, 211, 153, 255)},
    "pm_spotlight_duo": {"photo_model_id": "pm_spotlight_duo", "name": "Duo / Comparatif", "category": "comparison", "border_color": (129, 140, 248, 255)},
    "pm_night_club_pulse": {"photo_model_id": "pm_night_club_pulse", "name": "Soirée & Lumières", "category": "snap_style", "border_color": (192, 132, 252, 255)},
    "pm_minimal_pro": {"photo_model_id": "pm_minimal_pro", "name": "Vitrine Pro Épurée", "category": "business", "border_color": (226, 232, 240, 255)},
    "pm_monster_chaos": {"photo_model_id": "pm_monster_chaos", "name": "Monstre & Énergie", "category": "monstres", "border_color": (251, 113, 133, 255)},
}

FILTERS_CATALOG: Dict[str, dict] = {
    "beaute_velours_rose": {
        "filter_id": "beaute_velours_rose",
        "name": "Velours Rose",
        "category": "beaute",
        "ffmpeg_eq": "eq=brightness=0.05:contrast=1.06:saturation=1.18",
    },
    "beaute_lumiere_doree": {
        "filter_id": "beaute_lumiere_doree",
        "name": "Lumière Dorée",
        "category": "beaute",
        "ffmpeg_eq": "eq=brightness=0.06:contrast=1.08:saturation=1.15,colorbalance=rs=0.08:gs=0.03:bs=-0.06",
    },
    "beaute_aura_studio": {
        "filter_id": "beaute_aura_studio",
        "name": "Aura Studio",
        "category": "beaute",
        "ffmpeg_eq": "eq=brightness=0.04:contrast=1.10:saturation=1.08",
    },
    "monstre_bete_neon": {
        "filter_id": "monstre_bete_neon",
        "name": "Bête Néon",
        "category": "monstres",
        "ffmpeg_eq": "eq=brightness=0.02:contrast=1.22:saturation=1.35,colorbalance=rs=0.10:gs=-0.04:bs=0.14",
    },
    "monstre_titan_magma": {
        "filter_id": "monstre_titan_magma",
        "name": "Titan Magma",
        "category": "monstres",
        "ffmpeg_eq": "eq=brightness=0.01:contrast=1.20:saturation=1.30,colorbalance=rs=0.16:gs=-0.02:bs=-0.10",
    },
    "jeu_boss_cyber": {
        "filter_id": "jeu_boss_cyber",
        "name": "Boss d'Arène Cyber",
        "category": "jeux",
        "ffmpeg_eq": "eq=brightness=0.03:contrast=1.18:saturation=1.25,colorbalance=rs=-0.05:gs=0.06:bs=0.15",
    },
    "jeu_heros_arcade": {
        "filter_id": "jeu_heros_arcade",
        "name": "Héros Arcade Turbo",
        "category": "jeux",
        "ffmpeg_eq": "eq=brightness=0.05:contrast=1.16:saturation=1.28",
    },
    "fun_disco_retro": {
        "filter_id": "fun_disco_retro",
        "name": "Disco Rétro 80s",
        "category": "fun",
        "ffmpeg_eq": "eq=brightness=0.03:contrast=1.14:saturation=1.32,colorbalance=rs=0.12:gs=-0.05:bs=0.10",
    },
    "fun_fete_confettis": {
        "filter_id": "fun_fete_confettis",
        "name": "Mode Fiesta",
        "category": "fun",
        "ffmpeg_eq": "eq=brightness=0.06:contrast=1.12:saturation=1.34",
    },
}

STICKERS_CATALOG: Dict[str, dict] = {
    "sticker_haha": {"sticker_id": "sticker_haha", "label": "😂", "tag": "HAHA"},
    "sticker_heart_gift": {"sticker_id": "sticker_heart_gift", "label": "💝", "tag": "LOVE"},
    "sticker_fire": {"sticker_id": "sticker_fire", "label": "🔥", "tag": "HOT"},
    "sticker_rocket": {"sticker_id": "sticker_rocket", "label": "🚀", "tag": "VIRAL"},
    "sticker_sparkles": {"sticker_id": "sticker_sparkles", "label": "✨", "tag": "GLOW"},
    "sticker_crown": {"sticker_id": "sticker_crown", "label": "👑", "tag": "TOP"},
    "sticker_boom": {"sticker_id": "sticker_boom", "label": "💥", "tag": "BOOM"},
    "sticker_cloud_thought": {"sticker_id": "sticker_cloud_thought", "label": "💭", "tag": "IDÉE"},
}

DEFAULT_TEMPLATES: List[dict] = [
    {
        "template_id": "tpl_viral_hook_3s",
        "name": "Accroche Virale Rapide",
        "category": "viral",
        "hook_prefix": "Regarde ça avant de passer :",
        "scene_duration": 3.5,
    },
    {
        "template_id": "tpl_story_emotion",
        "name": "Récit Émotion & Impact",
        "category": "storytelling",
        "hook_prefix": "Personne ne s'attendait à ça :",
        "scene_duration": 4.0,
    },
    {
        "template_id": "tpl_top_3_tips",
        "name": "Top Astuces Express",
        "category": "education",
        "hook_prefix": "Conseil clé à retenir :",
        "scene_duration": 3.5,
    },
]

PLANS_CONFIG: Dict[str, dict] = {
    "plan_20": {
        "plan_id": "plan_20",
        "price_usd": 20,
        "credits": 40,
        "max_duration_sec": 90.0,
        "short_threshold_sec": 40.0,
        "short_cost": 2,
        "long_cost": 4,
    },
    "plan_40": {
        "plan_id": "plan_40",
        "price_usd": 40,
        "credits": 100,
        "max_duration_sec": 180.0,
        "short_threshold_sec": 60.0,
        "short_cost": 2,
        "long_cost": 4,
    },
    "plan_80": {
        "plan_id": "plan_80",
        "price_usd": 80,
        "credits": 120,
        "max_duration_sec": 600.0,
        "short_threshold_sec": 120.0,
        "short_cost": 2,
        "long_cost": 8,
    },
}


def compute_video_credit_cost(plan_id: str, duration_sec: float) -> Tuple[int, float]:
    cfg = PLANS_CONFIG.get(plan_id, PLANS_CONFIG["plan_20"])
    max_allowed = float(cfg["max_duration_sec"])
    if duration_sec > max_allowed:
        raise HTTPException(
            status_code=400,
            detail=(
                f"La durée demandée ({duration_sec:.1f}s) dépasse la limite de votre abonnement "
                f"({int(max_allowed)}s maximum pour {plan_id})."
            ),
        )
    clamped_dur = max(2.0, min(duration_sec, max_allowed))
    threshold = float(cfg["short_threshold_sec"])
    cost = int(cfg["short_cost"]) if clamped_dur <= threshold else int(cfg["long_cost"])
    return cost, clamped_dur


# =========================================================================
# SÉCURITÉ, AUTHENTIFICATION, QUOTAS GRATUITS & PERSISTANCE
# =========================================================================
def _decode_base64url(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def verify_api_token(authorization: Optional[str] = Header(None)) -> str:
    """Vérifie un JWT HS256 émis côté serveur Base44. Aucun X-User-ID non signé n'est accepté."""
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Jeton utilisateur Base44 manquant.")
    token = authorization.split(" ", 1)[1].strip()
    if len(GENIA_AUTH_SECRET) < 32:
        raise HTTPException(status_code=503, detail="GENIA_AUTH_SECRET doit contenir au moins 32 caractères.")
    try:
        header_b64, payload_b64, signature_b64 = token.split(".")
        header = json.loads(_decode_base64url(header_b64))
        claims = json.loads(_decode_base64url(payload_b64))
        if header.get("alg") != "HS256":
            raise ValueError("Algorithme JWT interdit")
        signing_input = f"{header_b64}.{payload_b64}".encode()
        expected = hmac.new(GENIA_AUTH_SECRET.encode(), signing_input, hashlib.sha256).digest()
        if not hmac.compare_digest(expected, _decode_base64url(signature_b64)):
            raise ValueError("Signature JWT invalide")
        now=int(time.time())
        exp=int(claims.get("exp",0))
        if exp <= now or exp > now + 3600:
            raise ValueError("JWT expiré ou durée supérieure à une heure")
        if claims.get("iss") != GENIA_JWT_ISSUER:
            raise ValueError("Émetteur JWT invalide")
        aud=claims.get("aud")
        if not (aud == GENIA_JWT_AUDIENCE or (isinstance(aud,list) and GENIA_JWT_AUDIENCE in aud)):
            raise ValueError("Audience JWT invalide")
        subject=str(claims.get("sub","")).strip()
        if not re.fullmatch(r"[A-Za-z0-9_@.+-]{1,120}",subject):
            raise ValueError("Identité JWT absente ou invalide")
        return subject
    except Exception as exc:
        raise HTTPException(status_code=401, detail="Jeton utilisateur invalide ou expiré.") from exc


def extract_user_id(token: str = Depends(verify_api_token)) -> str:
    # Identité dérivée exclusivement du claim sub signé par le serveur Base44.
    return token


async def _get_doc(collection_name: str, doc_id: str, fallback_map: Dict[str, dict]) -> Optional[dict]:
    if firestore_client:
        def _read():
            snap=firestore_client.collection(collection_name).document(doc_id).get()
            return snap.to_dict() if snap.exists else None
        try:
            doc=await run_in_executor(_read)
            if doc is not None: fallback_map[doc_id]=doc
            return doc
        except Exception as exc:
            ApexCloudTelemetry.emit("ERROR","firestore_read_failed",collection=collection_name,doc_id=doc_id,error=str(exc)[:180])
            if REQUIRE_CLOUD_STATE:
                raise HTTPException(status_code=503,detail="Firestore indisponible : lecture suspendue.") from exc
    if REQUIRE_CLOUD_STATE:
        raise HTTPException(status_code=503,detail="Firestore indisponible : opération suspendue pour protéger les données.")
    return fallback_map.get(doc_id)


async def _set_doc(collection_name: str, doc_id: str, data: dict, fallback_map: Dict[str, dict]) -> dict:
    if firestore_client:
        def _write():
            firestore_client.collection(collection_name).document(doc_id).set(data,merge=True)
        try:
            await run_in_executor(_write)
            fallback_map[doc_id]=data
            return data
        except Exception as exc:
            ApexCloudTelemetry.emit("ERROR","firestore_write_failed",collection=collection_name,doc_id=doc_id,error=str(exc)[:180])
            if REQUIRE_CLOUD_STATE:
                raise HTTPException(status_code=503,detail="Écriture Firestore impossible : opération non confirmée.") from exc
    if REQUIRE_CLOUD_STATE:
        raise HTTPException(status_code=503,detail="Firestore indisponible.")
    fallback_map[doc_id]=data
    return data


async def get_job_store(job_id: str) -> Optional[dict]:
    return await _get_doc(FIRESTORE_COLLECTION_JOBS, job_id, _LOCAL_JOB_STORE)


async def set_job_store(job_id: str, data: dict) -> dict:
    if firestore_client:
        def _merge_transactionally():
            ref = firestore_client.collection(FIRESTORE_COLLECTION_JOBS).document(job_id)
            transaction = firestore_client.transaction()
            @firestore.transactional
            def _apply(tx):
                snap = ref.get(transaction=tx)
                existing = snap.to_dict() if snap.exists else {}
                merged = {**existing, **data, "updated_at": _utc_now_iso()}
                tx.set(ref, merged, merge=True)
                return merged
            return _apply(transaction)
        try:
            result = await run_in_executor(_merge_transactionally)
            _LOCAL_JOB_STORE[job_id] = result
            return result
        except Exception as exc:
            ApexCloudTelemetry.emit("ERROR", "firestore_job_write_failed", job_id=job_id, error=str(exc)[:200])
            if REQUIRE_CLOUD_STATE:
                raise
    if REQUIRE_CLOUD_STATE:
        raise HTTPException(status_code=503, detail="Firestore indisponible.")
    existing = _LOCAL_JOB_STORE.get(job_id, {})
    merged = {**existing, **data, "updated_at": _utc_now_iso()}
    _LOCAL_JOB_STORE[job_id] = merged
    return merged


async def claim_job_for_processing(job_id: str, user_id: str, pipeline_name: str) -> bool:
    if firestore_client:
        def _claim():
            ref = firestore_client.collection(FIRESTORE_COLLECTION_JOBS).document(job_id)
            transaction = firestore_client.transaction()
            @firestore.transactional
            def _apply(tx):
                snap = ref.get(transaction=tx)
                if not snap.exists:
                    return False
                job = snap.to_dict() or {}
                if job.get("owner") != user_id or job.get("status") not in ("queued", "processing"):
                    return False
                if job.get("status") == "processing" and job.get("worker_claimed_at"):
                    try:
                        claimed_at=datetime.fromisoformat(job["worker_claimed_at"])
                        if claimed_at.tzinfo is None: claimed_at=claimed_at.replace(tzinfo=timezone.utc)
                        if (_utc_now()-claimed_at).total_seconds() < 1200: return False
                    except Exception: return False
                tx.update(ref, {"status": "processing", "step": f"Démarrage ({pipeline_name})",
                                "worker_claimed_at": _utc_now_iso(), "updated_at": _utc_now_iso()})
                return True
            return _apply(transaction)
        return await run_in_executor(_claim)
    if REQUIRE_CLOUD_STATE:
        raise HTTPException(status_code=503, detail="Firestore requis pour verrouiller les tâches.")
    job = _LOCAL_JOB_STORE.get(job_id)
    if not job or job.get("owner") != user_id or job.get("status") != "queued":
        return False
    job.update({"status":"processing", "step":f"Démarrage ({pipeline_name})", "worker_claimed_at":_utc_now_iso()})
    return True


async def get_or_create_wallet(user_id: str) -> dict:
    if firestore_client:
        def _create_if_missing():
            ref = firestore_client.collection(FIRESTORE_COLLECTION_WALLETS).document(user_id)
            transaction = firestore_client.transaction()
            @firestore.transactional
            def _apply(tx):
                snap = ref.get(transaction=tx)
                if snap.exists:
                    return snap.to_dict()
                now = _utc_now()
                wallet = {"user_id": user_id, "plan_id": "free", "credits_balance": 0,
                          "expires_at": None, "created_at": now.isoformat(), "updated_at": now.isoformat()}
                tx.create(ref, wallet)
                return wallet
            return _apply(transaction)
        wallet = await run_in_executor(_create_if_missing)
        _LOCAL_WALLET_STORE[user_id] = wallet
        return wallet
    if REQUIRE_CLOUD_STATE:
        raise HTTPException(status_code=503, detail="Firestore indisponible : portefeuille non accessible.")
    return _LOCAL_WALLET_STORE.setdefault(user_id, {"user_id":user_id,"plan_id":"free","credits_balance":0,"expires_at":None})


async def charge_credits_atomic(user_id: str, amount: int, reason: str, idempotency_key: Optional[str] = None) -> dict:
    if amount <= 0:
        return await get_or_create_wallet(user_id)
    if not firestore_client:
        if REQUIRE_CLOUD_STATE:
            raise HTTPException(status_code=503, detail="Firestore requis pour débiter les crédits en sécurité.")
        wallet = await get_or_create_wallet(user_id)
        if int(wallet.get("credits_balance", 0)) < amount:
            raise HTTPException(status_code=402, detail="Solde de crédits insuffisant.")
        wallet["credits_balance"] = int(wallet["credits_balance"]) - amount
        _LOCAL_WALLET_STORE[user_id] = wallet
        return wallet
    txid = hashlib.sha256(f"charge:{user_id}:{idempotency_key or uuid.uuid4().hex}".encode()).hexdigest()
    def _charge():
        wallet_ref = firestore_client.collection(FIRESTORE_COLLECTION_WALLETS).document(user_id)
        tx_ref = firestore_client.collection(FIRESTORE_COLLECTION_WALLETS).document(user_id).collection("ledger").document(txid)
        transaction = firestore_client.transaction()
        @firestore.transactional
        def _apply(tx):
            prior = tx_ref.get(transaction=tx)
            if prior.exists:
                return wallet_ref.get(transaction=tx).to_dict()
            snap = wallet_ref.get(transaction=tx)
            wallet = snap.to_dict() if snap.exists else None
            if not wallet:
                raise HTTPException(status_code=402, detail="Aucun abonnement actif. Achetez un forfait avant de générer.")
            exp = wallet.get("expires_at")
            if exp:
                exp_dt = datetime.fromisoformat(exp.replace("Z", "+00:00"))
                if exp_dt.tzinfo is None: exp_dt = exp_dt.replace(tzinfo=timezone.utc)
                if _utc_now() > exp_dt:
                    raise HTTPException(status_code=402, detail="Vos crédits ont expiré. Renouvelez votre abonnement.")
            balance = int(wallet.get("credits_balance", 0))
            if balance < amount:
                raise HTTPException(status_code=402, detail=f"Solde insuffisant ({balance} crédit(s), {amount} requis).")
            wallet["credits_balance"] = balance - amount
            wallet["updated_at"] = _utc_now_iso()
            tx.set(wallet_ref, wallet, merge=True)
            tx.create(tx_ref, {"type":"charge", "amount":amount, "reason":reason, "created_at":_utc_now_iso()})
            return wallet
        return _apply(transaction)
    wallet = await run_in_executor(_charge)
    _LOCAL_WALLET_STORE[user_id] = wallet
    return wallet


async def refund_credits(user_id: str, amount: int, reason: str) -> None:
    if amount <= 0: return
    if not firestore_client:
        if REQUIRE_CLOUD_STATE:
            raise HTTPException(status_code=503, detail="Firestore requis pour rembourser les crédits.")
        wallet = await get_or_create_wallet(user_id)
        wallet["credits_balance"] = int(wallet.get("credits_balance",0)) + amount
        _LOCAL_WALLET_STORE[user_id] = wallet
        return
    txid = hashlib.sha256(f"refund:{user_id}:{reason}".encode()).hexdigest()
    def _refund():
        wallet_ref = firestore_client.collection(FIRESTORE_COLLECTION_WALLETS).document(user_id)
        tx_ref = wallet_ref.collection("ledger").document(txid)
        transaction = firestore_client.transaction()
        @firestore.transactional
        def _apply(tx):
            if tx_ref.get(transaction=tx).exists: return wallet_ref.get(transaction=tx).to_dict()
            snap = wallet_ref.get(transaction=tx)
            if not snap.exists: raise RuntimeError("Portefeuille introuvable pour remboursement")
            wallet = snap.to_dict()
            wallet["credits_balance"] = int(wallet.get("credits_balance",0)) + amount
            wallet["updated_at"] = _utc_now_iso()
            tx.set(wallet_ref, wallet, merge=True)
            tx.create(tx_ref, {"type":"refund", "amount":amount, "reason":reason, "created_at":_utc_now_iso()})
            return wallet
        return _apply(transaction)
    wallet = await run_in_executor(_refund)
    _LOCAL_WALLET_STORE[user_id] = wallet


async def enforce_free_quota_and_rate_limit(user_id: str) -> dict:
    if not firestore_client:
        if REQUIRE_CLOUD_STATE: raise HTTPException(status_code=503, detail="Firestore requis pour le quota quotidien.")
        raise HTTPException(status_code=503, detail="Quota local désactivé en mode production.")
    now = _utc_now()
    day = now.strftime("%Y-%m-%d")
    minute = now.strftime("%Y%m%d%H%M")
    ref = firestore_client.collection("genia_free_usage").document(f"{user_id}_{day}")
    rate_ref = firestore_client.collection("genia_rate_limits").document(f"{user_id}_{minute}")
    def _increment():
        tx = firestore_client.transaction()
        @firestore.transactional
        def _apply(transaction):
            snap = ref.get(transaction=transaction)
            rate_snap = rate_ref.get(transaction=transaction)
            used = int((snap.to_dict() or {}).get("count", 0)) if snap.exists else 0
            rate_used = int((rate_snap.to_dict() or {}).get("count", 0)) if rate_snap.exists else 0
            if rate_used >= 20:
                raise HTTPException(status_code=429, detail="Limite de 20 requêtes par minute atteinte.")
            if used >= FREE_DAILY_FREE_RENDERS:
                raise HTTPException(status_code=429, detail=f"Quota gratuit quotidien atteint ({FREE_DAILY_FREE_RENDERS}).")
            transaction.set(ref, {"user_id":user_id,"date":day,"count":used+1,"updated_at":_utc_now_iso()}, merge=True)
            transaction.set(rate_ref, {"user_id":user_id,"minute":minute,"count":rate_used+1,"updated_at":_utc_now_iso()}, merge=True)
            return used + 1
        return _apply(tx)
    used = await run_in_executor(_increment)
    return {"tier":"free_with_genia_badge", "watermark_text":"Créé avec Genia", "max_duration_sec":FREE_TIER_MAX_DURATION_SEC,
            "daily_limit":FREE_DAILY_FREE_RENDERS, "remaining_today":max(0, FREE_DAILY_FREE_RENDERS-used)}


# =========================================================================
# MODÈLES PYDANTIC DE REQUÊTE
# =========================================================================
class SceneInput(BaseModel):
    personnage: Literal["narrateur", "femme", "mari", "proche", "expert"] = "narrateur"
    texte: str = Field(..., min_length=1, max_length=1500)
    visual_prompt: str = Field(..., min_length=1, max_length=1500)
    image_source_url: Optional[str] = Field(default=None, max_length=2048)


class VideoRenderRequest(BaseModel):
    scenes: List[SceneInput] = Field(default_factory=list, max_length=MAX_SCENES_PER_REQUEST)
    raw_script_input: Optional[str] = Field(default=None, max_length=4000)
    avatar_mode: Literal["single_avatar", "multi_avatar_dialogue"] = "single_avatar"
    avatar_id: Optional[str] = "leo_express"
    avatar_description: Optional[str] = Field(default=None, max_length=600)
    keep_same_avatar: bool = True
    voice_profile_id: Optional[str] = Field(default=None, max_length=128)
    lip_sync_mode: Literal["auto", "native_omni", "google_tts", "latentsync"] = "auto"
    auto_multi_scenes_count: int = Field(default=3, ge=2, le=12)
    aspect_ratio: Literal["9:16", "1:1", "16:9"] = "9:16"
    transition_style: Literal["cut", "crossfade"] = "cut"
    max_total_duration_sec: float = Field(default=30.0, ge=3.0, le=600.0)
    voice_speaking_rate: float = Field(default=1.06, ge=0.75, le=1.45)
    subtitle_position: Literal["top", "center", "bottom"] = "bottom"
    show_subtitles: bool = True
    filter_id: Optional[str] = None
    text_style_id: str = "pop_sticker_box"
    overlay_title: Optional[str] = Field(default=None, max_length=40)
    sticker_ids: List[str] = Field(default_factory=list, max_length=4)
    sticker_position: Literal["top_left", "top_right", "bottom_left", "bottom_right", "center"] = "top_right"
    bgm_url: Optional[str] = None
    bgm_volume: float = Field(default=0.15, ge=0.0, le=0.6)
    webhook_url: Optional[str] = None

    @field_validator("scenes")
    @classmethod
    def _validate_scenes(cls, v, info):
        raw = info.data.get("raw_script_input")
        if not v and not (raw and raw.strip()):
            raise ValueError("Fournissez au moins une scène ou un script (raw_script_input).")
        return v


class MediaItemInput(BaseModel):
    media_url: str = Field(..., min_length=4, max_length=2048)
    media_type: Literal["image", "video"] = "image"
    custom_caption: Optional[str] = Field(default=None, max_length=240)


class TemplateApplyRequest(BaseModel):
    template_id: str = Field(..., min_length=1)
    voice_profile_id: Optional[str] = Field(default=None, max_length=128)
    media_items: List[MediaItemInput] = Field(..., min_length=1, max_length=12)
    aspect_ratio: Literal["9:16", "1:1", "16:9"] = "9:16"
    transition_style: Literal["cut", "crossfade"] = "cut"
    subtitle_position: Literal["top", "center", "bottom"] = "bottom"
    show_subtitles: bool = True
    voice_speaking_rate: float = Field(default=1.06, ge=0.75, le=1.45)
    filter_id: Optional[str] = None
    text_style_id: str = "pop_sticker_box"
    overlay_title: Optional[str] = Field(default=None, max_length=40)
    sticker_ids: List[str] = Field(default_factory=list, max_length=4)
    sticker_position: Literal["top_left", "top_right", "bottom_left", "bottom_right", "center"] = "top_right"
    bgm_url: Optional[str] = None
    bgm_volume: float = Field(default=0.15, ge=0.0, le=0.6)


class PhotoModelApplyRequest(BaseModel):
    photo_model_id: str = Field(..., min_length=1)
    voice_profile_id: Optional[str] = Field(default=None, max_length=128)
    user_photo_urls: List[str] = Field(..., min_length=1, max_length=12)
    insertion_mode: Literal["add_model_to_photos", "add_photos_to_model"] = "add_model_to_photos"
    captions: List[str] = Field(default_factory=list)
    voice_enabled: bool = True
    personnage: Literal["narrateur", "femme", "mari", "proche", "expert"] = "narrateur"
    aspect_ratio: Literal["9:16", "1:1", "16:9"] = "9:16"
    transition_style: Literal["cut", "crossfade"] = "cut"
    subtitle_position: Literal["top", "center", "bottom"] = "bottom"
    show_subtitles: bool = True
    voice_speaking_rate: float = Field(default=1.06, ge=0.75, le=1.45)
    filter_id: Optional[str] = None
    text_style_id: str = "pop_sticker_box"
    overlay_title: Optional[str] = Field(default=None, max_length=40)
    sticker_ids: List[str] = Field(default_factory=list, max_length=4)
    sticker_position: Literal["top_left", "top_right", "bottom_left", "bottom_right", "center"] = "top_right"
    bgm_url: Optional[str] = None
    bgm_volume: float = Field(default=0.15, ge=0.0, le=0.6)


class RecordStudioRequest(BaseModel):
    recorded_video_url: str = Field(..., min_length=4, max_length=2048)
    camera_preset_id: str = "cam_zoom_hook"
    playback_speed: float = Field(default=1.0, ge=0.5, le=1.75)
    transcript_text: Optional[str] = Field(default=None, max_length=2500)
    aspect_ratio: Literal["9:16", "1:1", "16:9"] = "9:16"
    subtitle_position: Literal["top", "center", "bottom"] = "bottom"
    show_subtitles: bool = True
    filter_id: Optional[str] = None
    text_style_id: str = "pop_sticker_box"
    overlay_title: Optional[str] = Field(default=None, max_length=40)
    sticker_ids: List[str] = Field(default_factory=list, max_length=4)
    sticker_position: Literal["top_left", "top_right", "bottom_left", "bottom_right", "center"] = "top_right"
    bgm_url: Optional[str] = None
    bgm_volume: float = Field(default=0.15, ge=0.0, le=0.6)


class SongPhotoRenderRequest(BaseModel):
    photo_url: str = Field(..., min_length=4, max_length=2048)
    song_url: str = Field(..., min_length=4, max_length=2048)
    lyrics_text: Optional[str] = Field(default=None, max_length=3500)
    auto_extract_lyrics: bool = True
    motion: Literal["zoom_in", "zoom_out", "pan_right", "pan_left", "static"] = "zoom_in"
    lyrics_position: Literal["top", "center", "bottom"] = "bottom"
    show_lyrics: bool = True
    aspect_ratio: Literal["9:16", "1:1", "16:9"] = "9:16"
    filter_id: Optional[str] = None
    text_style_id: str = "pop_sticker_box"
    overlay_title: Optional[str] = Field(default=None, max_length=40)
    sticker_ids: List[str] = Field(default_factory=list, max_length=4)
    sticker_position: Literal["top_left", "top_right", "bottom_left", "bottom_right", "center"] = "top_right"
    bgm_url: Optional[str] = None
    bgm_volume: float = Field(default=0.15, ge=0.0, le=0.6)


class SplitVideoRequest(BaseModel):
    source_video_url: str = Field(..., min_length=4, max_length=2048)
    voice_profile_id: Optional[str] = Field(default=None, max_length=128)
    num_clips: int = Field(default=3, ge=1, le=10)
    clip_duration: float = Field(default=8.0, ge=2.0, le=600.0)
    topic_context: str = Field(default="Moment fort", max_length=300)
    add_hook_voice: bool = False
    personnage: Literal["narrateur", "femme", "mari", "proche", "expert"] = "narrateur"


class ViewPotentialRequest(BaseModel):
    job_id: Optional[str] = None
    followers_count: int = Field(default=1000, ge=0)
    average_views_per_video: int = Field(default=800, ge=0)
    platform: Literal["tiktok", "reels", "shorts"] = "tiktok"
    script_or_captions: Optional[str] = Field(default=None, max_length=4000)
    scenes_count: int = Field(default=3, ge=1, le=20)


class ActivatePlanRequest(BaseModel):
    plan_id: Literal["plan_20", "plan_40", "plan_80"]
    payment_reference: str = Field(..., min_length=8, max_length=160)
    payment_proof: str = Field(..., min_length=32, max_length=512)


# =========================================================================
# UTILITAIRES MÉDIA & FFMPEG
# =========================================================================
def get_dimensions(aspect_ratio: str) -> Tuple[int, int]:
    if aspect_ratio == "1:1":
        return 1080, 1080
    if aspect_ratio == "16:9":
        return 1920, 1080
    return 1080, 1920


def get_filter_spec(filter_id: Optional[str]) -> Optional[dict]:
    if not filter_id:
        return None
    return FILTERS_CATALOG.get(filter_id)


def _run_cmd(cmd: List[str], label: str = "ffmpeg") -> None:
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=FFMPEG_TIMEOUT_SECONDS)
    if proc.returncode != 0:
        err_tail = (proc.stderr or "")[-600:]
        raise RuntimeError(f"Échec {label} (code {proc.returncode}) : {err_tail}")


def _probe_media_duration(file_path: str, default_sec: float = 4.0) -> float:
    try:
        proc = subprocess.run(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                file_path,
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        val = float((proc.stdout or "").strip())
        if val > 0.2:
            return val
    except Exception:
        pass
    return default_sec


def _validate_public_http_url(url: str) -> urllib.parse.ParseResult:
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("URL média invalide : seuls les liens HTTP(S) publics sont acceptés.")
    try:
        addresses = socket.getaddrinfo(parsed.hostname, parsed.port or (443 if parsed.scheme == "https" else 80), type=socket.SOCK_STREAM)
        for item in addresses:
            ip = ipaddress.ip_address(item[4][0])
            if not ip.is_global:
                raise ValueError("Accès aux adresses IP privées ou réservées interdit.")
    except socket.gaierror as exc:
        raise ValueError("Nom d'hôte média introuvable.") from exc
    return parsed


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        _validate_public_http_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def download_remote_file(url: str, dest_path: str, job_id: str) -> str:
    """Télécharge uniquement HTTP(S) public ou gs:// du bucket Genia. Aucun chemin local/file:// utilisateur."""
    if url.startswith("gs://"):
        parsed = urllib.parse.urlparse(url)
        bucket_name = parsed.netloc
        blob_name = parsed.path.lstrip("/")
        if not storage_client or not bucket_name or not blob_name:
            raise ValueError("URI GCS invalide ou client Storage indisponible.")
        if bucket_name != GCS_BUCKET_NAME:
            raise ValueError("Téléchargement limité au bucket GCS Genia configuré.")
        blob = storage_client.bucket(bucket_name).blob(blob_name)
        blob.reload()
        if blob.size and int(blob.size) > MAX_DOWNLOAD_BYTES:
            raise ValueError("Fichier trop volumineux.")
        blob.download_to_filename(dest_path)
        return dest_path
    parsed = _validate_public_http_url(url)
    opener = urllib.request.build_opener(_NoRedirect())
    req = urllib.request.Request(url, headers={"User-Agent":"GeniaApex/1.0"})
    total = 0
    try:
        with opener.open(req, timeout=90) as response, open(dest_path, "wb") as out:
            content_length = int(response.headers.get("Content-Length", "0") or 0)
            if content_length > MAX_DOWNLOAD_BYTES:
                raise ValueError("Fichier distant trop volumineux.")
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk: break
                total += len(chunk)
                if total > MAX_DOWNLOAD_BYTES:
                    raise ValueError("Limite de téléchargement dépassée.")
                out.write(chunk)
        if total == 0: raise ValueError("Fichier téléchargé vide.")
        return dest_path
    except Exception:
        if os.path.exists(dest_path): os.remove(dest_path)
        raise


# =========================================================================
# GEMINI OMNI 1.2 — GÉNÉRATION AUDIO/VIDÉO SYNCHRONISÉE (INTERACTIONS API)
# =========================================================================
def _vertex_ai_rest_request(method: str, url: str, payload: Optional[dict] = None, timeout: int = 1200) -> dict:
    """Appel REST Google Vertex AI avec ADC; aucune clé API statique n'est utilisée."""
    credentials, _ = google_auth_default(scopes=["https://www.googleapis.com/auth/cloud-platform"])
    if not credentials.valid or credentials.expired or not credentials.token:
        credentials.refresh(GoogleCredentialsRequest())
    body = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=body,
        headers={
            "Authorization": f"Bearer {credentials.token}",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json",
        },
        method=method.upper(),
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read()
    except urllib.error.HTTPError as exc:
        detail = exc.read(4096).decode("utf-8", errors="replace")
        raise RuntimeError(f"Vertex AI REST API HTTP {exc.code}: {detail[:1200]}") from exc
    except Exception as exc:
        raise RuntimeError(f"Échec de connexion à Vertex AI REST API: {str(exc)[:500]}") from exc
    try:
        parsed = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise RuntimeError("Vertex AI REST API a renvoyé une réponse JSON invalide.") from exc
    if not isinstance(parsed, dict):
        raise RuntimeError("Vertex AI REST API a renvoyé une structure inattendue.")
    if parsed.get("error"):
        raise RuntimeError(f"Vertex AI REST API: {str(parsed['error'])[:1000]}")
    return parsed


# =========================================================================
# MOTEUR IA : SCRIPTS, SCÈNES, AVATARS & ESTIMATION DE VUES
# =========================================================================
class ApexManagedGoogleModels:
    @staticmethod
    async def expand_script_into_scenes(
        raw_script: str, avatar_mode: str, num_scenes: int,
        avatar_description: str, default_gesture: str,
    ) -> List[dict]:
        roles_cycle = ["narrateur", "femme", "mari", "proche", "expert"]
        prompt = (
            "Tu es réalisateur de vidéos courtes. Transforme le script en " + str(num_scenes) +
            " scènes en français. Réponds uniquement en JSON: [{\"personnage\":...,\"texte\":...,\"visual_prompt\":...}]. "
            "personnage doit être narrateur, femme, mari, proche ou expert. "
            f"Mode avatar: {avatar_mode}. Apparence: {avatar_description}. Gestuelle: {default_gesture}. Script: {raw_script}"
        )
        try:
            raw = await run_in_executor(_local_chat_text, prompt, 0.55, 2200)
            parsed = json.loads(raw[raw.find("["):raw.rfind("]") + 1])
            if isinstance(parsed, list) and parsed:
                result = []
                for i, item in enumerate(parsed[:num_scenes]):
                    role = item.get("personnage") if item.get("personnage") in ROLE_VOICE_MAP else "narrateur"
                    result.append({"personnage": role, "texte": str(item.get("texte") or raw_script).strip(),
                                   "visual_prompt": str(item.get("visual_prompt") or avatar_description).strip()})
                if result:
                    return result
        except Exception as exc:
            ApexCloudTelemetry.emit("WARNING", "local_qwen_scene_fallback", error=str(exc)[:220])
        sentences = [x.strip() for x in re.split(r"[.!?\n]+", raw_script) if x.strip()] or [raw_script.strip()]
        return [{"personnage": "narrateur" if avatar_mode == "single_avatar" else roles_cycle[i % len(roles_cycle)],
                 "texte": sentence, "visual_prompt": f"{avatar_description}, {default_gesture}, scene {i+1}"}
                for i, sentence in enumerate(sentences[:num_scenes])]

    @staticmethod
    async def generate_veo_clip(
        prompt_text: str, output_mp4_path: str, duration_sec: int,
        aspect_ratio: str, job_id: str, ref_image_path: Optional[str] = None,
    ) -> str:
        fields = {"prompt": prompt_text, "duration_seconds": int(max(3, min(8, duration_sec))),
                  "aspect_ratio": aspect_ratio, "job_id": job_id}
        if ref_image_path and os.path.isfile(ref_image_path):
            data = await run_in_executor(_local_ai_multipart, "/v1/videos/generations", fields,
                                         "image", ref_image_path, None, GENIA_LOCAL_AI_TIMEOUT)
        else:
            data = await run_in_executor(_local_ai_json, "/v1/videos/generations", fields, GENIA_LOCAL_AI_TIMEOUT)
        _copy_local_artifact(data, output_mp4_path)
        _validate_media_file(output_mp4_path)
        return output_mp4_path

    @staticmethod
    async def generate_live_avatar_clip(
        prompt_text: str, reference_image_path: str, output_mp4_path: str,
        job_id: str, scene_index: int, avatar_voice_name: str = "Puck",
        voice_profile_id: Optional[str] = None, user_id: Optional[str] = None,
        aspect_ratio: str = "9:16",
        additional_reference_image_path: Optional[str] = None,
    ) -> str:
        """Génère une vidéo d'avatar avec voix et lèvres synchronisées par Gemini 3.8 Live."""
        if not ENABLE_GEMINI_LIVE_AVATAR:
            raise RuntimeError("Gemini Live Avatar est désactivé. Activez-le uniquement après autorisation Google pour votre projet.")
        if not genai_client or not storage_client or not os.path.isfile(reference_image_path):
            raise RuntimeError("Gemini Live Avatar exige Vertex AI, Cloud Storage et une image de référence.")

        live_avatar_size = (1280, 720) if aspect_ratio == "16:9" else (720, 1280)
        with Image.open(reference_image_path) as source_image:
            avatar_image = ImageOps.fit(
                ImageOps.exif_transpose(source_image).convert("RGB"),
                live_avatar_size,
                method=Image.Resampling.LANCZOS,
                centering=(0.5, 0.38),
            )
            avatar_buffer = io.BytesIO()
            avatar_image.save(avatar_buffer, format="PNG", optimize=True)
            avatar_bytes = avatar_buffer.getvalue()
        if len(avatar_bytes) >= 5 * 1024 * 1024:
            raise RuntimeError("L'image d'avatar préparée dépasse la limite Google de 5 Mo.")

        voice_config: dict
        if voice_profile_id:
            if not user_id or not firestore_client:
                raise RuntimeError("Le profil vocal personnalisé nécessite une authentification et Firestore.")
            profile = await _get_doc("genia_voice_profiles", voice_profile_id, {})
            if not profile or profile.get("owner") != user_id:
                raise HTTPException(status_code=403, detail="Profil vocal introuvable ou non autorisé.")
            if profile.get("consent_verified_by_google") is not True:
                raise HTTPException(status_code=403, detail="Le profil vocal ne possède pas de consentement vérifié par Google.")
            sample_uri = str(profile.get("live_voice_sample_gcs_uri") or "")
            parsed_sample = urllib.parse.urlparse(sample_uri)
            if parsed_sample.scheme != "gs" or parsed_sample.netloc != GCS_BUCKET_NAME or not parsed_sample.path.lstrip("/"):
                raise RuntimeError("Ce profil vocal n'a pas d'échantillon PCM Live sécurisé. Recréez le profil vocal après activation du stockage GCS.")
            sample_blob = storage_client.bucket(parsed_sample.netloc).blob(parsed_sample.path.lstrip("/"))
            sample_bytes = await run_in_executor(sample_blob.download_as_bytes)
            if len(sample_bytes) < 24000 or len(sample_bytes) > 2 * 1024 * 1024:
                raise RuntimeError("L'échantillon PCM de la voix personnalisée est absent ou de taille invalide.")
            voice_config = {
                "replicated_voice_config": {
                    "voice_sample_audio": base64.b64encode(sample_bytes).decode("ascii"),
                    "mime_type": "audio/pcm;rate=24000",
                }
            }
        else:
            safe_voice_name = str(avatar_voice_name or "Puck").split("-")[-1]
            allowed_live_voices = {
                "Zephyr", "Kore", "Orus", "Autonoe", "Umbriel", "Erinome", "Laomedeia", "Schedar",
                "Achird", "Sadachbia", "Puck", "Fenrir", "Aoede", "Enceladus", "Algieba", "Algenib",
                "Achernar", "Gacrux", "Zubenelgenubi", "Charon", "Leda", "Callirrhoe", "Iapetus",
                "Despina", "Rasalgethi", "Alnilam", "Pulcherrima", "Vindemiatrix", "Sulafat",
            }
            if safe_voice_name not in allowed_live_voices:
                safe_voice_name = "Puck"
            voice_config = {"prebuilt_voice_config": {"voice_name": safe_voice_name}}

        config = {
            "response_modalities": ["VIDEO"],
            "speech_config": {
                "language_code": "fr-FR",
                "voice_config": voice_config,
            },
            "avatar_config": {
                "customized_avatar": {
                    "image_data": base64.b64encode(avatar_bytes).decode("ascii"),
                    "image_mime_type": "png",
                }
            },
            "system_instruction": {
                "parts": [{"text": (
                    "Tu es un présentateur vidéo francophone. Prononce intégralement le texte fourni par l'utilisateur, "
                    "sans le résumer, le traduire, le paraphraser ni ajouter de phrase. Parle naturellement, "
                    "avec une articulation claire et une expression adaptée. Termine après le texte demandé."
                )}]
            },
            "output_audio_transcription": {},
        }

        async def _collect_live_video():
            chunks: List[bytes] = []
            turn_completed = False
            async with genai_client.aio.live.connect(model=GEMINI_LIVE_AVATAR_MODEL, config=config) as session:
                live_input_parts = [genai_types.Part(text=prompt_text)]
                if additional_reference_image_path and os.path.isfile(additional_reference_image_path):
                    with Image.open(additional_reference_image_path) as scene_image:
                        scene_image = ImageOps.exif_transpose(scene_image).convert("RGB")
                        scene_image.thumbnail((1024, 1024), Image.Resampling.LANCZOS)
                        scene_buffer = io.BytesIO()
                        scene_image.save(scene_buffer, format="PNG", optimize=True)
                        live_input_parts.append(genai_types.Part.from_bytes(data=scene_buffer.getvalue(), mime_type="image/png"))
                await session.send_content(
                    content=genai_types.Content(
                        role="user",
                        parts=live_input_parts,
                    )
                )
                async for message in session.receive():
                    server_content = getattr(message, "server_content", None)
                    model_turn = getattr(server_content, "model_turn", None) if server_content else None
                    for part in (getattr(model_turn, "parts", None) or []):
                        inline = getattr(part, "inline_data", None)
                        if inline and str(getattr(inline, "mime_type", "")).startswith("video/mp4"):
                            data = getattr(inline, "data", None)
                            if data:
                                chunks.append(data if isinstance(data, bytes) else bytes(data))
                    if server_content and getattr(server_content, "turn_complete", False):
                        turn_completed = True
                        break
            if not turn_completed:
                raise RuntimeError("Gemini Live Avatar a fermé la session sans signal de fin de tour.")
            if not chunks:
                raise RuntimeError("Gemini Live Avatar n'a retourné aucun fragment MP4.")
            raw_fmp4 = output_mp4_path + ".fmp4"
            with open(raw_fmp4, "wb") as output_file:
                for chunk in chunks:
                    output_file.write(chunk)
            try:
                await run_in_executor(
                    _run_cmd,
                    ["ffmpeg", "-y", "-i", raw_fmp4, "-c", "copy", "-movflags", "+faststart", output_mp4_path],
                    label="gemini_live_avatar_fmp4_remux",
                )
            finally:
                if os.path.exists(raw_fmp4):
                    os.remove(raw_fmp4)
            _validate_media_file(output_mp4_path)
            if not _media_has_audio(output_mp4_path):
                raise RuntimeError("Gemini Live Avatar a retourné une vidéo sans audio muxé.")
            return output_mp4_path

        try:
            return await asyncio.wait_for(_collect_live_video(), timeout=240)
        except asyncio.TimeoutError as exc:
            raise TimeoutError("Gemini Live Avatar a dépassé 240 secondes; aucune génération de remplacement n'est lancée automatiquement.") from exc


    @staticmethod
    async def generate_omni_avatar_clip(
        prompt_text: str, reference_image_path: str, output_mp4_path: str,
        duration_sec: int, aspect_ratio: str, job_id: str, scene_index: int,
        additional_reference_image_path: Optional[str] = None,
    ) -> str:
        """Génère une scène parlante avec audio natif synchronisé par Gemini Omni 1.2."""
        if not ENABLE_GEMINI_OMNI_NATIVE_AVATAR:
            raise RuntimeError("La génération native Gemini Omni est désactivée par configuration.")
        if not storage_client or not os.path.isfile(reference_image_path):
            raise RuntimeError("Gemini Omni nécessite une image de référence et un bucket GCS disponible.")
        duration = int(max(3, min(15, duration_sec)))
        if GEMINI_OMNI_VIDEO_RESOLUTION not in {"360p", "720p", "1080p", "4k"}:
            raise RuntimeError("GEMINI_OMNI_VIDEO_RESOLUTION doit être 360p, 720p, 1080p ou 4k.")
        if aspect_ratio not in {"9:16", "16:9"}:
            # Gemini Omni ne documente que ces deux formats; le recadrage final gère les autres ratios.
            aspect_ratio = "9:16" if aspect_ratio == "1:1" else "16:9"

        def _generate():
            bucket = storage_client.bucket(GCS_BUCKET_NAME)
            ref_blob_name = f"omni-temp/{job_id}/reference_{scene_index}_{uuid.uuid4().hex}.png"
            output_blob_name = f"omni-output/{job_id}/scene_{scene_index}_{uuid.uuid4().hex}.mp4"
            ref_blob = bucket.blob(ref_blob_name)
            extra_blob = None
            try:
                with Image.open(reference_image_path) as reference_image:
                    ref_buffer = io.BytesIO()
                    ImageOps.exif_transpose(reference_image).convert("RGB").save(ref_buffer, format="PNG")
                    ref_blob.upload_from_string(ref_buffer.getvalue(), content_type="image/png")
                omni_inputs = [
                    {"type": "text", "text": prompt_text},
                    {"type": "image", "uri": f"gs://{GCS_BUCKET_NAME}/{ref_blob_name}", "mime_type": "image/png"},
                ]
                if additional_reference_image_path and os.path.isfile(additional_reference_image_path):
                    extra_blob_name = f"omni-temp/{job_id}/scene_reference_{scene_index}_{uuid.uuid4().hex}.png"
                    extra_blob = bucket.blob(extra_blob_name)
                    with Image.open(additional_reference_image_path) as extra_image:
                        extra_buffer = io.BytesIO()
                        ImageOps.exif_transpose(extra_image).convert("RGB").save(extra_buffer, format="PNG")
                        extra_blob.upload_from_string(extra_buffer.getvalue(), content_type="image/png")
                    omni_inputs.append({"type": "image", "uri": f"gs://{GCS_BUCKET_NAME}/{extra_blob_name}", "mime_type": "image/png"})
                request_body = {
                    "model": GEMINI_OMNI_VIDEO_MODEL,
                    "store": False,
                    "input": omni_inputs,
                    "response_format": [{
                        "type": "video",
                        "delivery": "uri",
                        "gcs_uri": f"gs://{GCS_BUCKET_NAME}/{output_blob_name}",
                        "aspect_ratio": aspect_ratio,
                        "resolution": GEMINI_OMNI_VIDEO_RESOLUTION,
                        "duration": f"{duration}s",
                    }],
                    "generation_config": {"video_config": {"task": "reference_to_video"}},
                }
                endpoint = (
                    f"https://aiplatform.googleapis.com/v1beta1/projects/{urllib.parse.quote(GCP_PROJECT_ID, safe='')}"
                    "/locations/global/interactions"
                )
                response = _vertex_ai_rest_request("POST", endpoint, request_body, timeout=1500)
                state = str(response.get("status", "")).lower()
                if state in {"failed", "cancelled", "expired"}:
                    raise RuntimeError(f"Gemini Omni a terminé avec le statut {state}: {str(response)[:700]}")

                output_uri = None
                for step in response.get("steps", []) or []:
                    if step.get("type") != "model_output":
                        continue
                    for content in step.get("content", []) or []:
                        if content.get("type") == "video" and content.get("uri"):
                            output_uri = content["uri"]
                            break
                    if output_uri:
                        break
                # Le modèle peut ne pas répéter l'URI dans la réponse; le chemin demandé est déterministe.
                output_uri = output_uri or f"gs://{GCS_BUCKET_NAME}/{output_blob_name}"
                parsed_uri = urllib.parse.urlparse(output_uri)
                if parsed_uri.scheme != "gs" or parsed_uri.netloc != GCS_BUCKET_NAME or not parsed_uri.path.lstrip("/"):
                    raise RuntimeError("Gemini Omni a retourné un URI GCS inattendu; sortie non publiée.")
                output_blob = storage_client.bucket(parsed_uri.netloc).blob(parsed_uri.path.lstrip("/"))
                if not output_blob.exists():
                    raise RuntimeError("Gemini Omni n'a pas créé le fichier vidéo attendu dans GCS.")
                output_blob.download_to_filename(output_mp4_path)
                _validate_media_file(output_mp4_path)
                if not _media_has_audio(output_mp4_path):
                    raise RuntimeError("Gemini Omni a produit une vidéo sans piste audio native; rendu interrompu.")
                return output_mp4_path
            finally:
                try:
                    ref_blob.delete()
                except Exception:
                    pass
                if extra_blob is not None:
                    try:
                        extra_blob.delete()
                    except Exception:
                        pass

        return await run_in_executor(_generate)


    @staticmethod
    async def analyze_video_highlights(video_path: str, topic_context: str, count: int, clip_duration: float) -> List[dict]:
        """Sélectionne des extraits à partir des paroles réellement transcrites (sans analyse visuelle Gemini)."""
        if not os.path.isfile(video_path):
            raise FileNotFoundError(video_path)
        duration = _probe_media_duration(video_path, default_sec=0)
        if duration <= 0:
            return []
        audio_path = f"/tmp/genia_highlights_{uuid.uuid4().hex}.wav"
        try:
            await run_in_executor(_run_cmd, ["ffmpeg", "-y", "-i", video_path, "-vn", "-ac", "1", "-ar", "16000", audio_path], label="extract_highlights_audio")
            response = await run_in_executor(
                _local_ai_multipart, "/v1/audio/transcriptions",
                {"language": "fr", "word_timestamps": "true"}, "file", audio_path,
                None, GENIA_LOCAL_AI_TIMEOUT
            )
            transcript_segments = []
            for index, segment in enumerate(response.get("segments", []) or []):
                text_value = str(segment.get("text") or "").strip()
                try:
                    start_sec=float(segment["start"]); end_sec=float(segment["end"])
                except (KeyError,TypeError,ValueError):
                    continue
                if text_value and 0 <= start_sec < end_sec <= duration:
                    transcript_segments.append({"index":len(transcript_segments),"start":round(start_sec,2),"end":round(end_sec,2),"text":text_value[:500]})
            if not transcript_segments:
                return []
            prompt=(
                "Tu sélectionnes des extraits courts dans une transcription horodatée. "
                "Choisis uniquement des intervalles continus formés de segments existants, sans inventer de temps ni de paroles. "
                f"Retourne uniquement JSON: {{\"highlights\":[{{\"start_segment_index\":0,\"end_segment_index\":2,\"quality_score\":80,\"reason\":\"...\",\"hook\":\"...\"}}]}}. "
                f"Au maximum {max(1,min(10,count))} extraits, durée cible {clip_duration:.1f}s, maximum {clip_duration+1.5:.1f}s. "
                "Privilégie une idée complète, une accroche claire, une émotion ou une conclusion. "
                "N'affirme rien sur les images: seule la transcription audio est analysée. "
                f"Contexte: {topic_context[:800]}\nSegments: {json.dumps(transcript_segments,ensure_ascii=False)}"
            )
            raw=await run_in_executor(_local_chat_text,prompt,0.1,1600)
            parsed=json.loads(raw[raw.find("{"):raw.rfind("}")+1])
            items=parsed.get("highlights",[]) if isinstance(parsed,dict) else []
            clean=[]
            for item in items:
                try:
                    a=int(item["start_segment_index"]); b=int(item["end_segment_index"])
                    if a<0 or b<a or b>=len(transcript_segments): continue
                    start_sec=transcript_segments[a]["start"]; end_sec=transcript_segments[b]["end"]
                    if end_sec<=start_sec or end_sec-start_sec<min(1.0,clip_duration*0.5): continue
                    if end_sec-start_sec>clip_duration+1.5: continue
                    score=item.get("quality_score")
                    score=round(float(score),1) if isinstance(score,(int,float)) and not isinstance(score,bool) and 0<=float(score)<=100 else None
                    clean.append({"start_sec":start_sec,"end_sec":end_sec,"quality_score":score,
                                  "analysis_processing":"audio_transcript_only",
                                  "reason":str(item.get("reason") or "Sélection issue de la transcription audio")[:240],
                                  "hook":str(item.get("hook") or "")[:120]})
                except (KeyError,TypeError,ValueError):
                    continue
            selected=[]
            for item in sorted(clean,key=lambda x:(x["quality_score"] is not None,x["quality_score"] or -1),reverse=True):
                if all(min(item["end_sec"],x["end_sec"])-max(item["start_sec"],x["start_sec"])<0.75 for x in selected):
                    selected.append(item)
                if len(selected)>=max(1,min(10,count)): break
            return sorted(selected,key=lambda x:x["start_sec"])
        finally:
            try: os.remove(audio_path)
            except OSError: pass

    @staticmethod
    async def generate_daily_templates(count: int = 3) -> List[dict]:
        prompt = (
            f"Crée {count} idées de modèles de vidéos courtes en français. "
            "Réponds uniquement en JSON {templates:[{template_id,name,category,hook_prefix,scene_duration}]}. "
            "N'affirme pas qu'il s'agit de tendances actuelles et n'invente aucune source."
        )
        try:
            raw = await run_in_executor(_local_chat_text, prompt, 0.65, 1800)
            parsed = json.loads(raw[raw.find("{"):raw.rfind("}")+1])
            items = parsed.get("templates", []) if isinstance(parsed, dict) else []
            out=[]
            for i,it in enumerate(items[:count]):
                cat=str(it.get("category") or "education").lower()
                if cat not in {"viral","storytelling","education","fun"}: cat="education"
                out.append({"template_id":re.sub(r"[^a-zA-Z0-9_]","_",str(it.get("template_id") or f"tpl_qwen_{uuid.uuid4().hex[:8]}"))[:64],
                    "name":str(it.get("name") or f"Concept Genia #{i+1}")[:100],"category":cat,
                    "hook_prefix":str(it.get("hook_prefix") or "")[:180],
                    "scene_duration":max(3.0,min(5.0,float(it.get("scene_duration") or 3.5))),
                    "trend_basis":"idee_editoriale_generee_localement_sans_verification_tendance","source_urls":[]})
            if not out: raise RuntimeError("Qwen n'a retourné aucun modèle valide.")
            return out
        except Exception as exc:
            ApexCloudTelemetry.emit("ERROR","local_qwen_daily_templates_failed",error=str(exc)[:220])
            raise RuntimeError("La génération des modèles éditoriaux locaux a échoué.") from exc

    @staticmethod
    async def generate_clip_hooks(topic_context: str, num_clips: int) -> List[str]:
        prompt=(f"Donne exactement {num_clips} accroches courtes en français, maximum six mots chacune, "
                f"pour des clips sur le thème: {topic_context}. Réponds uniquement avec une liste JSON.")
        try:
            raw=await run_in_executor(_local_chat_text,prompt,0.65,700)
            arr=json.loads(raw[raw.find("["):raw.rfind("]")+1])
            if isinstance(arr,list) and len(arr)>=num_clips:
                return [str(x).strip() for x in arr[:num_clips]]
        except Exception as exc:
            ApexCloudTelemetry.emit("WARNING","local_qwen_hooks_fallback",error=str(exc)[:180])
        return [f"{topic_context} — Partie {i+1}" for i in range(num_clips)]

    @staticmethod
    async def estimate_views_potential(payload: ViewPotentialRequest) -> dict:
        """Score éditorial Qwen local; ne prédit jamais des vues sans données analytiques réelles."""
        script_txt = (payload.script_or_captions or "").strip()
        unavailable = {
            "virality_score": None,
            "estimated_min_views": None,
            "estimated_expected_views": None,
            "estimated_max_views": None,
            "view_estimate_status": "unavailable_without_connected_platform_analytics",
            "score_status": "unavailable",
            "score_basis": "none",
            "score_label": "Score éditorial indisponible — pas une prévision de vues",
            "not_a_view_prediction": True,
            "summary": "Une analyse éditoriale nécessite le moteur Qwen local disponible.",
            "improvements": [],
            "component_scores": {},
            "evidence": [],
            "analytics_used": False,
            "confidence_type": "model_self_assessment_not_calibrated",
        }
        if not script_txt:
            unavailable["score_status"] = "missing_script"
            unavailable["summary"] = "Fournissez le script ou les sous-titres pour obtenir une analyse éditoriale."
            return unavailable
        prompt = (
            "Tu es un évaluateur éditorial vidéo. Évalue le potentiel créatif du contenu, PAS sa performance future. "
            "Retourne uniquement un JSON avec les clés: overall_score (entier 0-100), "
            "component_scores (objet avec hook, clarity, retention_structure, emotional_value, originality, call_to_action; chacun 0-100), "
            "summary (une phrase), improvements (3 à 5 conseils précis), evidence (2 à 5 courtes observations appuyées sur le texte), "
            "confidence (low, medium ou high). "
            "N'invente aucune statistique, tendance, benchmark, nombre de vues ou donnée de plateforme. "
            "Pénalise les accroches vagues, les répétitions, les promesses sans preuve et les appels à l'action artificiels. "
            "Si le texte ne permet pas d'évaluer une dimension, indique la limite dans evidence. "
            f"Plateforme cible: {payload.platform}. Nombre de scènes déclaré: {payload.scenes_count}. "
            f"Script à évaluer:\n{script_txt}"
        )
        try:
            raw = await run_in_executor(_local_chat_text, prompt, 0.1, 1800)
            parsed = json.loads(raw[raw.find("{"):raw.rfind("}")+1])
            if not isinstance(parsed, dict): raise ValueError("Réponse Qwen non structurée.")
            score = max(0, min(100, int(parsed.get("overall_score", 0))))
            expected_keys = {"hook", "clarity", "retention_structure", "emotional_value", "originality", "call_to_action"}
            raw_components = parsed.get("component_scores") if isinstance(parsed.get("component_scores"), dict) else {}
            components = {k:max(0,min(100,int(raw_components[k]))) for k in expected_keys
                          if isinstance(raw_components.get(k), (int,float)) and not isinstance(raw_components.get(k), bool)}
            improvements = parsed.get("improvements") if isinstance(parsed.get("improvements"), list) else []
            evidence = parsed.get("evidence") if isinstance(parsed.get("evidence"), list) else []
            confidence = parsed.get("confidence") if parsed.get("confidence") in {"low","medium","high"} else "low"
            return {
                "virality_score": score,
                "estimated_min_views": None, "estimated_expected_views": None, "estimated_max_views": None,
                "view_estimate_status": "unavailable_without_connected_platform_analytics",
                "score_status": "available", "score_basis": "qwen_local_editorial_rubric_v1",
                "score_label": "Score éditorial de potentiel — pas une prédiction de vues",
                "not_a_view_prediction": True,
                "summary": str(parsed.get("summary") or "Analyse éditoriale locale terminée.")[:500],
                "improvements": [str(x)[:300] for x in improvements[:5]],
                "component_scores": components,
                "evidence": [str(x)[:300] for x in evidence[:5]],
                "confidence": confidence, "analytics_used": False,
                "confidence_type": "model_self_assessment_not_calibrated",
            }
        except Exception as exc:
            ApexCloudTelemetry.emit("WARNING", "local_qwen_virality_failed", error=str(exc)[:240])
            unavailable["score_status"] = "local_model_failed"
            unavailable["summary"] = "Analyse éditoriale locale indisponible : aucun score de secours n'est fabriqué."
            return unavailable


# =========================================================================
# MOTEUR AUDIO : VOIX OFF TTS & TRANSCRIPTION PAROLES STT
# =========================================================================
async def synthesize_voice_to_file(
    text: str, out_audio_path: str, personnage: str = "narrateur",
    avatar_id: Optional[str] = None, speaking_rate: float = 1.06,
    voice_profile_id: Optional[str] = None, user_id: Optional[str] = None,
) -> Tuple[str, float]:
    clean_text = (text or "").strip()
    if not clean_text:
        raise ValueError("Le texte à prononcer est vide.")
    fields = {"input": clean_text, "voice": "ff_siwis", "language": "fr", "speed": max(0.75, min(1.45, float(speaking_rate)))}
    # Les profils vocaux locaux sont traités par OpenVoice V2 dans le worker, après contrôle propriétaire.
    if voice_profile_id:
        if not user_id or not firestore_client:
            raise RuntimeError("Le clonage vocal local nécessite un profil vérifié dans Firestore.")
        profile = await _get_doc("genia_voice_profiles", voice_profile_id, {})
        if not profile or profile.get("owner") != user_id:
            raise HTTPException(status_code=403, detail="Profil vocal introuvable ou non autorisé.")
        profile_uri = str(profile.get("voice_embedding_gcs_uri") or "")
        if not profile_uri.startswith("gs://"):
            raise HTTPException(status_code=503, detail="L'empreinte OpenVoice de ce profil est indisponible.")
        fields["voice_profile_gcs_uri"] = profile_uri
    response = await run_in_executor(_local_ai_json, "/v1/audio/speech", fields, GENIA_LOCAL_AI_TIMEOUT)
    _copy_local_artifact(response, out_audio_path)
    if not os.path.isfile(out_audio_path) or os.path.getsize(out_audio_path) < 128:
        raise RuntimeError("Le rendu vocal local est vide.")
    return out_audio_path, _probe_media_duration(out_audio_path, default_sec=3.0)


async def _read_upload_limited(upload: UploadFile, max_bytes: int) -> bytes:
    chunks, total = [], 0
    while True:
        chunk = await upload.read(1024 * 1024)
        if not chunk:
            break
        total += len(chunk)
        if total > max_bytes:
            raise HTTPException(status_code=413, detail="Fichier audio trop volumineux.")
        chunks.append(chunk)
    if not total:
        raise HTTPException(status_code=400, detail="Fichier audio vide.")
    return b"".join(chunks)


async def create_openvoice_voice_profile(user_id: str, source_audio: bytes, consent_audio: bytes, display_name: str) -> dict:
    """Enrôle une voix consentante avec OpenVoice V2 et stocke son empreinte dans GCS/Firestore."""
    if not firestore_client or not storage_client:
        raise HTTPException(status_code=503, detail="Firestore et Cloud Storage sont requis pour enregistrer un profil vocal.")
    if not source_audio or len(source_audio) < 4096:
        raise HTTPException(status_code=400, detail="L'enregistrement vocal doit contenir une voix claire de plusieurs secondes.")
    if not consent_audio or len(consent_audio) < 1024:
        raise HTTPException(status_code=400, detail="Un enregistrement de consentement valide est obligatoire.")
    suffix = ".wav"
    tmp_path = f"/tmp/genia_voice_enroll_{uuid.uuid4().hex}{suffix}"
    try:
        with open(tmp_path, "wb") as handle:
            handle.write(source_audio)
        sample_duration = _probe_media_duration(tmp_path, default_sec=0.0)
        if sample_duration < 6.0:
            raise HTTPException(status_code=400, detail="L'échantillon vocal doit durer au moins 6 secondes; 10 à 30 secondes avec une voix claire sont préférables.")
        response = await run_in_executor(
            _local_ai_multipart, "/v1/audio/clone", {}, "file", tmp_path, "voice_sample.wav", GENIA_LOCAL_AI_TIMEOUT
        )
        embedding_uri = str(response.get("gcs_uri") or "")
        if not embedding_uri.startswith("gs://"):
            raise RuntimeError("Le worker OpenVoice n'a pas enregistré l'empreinte dans GCS.")
        profile_id = uuid.uuid4().hex
        profile = {
            "owner": user_id,
            "display_name": display_name[:80],
            "status": "active",
            "provider": "OpenVoice V2",
            "voice_embedding_gcs_uri": embedding_uri,
            "consent_provided": True,
            "consent_sha256": hashlib.sha256(consent_audio).hexdigest(),
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        await _set_doc("genia_voice_profiles", profile_id, profile, {})
        return {"voice_profile_id": profile_id, "display_name": profile["display_name"],
                "status": "active", "provider": "OpenVoice V2", "created_at": profile["created_at"]}
    except HTTPException:
        raise
    except Exception as exc:
        ApexCloudTelemetry.emit("ERROR", "openvoice_profile_creation_failed", user_id=user_id, error=str(exc)[:240])
        raise HTTPException(status_code=502, detail=f"Échec de création du profil OpenVoice V2 : {str(exc)[:500]}") from exc
    finally:
        try: os.remove(tmp_path)
        except OSError: pass


_LYRICS_WORD_TIMESTAMPS: Dict[str, List[Tuple[float, float, str]]] = {}


async def transcribe_song_lyrics(audio_path: str, fallback_text: Optional[str] = None) -> str:
    if fallback_text and fallback_text.strip():
        return fallback_text.strip()
    if not os.path.isfile(audio_path):
        raise FileNotFoundError(audio_path)
    response = await run_in_executor(_local_ai_multipart, "/v1/audio/transcriptions",
                                     {"language": "fr", "word_timestamps": "true"},
                                     "file", audio_path, None, GENIA_LOCAL_AI_TIMEOUT)
    text_value = str(response.get("text") or "").strip()
    if not text_value:
        raise RuntimeError("Whisper local n'a reconnu aucune parole dans le fichier.")
    words = []
    for segment in response.get("segments", []) or []:
        for word in segment.get("words", []) or []:
            try:
                words.append((float(word["start"]), float(word["end"]), str(word["word"])))
            except Exception:
                continue
    _LYRICS_WORD_TIMESTAMPS[audio_path] = words
    return text_value


def _build_timed_lyrics_segments(lyrics_text: str, total_duration: float, audio_path: Optional[str] = None) -> List[Tuple[float, float, str]]:
    """Regroupe les mots réellement horodatés par faster-whisper; pas de synchronisation inventée."""
    words = _LYRICS_WORD_TIMESTAMPS.get(audio_path or "", [])
    if not words: return []
    segments, chunk = [], []
    for word_index, item in enumerate(words):
        chunk.append(item)
        if len(chunk) >= 6 or word_index == len(words)-1:
            segments.append((max(0.0, chunk[0][0]), min(float(total_duration), chunk[-1][1]), " ".join(x[2] for x in chunk)))
            chunk = []
    return [x for x in segments if x[1] > x[0]]


# =========================================================================
# COMPOSITION VISUELLE : OVERLAYS, FILTRES, STICKERS & SIGNATURE « CRÉÉ AVEC GENIA »
# =========================================================================
def _load_font(size: int, bold: bool = True) -> ImageFont.ImageFont:
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    ]
    for path in candidates:
        if os.path.exists(path):
            try:
                return ImageFont.truetype(path, size=size)
            except Exception:
                pass
    return ImageFont.load_default()


def _wrap_text(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.ImageFont, max_width: int) -> List[str]:
    words = text.split()
    if not words:
        return []
    lines: List[str] = []
    cur = words[0]
    for w in words[1:]:
        test = f"{cur} {w}"
        bbox = draw.textbbox((0, 0), test, font=font)
        if (bbox[2] - bbox[0]) <= max_width:
            cur = test
        else:
            lines.append(cur)
            cur = w
    lines.append(cur)
    return lines


def render_overlay_png(
    out_png: str,
    width: int,
    height: int,
    subtitle_text: Optional[str] = None,
    subtitle_position: str = "bottom",
    overlay_title: Optional[str] = None,
    text_style_id: str = "pop_sticker_box",
    sticker_ids: Optional[List[str]] = None,
    sticker_position: str = "top_right",
    include_genia_badge: bool = False,
) -> str:
    canvas = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(canvas)

    if overlay_title and overlay_title.strip():
        title_font = _load_font(max(28, int(height * 0.028)), bold=True)
        t_lines = _wrap_text(draw, overlay_title.strip(), title_font, int(width * 0.84))
        pad_x, pad_y = 22, 12
        line_h = int(title_font.size * 1.25)
        box_h = len(t_lines) * line_h + pad_y * 2
        box_w = min(int(width * 0.88), max((int(draw.textlength(ln, font=title_font)) + pad_x * 2) for ln in t_lines))
        x0 = (width - box_w) // 2
        y0 = int(height * 0.08)

        bg_fill = (15, 23, 42, 220)
        border_fill = (168, 85, 247, 255)
        if text_style_id == "neon_glow":
            bg_fill = (10, 10, 28, 225)
            border_fill = (56, 189, 248, 255)
        elif text_style_id == "gradient_fire":
            bg_fill = (40, 12, 18, 225)
            border_fill = (251, 146, 60, 255)

        draw.rounded_rectangle([x0, y0, x0 + box_w, y0 + box_h], radius=20, fill=bg_fill, outline=border_fill, width=3)
        for idx, ln in enumerate(t_lines):
            lw = int(draw.textlength(ln, font=title_font))
            lx = x0 + (box_w - lw) // 2
            ly = y0 + pad_y + idx * line_h
            draw.text((lx, ly), ln, font=title_font, fill=(255, 255, 255, 255))

    if subtitle_text and subtitle_text.strip():
        sub_font = _load_font(max(30, int(height * 0.031)), bold=True)
        s_lines = _wrap_text(draw, subtitle_text.strip(), sub_font, int(width * 0.82))
        pad_x, pad_y = 24, 14
        line_h = int(sub_font.size * 1.28)
        box_h = len(s_lines) * line_h + pad_y * 2
        box_w = min(int(width * 0.88), max((int(draw.textlength(ln, font=sub_font)) + pad_x * 2) for ln in s_lines))
        x0 = (width - box_w) // 2

        if subtitle_position == "top":
            y0 = int(height * 0.17)
        elif subtitle_position == "center":
            y0 = (height - box_h) // 2
        else:
            y0 = int(height * 0.76) - box_h // 2

        draw.rounded_rectangle([x0, y0, x0 + box_w, y0 + box_h], radius=22, fill=(0, 0, 0, 195), outline=(255, 255, 255, 50), width=2)
        for idx, ln in enumerate(s_lines):
            lw = int(draw.textlength(ln, font=sub_font))
            lx = x0 + (box_w - lw) // 2
            ly = y0 + pad_y + idx * line_h
            color_txt = (253, 224, 71, 255) if idx == 0 else (255, 255, 255, 255)
            draw.text((lx + 2, ly + 2), ln, font=sub_font, fill=(0, 0, 0, 220))
            draw.text((lx, ly), ln, font=sub_font, fill=color_txt)

    chosen_stickers = [STICKERS_CATALOG[sid] for sid in (sticker_ids or [])[:4] if sid in STICKERS_CATALOG]
    if chosen_stickers:
        st_font = _load_font(max(22, int(height * 0.022)), bold=True)
        labels = [f"{s['label']} {s['tag']}" for s in chosen_stickers]
        st_h = int(st_font.size * 1.4) + 12
        st_w = max(int(draw.textlength(lbl, font=st_font)) + 28 for lbl in labels)
        total_h = len(labels) * (st_h + 10)

        pos_map = {
            "top_left": (36, int(height * 0.14)),
            "top_right": (width - st_w - 36, int(height * 0.14)),
            "bottom_left": (36, height - total_h - int(height * 0.14)),
            "bottom_right": (width - st_w - 36, height - total_h - int(height * 0.14)),
            "center": ((width - st_w) // 2, (height - total_h) // 2),
        }
        sx, sy = pos_map.get(sticker_position, pos_map["top_right"])
        sx = max(20, min(width - st_w - 20, sx))
        sy = max(20, min(height - total_h - 20, sy))

        for i, lbl in enumerate(labels):
            item_y = sy + i * (st_h + 10)
            draw.rounded_rectangle([sx, item_y, sx + st_w, item_y + st_h], radius=16, fill=(15, 23, 42, 210), outline=(251, 191, 36, 210), width=2)
            draw.text((sx + 14, item_y + 6), lbl, font=st_font, fill=(255, 255, 255, 255))

    if include_genia_badge:
        badge_font = _load_font(max(20, int(height * 0.020)), bold=True)
        badge_txt = "Créé avec Genia"
        bw = int(draw.textlength(badge_txt, font=badge_font)) + 28
        bh = int(badge_font.size * 1.4) + 10
        bx = width - bw - 28
        by = height - bh - 34
        draw.rounded_rectangle([bx, by, bx + bw, by + bh], radius=14, fill=(9, 13, 24, 215), outline=(251, 191, 36, 220), width=2)
        draw.text((bx + 14, by + 5), badge_txt, font=badge_font, fill=(254, 240, 138, 255))

    canvas.save(out_png, "PNG")
    return out_png


async def generate_avatar_reference_with_gemini(avatar_description: str, output_path: str) -> str:
    response = await run_in_executor(_local_ai_json, "/v1/images/generations", {
        "prompt": "Photorealistic front-facing fictional adult presenter, head and shoulders, neutral expression, "
                   "simple studio background, even lighting, no text or logos. Description: " + avatar_description[:1000],
        "width": 768, "height": 1024
    }, GENIA_LOCAL_AI_TIMEOUT)
    _copy_local_artifact(response, output_path)
    with Image.open(output_path) as image:
        image.verify()
    return output_path


async def generate_photo_edit_with_gemini(
    photo_path: str, output_path: str, insertion_mode: str, photo_model_id: str, caption: Optional[str] = None
) -> str:
    if not os.path.isfile(photo_path):
        raise FileNotFoundError(photo_path)
    prompt = ("Edit this photograph as a polished commercial composition. Preserve existing people and their identities. "
              + f"Mode: {insertion_mode}. Style: {photo_model_id}. Caption concept: {(caption or '')[:300]}")
    data = await run_in_executor(_local_ai_multipart, "/v1/images/edits",
                                 {"prompt": prompt, "strength": "0.35"},
                                 "image", photo_path, None, GENIA_LOCAL_AI_TIMEOUT)
    _copy_local_artifact(data, output_path)
    with Image.open(output_path) as generated:
        generated.verify()
    return output_path


def prepare_styled_photo_frame(
    photo_path: str,
    out_png_path: str,
    width: int,
    height: int,
    photo_model_id: str,
    caption: Optional[str] = None,
    insertion_mode: str = "add_model_to_photos",
) -> str:
    spec = PHOTO_MODELS_CATALOG.get(photo_model_id, PHOTO_MODELS_CATALOG["pm_snap_neon_frame"])
    border_rgba = spec["border_color"]

    bg = Image.new("RGBA", (width, height), (10, 14, 26, 255))
    draw = ImageDraw.Draw(bg)

    if insertion_mode == "add_photos_to_model":
        # Mode écrin : décor thématique complet + médaillon central pour la photo
        draw.rounded_rectangle(
            [24, 24, width - 24, height - 24],
            radius=36,
            fill=(18, 24, 42, 255),
            outline=border_rgba,
            width=8,
        )
        badge_font = _load_font(max(22, int(height * 0.022)), bold=True)
        model_label = spec["name"].upper()
        ml_w = int(draw.textlength(model_label, font=badge_font))
        draw.text(((width - ml_w) // 2, int(height * 0.065)), model_label, font=badge_font, fill=border_rgba)

        margin_x = int(width * 0.13)
        top_y = int(height * 0.16)
        avail_w = width - margin_x * 2
        avail_h = int(height * 0.56)
    else:
        # Mode cadre autour de la photo : la photo occupe l'espace principal avec bordure du modèle
        margin_x = int(width * 0.07)
        top_y = int(height * 0.14)
        avail_w = width - margin_x * 2
        avail_h = int(height * 0.62)

    with Image.open(photo_path) as im:
        rgb = im.convert("RGBA")
        scale = min(avail_w / max(1, rgb.width), avail_h / max(1, rgb.height))
        nw = max(1, int(rgb.width * scale))
        nh = max(1, int(rgb.height * scale))
        resized = rgb.resize((nw, nh), Image.Resampling.LANCZOS)

        pad = 14 if insertion_mode == "add_photos_to_model" else 10
        frame_x0 = (width - nw) // 2 - pad
        frame_y0 = top_y + (avail_h - nh) // 2 - pad
        frame_x1 = frame_x0 + nw + pad * 2
        frame_y1 = frame_y0 + nh + pad * 2

        draw.rounded_rectangle([frame_x0, frame_y0, frame_x1, frame_y1], radius=26, fill=border_rgba)
        bg.paste(resized, (frame_x0 + pad, frame_y0 + pad))

    if caption and caption.strip():
        c_font = _load_font(max(26, int(height * 0.026)), bold=True)
        lines = _wrap_text(draw, caption.strip(), c_font, int(width * 0.84))
        y_cursor = top_y + avail_h + 28
        for ln in lines[:3]:
            lw = int(draw.textlength(ln, font=c_font))
            draw.text(((width - lw) // 2, y_cursor), ln, font=c_font, fill=(255, 255, 255, 255))
            y_cursor += int(c_font.size * 1.3)

    bg.convert("RGB").save(out_png_path, "PNG")
    return out_png_path


def build_animated_still_clip(
    image_path: str, audio_path: Optional[str], out_mp4_path: str,
    width: int, height: int, duration_sec: float, motion: str = "zoom_in",
    filter_spec: Optional[dict] = None, overlay_png_path: Optional[str] = None,
    bgm_url: Optional[str] = None, bgm_volume: float = 0.15, work_dir: str = "/tmp",
) -> str:
    dur=max(1.5,float(duration_sec)); fps=24; frames=max(24,int(dur*fps))
    pre_img=os.path.join(work_dir,f"pre_{uuid.uuid4().hex[:8]}.png")
    with Image.open(image_path) as im:
        ImageOps.fit(im.convert("RGB"),(width*2,height*2),method=Image.Resampling.LANCZOS).save(pre_img,"PNG")
    if motion=="zoom_out": zp=f"zoompan=z='1.25-0.25*on/{frames}':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d={frames}:s={width}x{height}:fps={fps}"
    elif motion=="pan_right": zp=f"zoompan=z='1.15':x='(iw-iw/zoom)*(on/{frames})':y='ih/2-(ih/zoom/2)':d={frames}:s={width}x{height}:fps={fps}"
    elif motion=="pan_left": zp=f"zoompan=z='1.15':x='(iw-iw/zoom)*(1-on/{frames})':y='ih/2-(ih/zoom/2)':d={frames}:s={width}x{height}:fps={fps}"
    elif motion=="static": zp=f"zoompan=z='1.0':x='0':y='0':d={frames}:s={width}x{height}:fps={fps}"
    else: zp=f"zoompan=z='1.0+0.22*on/{frames}':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d={frames}:s={width}x{height}:fps={fps}"
    vf=[zp]
    if filter_spec and filter_spec.get("ffmpeg_eq"): vf.append(filter_spec["ffmpeg_eq"])
    vf.append("format=yuv420p")
    inputs=["-loop","1","-i",pre_img]; next_input=1
    voice_idx=None; bgm_idx=None; overlay_idx=None
    has_voice=bool(audio_path and os.path.isfile(audio_path))
    if has_voice:
        voice_idx=next_input; inputs += ["-i",audio_path]; next_input+=1
    bgm_local=None
    if bgm_url:
        try:
            bgm_local=os.path.join(work_dir,f"bgm_{uuid.uuid4().hex[:8]}.mp3")
            download_remote_file(bgm_url,bgm_local,"bgm")
            bgm_idx=next_input; inputs += ["-stream_loop","-1","-i",bgm_local]; next_input+=1
        except Exception as exc:
            ApexCloudTelemetry.emit("WARNING","bgm_unavailable",error=str(exc)[:160]); bgm_local=None
    if overlay_png_path and os.path.isfile(overlay_png_path):
        overlay_idx=next_input; inputs += ["-loop","1","-i",overlay_png_path]; next_input+=1
    filters=[f"[0:v]{','.join(vf)}[vbase]"]; last_v="[vbase]"
    if overlay_idx is not None:
        filters.append(f"{last_v}[{overlay_idx}:v]overlay=0:0:eof_action=repeat:shortest=0[vout]"); last_v="[vout]"
    audio_labels=[]
    if voice_idx is not None:
        filters.append(f"[{voice_idx}:a]aresample=48000,volume=1.0[voice]"); audio_labels.append("[voice]")
    if bgm_idx is not None:
        filters.append(f"[{bgm_idx}:a]aresample=48000,volume={max(0.0,min(0.6,bgm_volume))}[bgma]"); audio_labels.append("[bgma]")
    if not audio_labels:
        silent_idx=next_input; inputs += ["-f","lavfi","-i","anullsrc=r=48000:cl=stereo"]; audio_map=["-map",f"{silent_idx}:a"]
    elif len(audio_labels)==1:
        filters.append(f"{audio_labels[0]}anull[aout]"); audio_map=["-map","[aout]"]
    else:
        filters.append("".join(audio_labels)+f"amix=inputs={len(audio_labels)}:duration=longest:dropout_transition=2[aout]"); audio_map=["-map","[aout]"]
    cmd=["ffmpeg","-y",*inputs,"-filter_complex",";".join(filters),"-map",last_v,*audio_map,
         "-t",f"{dur:.2f}","-c:v","libx264","-preset","veryfast","-crf","23","-pix_fmt","yuv420p",
         "-c:a","aac","-b:a","128k","-ar","48000","-movflags","+faststart",out_mp4_path]
    _run_cmd(cmd,label="build_animated_still_clip")
    return out_mp4_path


def _media_has_audio(path: str) -> bool:
    try:
        proc = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=codec_type", "-of", "csv=p=0", path],
                              capture_output=True, text=True, timeout=30)
        return proc.returncode == 0 and bool(proc.stdout.strip())
    except Exception: return False


def normalize_video_clip(
    input_video_path: str, out_mp4_path: str, width: int, height: int,
    target_duration: Optional[float] = None, playback_speed: float = 1.0,
    zoom_factor: float = 1.0, filter_spec: Optional[dict] = None,
    overlay_png_path: Optional[str] = None, bgm_url: Optional[str] = None,
    bgm_volume: float = 0.15, work_dir: str = "/tmp", voice_audio_path: Optional[str] = None,
) -> str:
    speed=max(0.5,min(1.75,float(playback_speed)))
    vf=[f"scale={width}:{height}:force_original_aspect_ratio=increase",f"crop={width}:{height}"]
    if zoom_factor>1.01:
        z=min(float(zoom_factor),1.5)
        vf += [f"scale=ceil(iw*{z:.3f}/2)*2:ceil(ih*{z:.3f}/2)*2",f"crop={width}:{height}:(iw-{width})/2:(ih-{height})/2"]
    if abs(speed-1.0)>0.01: vf.append(f"setpts=PTS/{speed:.4f}")
    vf += ["setsar=1","fps=24"]
    if filter_spec and filter_spec.get("ffmpeg_eq"): vf.append(filter_spec["ffmpeg_eq"])
    vf.append("format=yuv420p")
    inputs=["-i",input_video_path]; next_input=1
    has_source_audio=_media_has_audio(input_video_path)
    voice_idx=None; bgm_idx=None; overlay_idx=None
    if voice_audio_path and os.path.isfile(voice_audio_path):
        voice_idx=next_input; inputs += ["-i",voice_audio_path]; next_input+=1
    bgm_local=None
    if bgm_url:
        try:
            bgm_local=os.path.join(work_dir,f"bgm_{uuid.uuid4().hex[:8]}.mp3")
            download_remote_file(bgm_url,bgm_local,"bgm")
            bgm_idx=next_input; inputs += ["-stream_loop","-1","-i",bgm_local]; next_input+=1
        except Exception as exc:
            ApexCloudTelemetry.emit("WARNING","bgm_unavailable",error=str(exc)[:160])
    if overlay_png_path and os.path.isfile(overlay_png_path):
        overlay_idx=next_input; inputs += ["-loop","1","-i",overlay_png_path]; next_input+=1
    filters=[f"[0:v]{','.join(vf)}[vbase]"]; last_v="[vbase]"
    if overlay_idx is not None:
        filters.append(f"{last_v}[{overlay_idx}:v]overlay=0:0:eof_action=repeat:shortest=0[vout]"); last_v="[vout]"
    audio_labels=[]
    if has_source_audio:
        filters.append(f"[0:a]aresample=48000,atempo={speed:.4f},volume=0.35[srca]"); audio_labels.append("[srca]")
    if voice_idx is not None:
        filters.append(f"[{voice_idx}:a]aresample=48000,volume=1.0[voice]"); audio_labels.append("[voice]")
    if bgm_idx is not None:
        filters.append(f"[{bgm_idx}:a]aresample=48000,volume={max(0.0,min(0.6,bgm_volume))}[bgma]"); audio_labels.append("[bgma]")
    if not audio_labels:
        silent_idx=next_input; inputs += ["-f","lavfi","-i","anullsrc=r=48000:cl=stereo"]; amap=["-map",f"{silent_idx}:a"]
    elif len(audio_labels)==1:
        filters.append(f"{audio_labels[0]}anull[aout]"); amap=["-map","[aout]"]
    else:
        filters.append("".join(audio_labels)+f"amix=inputs={len(audio_labels)}:duration=longest:dropout_transition=2[aout]"); amap=["-map","[aout]"]
    cmd=["ffmpeg","-y",*inputs,"-filter_complex",";".join(filters),"-map",last_v,*amap]
    if target_duration and target_duration>0.5: cmd += ["-t",f"{target_duration:.2f}"]
    cmd += ["-c:v","libx264","-preset","veryfast","-crf","23","-pix_fmt","yuv420p","-c:a","aac","-b:a","128k","-ar","48000","-movflags","+faststart",out_mp4_path]
    _run_cmd(cmd,label="normalize_video_clip")
    return out_mp4_path


def _probe_dimensions(path: str) -> Tuple[int, int]:
    proc = subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries","stream=width,height","-of","json",path],
                          capture_output=True,text=True,timeout=30)
    data=json.loads(proc.stdout or "{}")
    streams=data.get("streams") or []
    if not streams: raise RuntimeError(f"Aucun flux vidéo valide dans {path}")
    return int(streams[0]["width"]),int(streams[0]["height"])


def concat_clips_and_thumb(clip_paths: List[str], out_mp4_path: str, out_thumb_path: str,
                           work_dir: str, transition_style: str = "cut") -> str:
    if not clip_paths: raise RuntimeError("Aucun clip à assembler.")
    width,height=_probe_dimensions(clip_paths[0])
    normalized=[]; durations=[]
    for idx,src in enumerate(clip_paths):
        dst=os.path.join(work_dir,f"concat_norm_{idx}.mp4")
        if _media_has_audio(src):
            cmd=["ffmpeg","-y","-i",src,"-vf",f"scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},fps=24,setsar=1,format=yuv420p",
                 "-af","aresample=48000,aformat=channel_layouts=stereo,apad","-map","0:v:0","-map","0:a:0",
                 "-c:v","libx264","-preset","veryfast","-crf","23","-c:a","aac","-b:a","128k","-ar","48000","-ac","2", "-shortest",dst]
        else:
            cmd=["ffmpeg","-y","-i",src,"-f","lavfi","-i","anullsrc=r=48000:cl=stereo",
                 "-vf",f"scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},fps=24,setsar=1,format=yuv420p",
                 "-map","0:v:0","-map","1:a:0","-c:v","libx264","-preset","veryfast","-crf","23",
                 "-c:a","aac","-b:a","128k","-ar","48000","-ac","2","-shortest",dst]
        _run_cmd(cmd,label=f"normalize_concat_clip_{idx}")
        normalized.append(dst); durations.append(_probe_media_duration(dst,default_sec=3.0))
    inputs=[]
    for path in normalized: inputs += ["-i",path]
    chains=[]
    for i in range(len(normalized)):
        chains.append(f"[{i}:v]settb=AVTB,setpts=PTS-STARTPTS,fps=24,format=yuv420p[v{i}]")
        chains.append(f"[{i}:a]aresample=48000,aformat=channel_layouts=stereo,asetpts=PTS-STARTPTS[a{i}]")
    if transition_style == "crossfade" and len(normalized)>1:
        fade=min(0.35,max(0.10,min(durations)/3))
        prev_v="[v0]"; prev_a="[a0]"; elapsed=durations[0]
        for i in range(1,len(normalized)):
            offset=max(0.0,elapsed-fade)
            outv=f"[vx{i}]"; outa=f"[ax{i}]"
            chains.append(f"{prev_v}[v{i}]xfade=transition=fade:duration={fade:.3f}:offset={offset:.3f}{outv}")
            chains.append(f"{prev_a}[a{i}]acrossfade=d={fade:.3f}:c1=tri:c2=tri{outa}")
            prev_v,prev_a=outv,outa
            elapsed=offset+durations[i]
        vout,aout=prev_v,prev_a
    else:
        joined="".join(f"[v{i}][a{i}]" for i in range(len(normalized)))
        chains.append(f"{joined}concat=n={len(normalized)}:v=1:a=1[vout][aout]")
        vout,aout="[vout]","[aout]"
    _run_cmd(["ffmpeg","-y",*inputs,"-filter_complex",";".join(chains),"-map",vout,"-map",aout,
              "-c:v","libx264","-preset","veryfast","-crf","23","-pix_fmt","yuv420p",
              "-c:a","aac","-b:a","128k","-ar","48000","-movflags","+faststart",out_mp4_path],label="concat_final")
    _run_cmd(["ffmpeg","-y","-ss","0.4","-i",out_mp4_path,"-frames:v","1","-q:v","3",out_thumb_path],label="thumbnail")
    return out_mp4_path


# =========================================================================
# PIPELINES DE TRAITEMENT ASYNCHRONE
# =========================================================================
async def execute_master_pipeline(job_id: str, req_data: dict, user_id: str):
    async with RENDER_SEMAPHORE:
        work_dir = f"/tmp/apex_job_{job_id}"
        os.makedirs(work_dir, exist_ok=True)
        final_output = os.path.join(work_dir, f"apex_master_{job_id}.mp4")
        thumb_output = os.path.join(work_dir, f"thumb_{job_id}.jpg")
        charged_credits = int(req_data.get("_charged_credits", 0))

        avatar_mode = req_data.get("avatar_mode", "single_avatar")
        selected_avatar_id = req_data.get("avatar_id")
        keep_same_avatar = bool(req_data.get("keep_same_avatar", True))
        voice_profile_id = req_data.get("voice_profile_id")
        lip_sync_mode = req_data.get("lip_sync_mode", "auto")
        if lip_sync_mode not in {"auto", "native_omni", "google_tts", "latentsync"}:
            raise ValueError("lip_sync_mode doit être auto, latentsync ou google_tts.")
        transition_style = req_data.get("transition_style", "cut")
        catalog_avatar = AVATAR_MODELS_CATALOG.get(selected_avatar_id) if selected_avatar_id else None
        filter_spec = get_filter_spec(req_data.get("filter_id"))
        aspect_ratio = req_data.get("aspect_ratio", "9:16")
        vid_w, vid_h = get_dimensions(aspect_ratio)
        subtitle_position = req_data.get("subtitle_position", "bottom")
        show_subtitles = bool(req_data.get("show_subtitles", True))
        voice_rate = float(req_data.get("voice_speaking_rate", 1.06))
        bgm_url = req_data.get("bgm_url")
        bgm_volume = float(req_data.get("bgm_volume", 0.15))
        overlay_title = req_data.get("overlay_title")
        text_style_id = req_data.get("text_style_id", "pop_sticker_box")
        sticker_ids = req_data.get("sticker_ids", [])
        sticker_position = req_data.get("sticker_position", "top_right")

        avatar_description = (
            req_data.get("avatar_description")
            or (catalog_avatar["avatar_description"] if catalog_avatar else None)
            or "single stylized 3D animated avatar character with consistent appearance, natural lip-sync and expressive gestures"
        )
        default_gesture = (
            catalog_avatar["default_gesture"]
            if catalog_avatar
            else "expressive hand gestures, natural facial expressions and engaging body language"
        )
        max_total_dur = min(MAX_VIDEO_DURATION_SEC, float(req_data.get("max_total_duration_sec", 30.0)))
        avatar_reference_path = None

        try:
            claimed = await claim_job_for_processing(job_id, user_id, "avatar_pipeline")
            if not claimed:
                return

            await set_job_store(job_id, {"step": "Préparation du scénario et des scènes"})
            raw_scenes = req_data.get("scenes") or []
            if not raw_scenes and req_data.get("raw_script_input"):
                raw_scenes = await ApexManagedGoogleModels.expand_script_into_scenes(
                    raw_script=req_data["raw_script_input"],
                    avatar_mode=avatar_mode,
                    num_scenes=int(req_data.get("auto_multi_scenes_count", 3)),
                    avatar_description=avatar_description,
                    default_gesture=default_gesture,
                )

            if not raw_scenes:
                raise RuntimeError("Aucune scène à générer.")

            if avatar_mode == "single_avatar":
                try:
                    avatar_reference_path = os.path.join(work_dir, "avatar_identity_reference.png")
                    await generate_avatar_reference_with_gemini(avatar_description, avatar_reference_path)
                except Exception as avatar_ref_error:
                    avatar_reference_path = None
                    ApexCloudTelemetry.emit("WARNING", "avatar_reference_generation_unavailable", job_id=job_id,
                                            error=str(avatar_ref_error)[:200])

            clip_paths: List[str] = []
            elapsed_total = 0.0
            scene_lip_sync_modes: List[str] = []
            scene_avatar_identity_modes: List[str] = []
            scene_engine_modes: List[str] = []
            scene_dialogue_checks: List[dict] = []

            for idx, sc in enumerate(raw_scenes):
                if elapsed_total >= max_total_dur:
                    break
                cur_job = await get_job_store(job_id)
                if cur_job and (cur_job.get("cancel_requested") or cur_job.get("status") == "cancelled"):
                    await set_job_store(job_id, {"status":"cancelled","step":"Annulé"})
                    if charged_credits > 0:
                        await refund_credits(user_id, charged_credits, f"Annulation rendu {job_id}")
                    return

                await set_job_store(job_id, {"step": f"Voix off et animation de la scène {idx + 1}/{len(raw_scenes)}"})
                role = sc.get("personnage", "narrateur")
                spoken_text = sc.get("texte", "")
                vis_prompt = sc.get("visual_prompt", "")

                use_single_voice = avatar_mode == "single_avatar" or keep_same_avatar
                remaining_budget = max(0.0, max_total_dur - elapsed_total)
                estimated_words_duration = max(3.0, len(spoken_text.split()) / 2.45)
                live_avatar_requested = bool(
                    ENABLE_GEMINI_LIVE_AVATAR
                    and avatar_mode == "single_avatar"
                    and False
                )
                if live_avatar_requested and voice_profile_id and not avatar_reference_path:
                    raise RuntimeError("Gemini Live Avatar est activé pour une voix clonée, mais l'image de référence de l'avatar n'a pas pu être créée. Aucun rendu TTS désynchronisé de remplacement ne sera lancé.")
                if live_avatar_requested and voice_profile_id and remaining_budget < 3.0:
                    raise RuntimeError("Il ne reste pas assez de temps pour générer une scène Gemini Live Avatar complète; la phrase ne sera pas coupée.")
                use_live_avatar = bool(
                    live_avatar_requested
                    and avatar_reference_path
                    and 3.0 <= remaining_budget
                )
                # Compatibilité avec les anciens clients : native_omni est redirigé
                # vers le pipeline local Wan + LatentSync, sans appel Gemini.
                use_omni_native = bool(
                    False
                    and not use_live_avatar
                    and ENABLE_GEMINI_OMNI_NATIVE_AVATAR
                    and avatar_mode == "single_avatar"
                    and avatar_reference_path
                    and not voice_profile_id
                    and lip_sync_mode != "google_tts"
                    and (lip_sync_mode == "native_omni" or (lip_sync_mode == "auto" and not selected_avatar_id))
                    and 3.0 <= remaining_budget
                    and estimated_words_duration <= 15.0
                )
                audio_file = os.path.join(work_dir, f"voice_{idx}.mp3")
                voice_dur = 0.0
                if use_live_avatar:
                    # Gemini Live audio/vidéo est limité à 2 minutes par session; marge de sécurité 10 s.
                    live_budget = min(110.0, remaining_budget)
                    if estimated_words_duration > live_budget + 0.5:
                        raise RuntimeError("Le texte estimé dépasse le temps restant pour Gemini Live Avatar; la phrase ne sera pas coupée.")
                    scene_dur = min(live_budget, estimated_words_duration)
                elif use_omni_native:
                    omni_requested_duration = int(math.ceil(estimated_words_duration))
                    if omni_requested_duration > remaining_budget:
                        raise RuntimeError("La durée minimale entière de Gemini Omni dépasse le temps restant; la phrase ne sera pas coupée.")
                    scene_dur = float(omni_requested_duration)
                else:
                    _, voice_dur = await synthesize_voice_to_file(
                        text=spoken_text,
                        out_audio_path=audio_file,
                        personnage=role,
                        avatar_id=selected_avatar_id if use_single_voice else None,
                        speaking_rate=voice_rate,
                        voice_profile_id=voice_profile_id,
                        user_id=user_id,
                    )
                    if voice_dur > remaining_budget + 0.05:
                        raise RuntimeError(
                            f"La voix de la scène {idx + 1} ({voice_dur:.2f}s) dépasse le temps restant ({remaining_budget:.2f}s). "
                            "Genia arrête le rendu plutôt que de couper la phrase ou de dépasser la durée autorisée."
                        )
                    scene_dur = min(voice_dur + 0.35, remaining_budget)

                ref_img_local = None
                if sc.get("image_source_url"):
                    try:
                        ref_img_local = os.path.join(work_dir, f"ref_{idx}.jpg")
                        await run_in_executor(download_remote_file,sc["image_source_url"],ref_img_local,job_id)
                    except Exception:
                        ref_img_local = avatar_reference_path
                elif avatar_reference_path:
                    ref_img_local = avatar_reference_path

                scene_avatar_desc = (
                    avatar_description
                    if use_single_voice
                    else f"Expressive character playing role '{role}', natural lip-sync talking motion"
                )
                full_visual_prompt = (
                    f"{scene_avatar_desc}. Scene action: {vis_prompt}. "
                    f"Gestures: {default_gesture}. Speaking naturally in French."
                )

                veo_raw = os.path.join(work_dir, f"veo_raw_{idx}.mp4")
                overlay_png = os.path.join(work_dir, f"ov_{idx}.png")
                await run_in_executor(
                    render_overlay_png,
                    out_png=overlay_png,
                    width=vid_w,
                    height=vid_h,
                    subtitle_text=spoken_text if show_subtitles else None,
                    subtitle_position=subtitle_position,
                    overlay_title=overlay_title if idx == 0 else None,
                    text_style_id=text_style_id,
                    sticker_ids=sticker_ids,
                    sticker_position=sticker_position,
                    include_genia_badge=False,
                )

                scene_out = os.path.join(work_dir, f"scene_{idx}.mp4")
                generated_veo = False
                generated_omni = False
                generated_live = False
                if use_live_avatar:
                    live_prompt = (
                        f"Parle en français et prononce exactement ce texte, sans aucune modification: {spoken_text}. "
                        "L'image de visage configurée dans l'avatar est l'identité du présentateur. Si une image de scène est jointe, "
                        "utilise-la uniquement comme contexte de décor, d'objet ou de lieu, sans remplacer l'identité du présentateur. "
                        f"Format vidéo demandé: {aspect_ratio}. Action visuelle pendant la prise de parole: {full_visual_prompt}. "
                        "Garde le visage bien visible, regarde la caméra, effectue des gestes sobres et termine lorsque le texte est fini."
                    )
                    await ApexManagedGoogleModels.generate_live_avatar_clip(
                        prompt_text=live_prompt,
                        reference_image_path=avatar_reference_path,
                        output_mp4_path=veo_raw,
                        job_id=job_id,
                        scene_index=idx,
                        avatar_voice_name=(AVATAR_MODELS_CATALOG.get(selected_avatar_id) or {}).get("voice_name", "Puck"),
                        voice_profile_id=voice_profile_id,
                        user_id=user_id,
                        aspect_ratio=aspect_ratio,
                        additional_reference_image_path=ref_img_local if ref_img_local != avatar_reference_path else None,
                    )
                    generated_live = True
                    scene_dur = _probe_media_duration(veo_raw, default_sec=scene_dur)
                    if scene_dur > remaining_budget + 0.25:
                        raise RuntimeError("Gemini Live Avatar a dépassé la durée restante autorisée; la scène n'est pas tronquée automatiquement.")
                    dialogue_check = {"scene": idx, "status": "unavailable", "similarity": None, "recognized_text": None}
                    if stt_client and storage_client:
                        try:
                            recognized_text = await transcribe_song_lyrics(veo_raw)
                            normalize_words = lambda value: re.sub(r"[^a-z0-9 ]+", " ", (value or "").lower()).split()
                            expected_words = normalize_words(spoken_text)
                            recognized_words = normalize_words(recognized_text)
                            similarity = difflib.SequenceMatcher(None, expected_words, recognized_words).ratio() if expected_words else 0.0
                            dialogue_check = {
                                "scene": idx,
                                "status": "speech_text_close" if similarity >= 0.82 else "speech_text_mismatch_review_required",
                                "similarity": round(similarity, 3),
                                "recognized_text": recognized_text[:1200],
                            }
                            if similarity < 0.55:
                                raise DialogueTranscriptMismatchError(
                                    f"La vérification Google Speech-to-Text de la scène {idx + 1} ne correspond pas suffisamment au texte demandé (similarité {similarity:.2f}); rendu arrêté."
                                )
                        except DialogueTranscriptMismatchError:
                            raise
                        except Exception as stt_error:
                            dialogue_check = {"scene": idx, "status": "validation_failed_or_unavailable", "similarity": None, "recognized_text": None}
                            ApexCloudTelemetry.emit("WARNING", "live_avatar_dialogue_validation_unavailable", job_id=job_id, scene=idx, error=str(stt_error)[:180])
                    scene_dialogue_checks.append(dialogue_check)
                elif use_omni_native:
                    omni_prompt = (
                        f"Create a polished talking-presenter video, aspect ratio {aspect_ratio}. "
                        "Use the supplied reference image as the same adult presenter. Preserve the person's face, "
                        "hair, clothing, skin appearance and overall identity as closely as possible. "
                        "The first reference image defines the presenter identity. If a second reference image is supplied, "
                        "use it only as scene/location/product context; do not replace the presenter with it. "
                        "The presenter must speak the following French sentence exactly, with natural facial motion, "
                        "clear audible French speech and mouth movements synchronized to the generated speech. "
                        "Do not paraphrase, omit, translate or add words. Do not add another speaker. "
                        f"If a Google voice preset was selected, use only its broad vocal characteristics as a style hint: {(AVATAR_MODELS_CATALOG.get(selected_avatar_id) or {}).get('voice_name', 'natural French voice')}. "
                        f"Requested speaking rate: {voice_rate:.2f}. The native generated voice is not guaranteed to be identical to the Google TTS preset. "
                        f"Dialogue exact: {spoken_text}\n"
                        f"Visual action: {full_visual_prompt}\n"
                        "Keep the face clearly visible while speaking. No subtitles, captions, watermarks or text; "
                        "Genia will add the final graphic overlays separately."
                    )
                    await ApexManagedGoogleModels.generate_omni_avatar_clip(
                        prompt_text=omni_prompt,
                        reference_image_path=avatar_reference_path,
                        output_mp4_path=veo_raw,
                        duration_sec=int(scene_dur),
                        aspect_ratio=aspect_ratio,
                        job_id=job_id,
                        scene_index=idx,
                        additional_reference_image_path=ref_img_local if ref_img_local != avatar_reference_path else None,
                    )
                    generated_omni = True
                    scene_dur = _probe_media_duration(veo_raw, default_sec=scene_dur)
                    if scene_dur > remaining_budget + 0.25:
                        raise RuntimeError("Gemini Omni a dépassé la durée restante autorisée; la scène n'est pas tronquée automatiquement.")
                    dialogue_check = {"scene": idx, "status": "unavailable", "similarity": None, "recognized_text": None}
                    if stt_client and storage_client:
                        try:
                            recognized_text = await transcribe_song_lyrics(veo_raw)
                            normalize_words = lambda value: re.sub(r"[^a-z0-9 ]+", " ", (value or "").lower()).split()
                            expected_words = normalize_words(spoken_text)
                            recognized_words = normalize_words(recognized_text)
                            similarity = difflib.SequenceMatcher(None, expected_words, recognized_words).ratio() if expected_words else 0.0
                            dialogue_check = {
                                "scene": idx,
                                "status": "speech_text_close" if similarity >= 0.82 else "speech_text_mismatch_review_required",
                                "similarity": round(similarity, 3),
                                "recognized_text": recognized_text[:1200],
                            }
                            if similarity < 0.55:
                                raise DialogueTranscriptMismatchError(
                                    f"La vérification Google Speech-to-Text de la scène {idx + 1} ne correspond pas suffisamment au texte demandé (similarité {similarity:.2f}); rendu arrêté pour éviter une fausse validation."
                                )
                        except DialogueTranscriptMismatchError:
                            raise
                        except Exception as stt_error:
                            dialogue_check = {"scene": idx, "status": "validation_failed_or_unavailable", "similarity": None, "recognized_text": None}
                            ApexCloudTelemetry.emit("WARNING", "omni_dialogue_transcript_validation_unavailable", job_id=job_id, scene=idx, error=str(stt_error)[:180])
                    scene_dialogue_checks.append(dialogue_check)
                else:
                    try:
                        await ApexManagedGoogleModels.generate_veo_clip(
                            prompt_text=full_visual_prompt,
                            output_mp4_path=veo_raw,
                            duration_sec=int(round(scene_dur)),
                            aspect_ratio=aspect_ratio,
                            job_id=job_id,
                            ref_image_path=ref_img_local,
                        )
                        generated_veo = True
                    except Exception as veo_err:
                        ApexCloudTelemetry.emit("WARNING", "veo_clip_fallback", job_id=job_id, scene=idx, error=str(veo_err)[:200])

                if (generated_live or generated_omni) and os.path.exists(veo_raw):
                    if not _media_has_audio(veo_raw):
                        raise RuntimeError("La scène Gemini Live/Omni ne contient pas son audio natif; aucune voix externe ne sera ajoutée pour masquer ce défaut.")
                    omni_inputs = ["-i", veo_raw, "-loop", "1", "-i", overlay_png]
                    bgm_local = None
                    if bgm_url:
                        try:
                            bgm_local = os.path.join(work_dir, f"omni_bgm_{idx}.mp3")
                            await run_in_executor(download_remote_file, bgm_url, bgm_local, job_id)
                            omni_inputs.extend(["-stream_loop", "-1", "-i", bgm_local])
                        except Exception as bgm_error:
                            ApexCloudTelemetry.emit("WARNING", "omni_background_music_unavailable", job_id=job_id, scene=idx, error=str(bgm_error)[:160])
                            bgm_local = None
                    fc = (
                        f"[0:v]scale={vid_w}:{vid_h}:force_original_aspect_ratio=increase,crop={vid_w}:{vid_h},fps=24"
                        + (f",{filter_spec['ffmpeg_eq']}" if filter_spec and filter_spec.get("ffmpeg_eq") else "")
                        + ",format=yuv420p[v0];[v0][1:v]overlay=0:0:eof_action=repeat:shortest=0[vout]"
                    )
                    if bgm_local:
                        fc += f";[0:a]aresample=48000[orig];[2:a]volume={max(0.0, min(0.6, bgm_volume))}[bgma];[orig][bgma]amix=inputs=2:duration=first:dropout_transition=2[aout]"
                    else:
                        fc += ";[0:a]aresample=48000[aout]"
                    await run_in_executor(
                        _run_cmd,
                        ["ffmpeg", "-y", *omni_inputs, "-filter_complex", fc,
                         "-map", "[vout]", "-map", "[aout]", "-t", f"{scene_dur:.2f}",
                         "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
                         "-c:a", "aac", "-b:a", "128k", scene_out],
                        label="mux_gemini_omni_native_audio_overlay",
                    )
                    if generated_live:
                        scene_lip_sync_modes.append("google_gemini_3_8_live_native_avatar_custom_voice_sync" if voice_profile_id else "google_gemini_3_8_live_native_avatar_prebuilt_voice_sync")
                        scene_avatar_identity_modes.append("gemini_live_custom_avatar_reference_guided_not_identity_perfect")
                        scene_engine_modes.append("gemini_3_8_live_avatar")
                    else:
                        scene_lip_sync_modes.append("google_gemini_omni_native_audio_video_sync")
                        scene_avatar_identity_modes.append("gemini_omni_reference_guided_consistency_not_hard_identity_lock")
                        scene_engine_modes.append("gemini_omni_1_2_flash")
                elif generated_veo and os.path.exists(veo_raw):
                    mux_inputs = ["-i", veo_raw, "-i", audio_file, "-loop", "1", "-i", overlay_png]
                    bgm_local = None
                    if bgm_url:
                        try:
                            bgm_local = os.path.join(work_dir, f"veo_bgm_{idx}.mp3")
                            await run_in_executor(download_remote_file,bgm_url,bgm_local,job_id)
                            mux_inputs.extend(["-stream_loop", "-1", "-i", bgm_local])
                        except Exception:
                            bgm_local = None

                    fc = (
                        f"[0:v]scale={vid_w}:{vid_h}:force_original_aspect_ratio=increase,crop={vid_w}:{vid_h},fps=24"
                        + (f",{filter_spec['ffmpeg_eq']}" if filter_spec and filter_spec.get("ffmpeg_eq") else "")
                        + ",format=yuv420p[v0];[v0][2:v]overlay=0:0:eof_action=repeat:shortest=0[vout]"
                    )
                    if bgm_local:
                        fc += f";[3:a]volume={max(0.0, min(0.6, bgm_volume))}[bgma];[1:a][bgma]amix=inputs=2:duration=first:dropout_transition=2[aout]"
                        a_map = "[aout]"
                    else:
                        a_map = "1:a"

                    cmd_mux = [
                        "ffmpeg", "-y", *mux_inputs, "-filter_complex", fc,
                        "-map", "[vout]", "-map", a_map, "-t", f"{scene_dur:.2f}",
                        "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
                        "-c:a", "aac", "-b:a", "128k", scene_out,
                    ]
                    await run_in_executor(_run_cmd,cmd_mux,label="mux_wan_voice_overlay")
                    if avatar_reference_path and lip_sync_mode != "google_tts":
                        synced_out = os.path.join(work_dir, f"scene_{idx}_latentsync.mp4")
                        # The worker accepts both the video and generated audio as multipart fields.
                        sync_data = await run_in_executor(
                            _local_ai_multipart_two_files, "/v1/videos/lipsync",
                            {"inference_steps": 20, "guidance_scale": 1.5},
                            "video", scene_out, "audio", audio_file, GENIA_LOCAL_AI_TIMEOUT
                        )
                        _copy_local_artifact(sync_data, synced_out)
                        _validate_media_file(synced_out)
                        os.replace(synced_out, scene_out)
                        scene_lip_sync_modes.append("latentsync_1_5_audio_conditioned")
                    else:
                        scene_lip_sync_modes.append("voiceover_no_avatar_lipsync_requested")
                    scene_avatar_identity_modes.append("wan_reference_guided_avatar_not_hard_identity_lock")
                    scene_engine_modes.append("wan_2_2_ti2v_5b")
                else:
                    raise RuntimeError(
                        f"Aucun moteur vidéo n'a généré la scène {idx + 1}. Genia n'insère pas une image fixe ni une vidéo de remplacement; le rendu est arrêté et les crédits seront remboursés."
                    )

                clip_paths.append(scene_out)
                elapsed_total += _probe_media_duration(scene_out, default_sec=scene_dur)

            await set_job_store(job_id, {"step": "Assemblage final de la vidéo MP4"})
            await run_in_executor(concat_clips_and_thumb,clip_paths,final_output,thumb_output,work_dir,transition_style=transition_style)
            total_dur = round(_probe_media_duration(final_output, default_sec=elapsed_total), 2)

            video_url = await run_in_executor(ensure_bucket_and_upload,final_output,f"renders/{user_id}/{job_id}.mp4",job_id)
            thumb_url = await run_in_executor(ensure_bucket_and_upload,thumb_output,f"renders/{user_id}/{job_id}.jpg",job_id)

            final_state = await get_job_store(job_id)
            if final_state and final_state.get("cancel_requested"):
                if charged_credits > 0: await refund_credits(user_id,charged_credits,f"Annulation rendu {job_id}")
                await set_job_store(job_id,{"status":"cancelled","step":"Annulé"})
                return
            await set_job_store(job_id, {
                "status": "completed",
                "step": "Terminé",
                "mode": "avatar",
                "quality_status": (
                    "wan2_2_with_latentsync_1_5_and_openvoice_v2" if voice_profile_id and scene_lip_sync_modes and all(x == "latentsync_1_5_audio_conditioned" for x in scene_lip_sync_modes)
                    else "wan2_2_with_latentsync_1_5_and_kokoro" if scene_lip_sync_modes and all(x == "latentsync_1_5_audio_conditioned" for x in scene_lip_sync_modes)
                    else "wan2_2_with_local_voiceover"
                ),
                "lip_sync_status": (
                    "latentsync_1_5_audio_conditioned" if scene_lip_sync_modes and all(x == "latentsync_1_5_audio_conditioned" for x in scene_lip_sync_modes)
                    else "not_requested_or_no_avatar_reference"
                ),
                "voice_clone_status": "openvoice_v2_personalized_voice" if voice_profile_id else "no_custom_voice_profile",
                "voice_selection_status": "openvoice_v2_custom_voice" if voice_profile_id else "kokoro_french_standard_voice",
                "avatar_identity_status": "wan_reference_guided_not_hard_identity_lock",
                "scene_engine_modes": scene_engine_modes,
                "scene_lip_sync_modes": scene_lip_sync_modes,
                "scene_avatar_identity_modes": scene_avatar_identity_modes,
                "scene_dialogue_checks": scene_dialogue_checks,
                "dialogue_text_validation": (
                    "faster_whisper_checked" if scene_dialogue_checks and all(x.get("status") == "speech_text_close" for x in scene_dialogue_checks)
                    else "partial_or_unavailable_check"
                ),
                "free_tier": False,
                "video_url": video_url,
                "thumbnail_url": thumb_url,
                "duration_sec": total_dur,
            })
        except Exception as exc:
            ApexCloudTelemetry.emit("ERROR", "master_pipeline_failed", job_id=job_id, user_id=user_id, error=str(exc)[:260])
            if charged_credits > 0:
                await refund_credits(user_id, charged_credits, f"Échec rendu {job_id}")
            await set_job_store(job_id, {
                "status": "failed",
                "step": "Échec",
                "error": str(exc)[:300],
            })
        finally:
            shutil.rmtree(work_dir, ignore_errors=True)


class ApexTemplateAndPhotoEngine:
    @staticmethod
    async def process_template_job(job_id: str, user_id: str, payload: TemplateApplyRequest, max_allowed_dur: float):
        async with RENDER_SEMAPHORE:
            work_dir = f"/tmp/apex_tpl_{job_id}"
            os.makedirs(work_dir, exist_ok=True)
            final_mp4 = os.path.join(work_dir, f"tpl_{job_id}.mp4")
            thumb_jpg = os.path.join(work_dir, f"tpl_{job_id}.jpg")

            try:
                claimed = await claim_job_for_processing(job_id, user_id, "template_free")
                if not claimed:
                    return

                tpl_spec = await get_template_by_id(payload.template_id)
                if not tpl_spec:
                    raise HTTPException(status_code=404, detail="Modèle vidéo introuvable.")

                vid_w, vid_h = get_dimensions(payload.aspect_ratio)
                filter_spec = get_filter_spec(payload.filter_id)
                clips: List[str] = []
                elapsed = 0.0

                for idx, item in enumerate(payload.media_items):
                    current = await get_job_store(job_id)
                    if current and current.get("cancel_requested"): raise RuntimeError("Tâche annulée par l'utilisateur.")
                    if elapsed >= max_allowed_dur:
                        break
                    await set_job_store(job_id, {"step": f"Traitement du média {idx + 1}/{len(payload.media_items)}"})
                    ext = ".mp4" if item.media_type == "video" else ".jpg"
                    local_media = os.path.join(work_dir, f"media_{idx}{ext}")
                    await run_in_executor(download_remote_file,item.media_url,local_media,job_id)

                    caption_txt = (item.custom_caption or f"{tpl_spec.get('hook_prefix', '')} Extrait #{idx + 1}").strip()
                    audio_path = os.path.join(work_dir, f"tpl_voice_{idx}.mp3")
                    _, v_dur = await synthesize_voice_to_file(
                        text=caption_txt,
                        out_audio_path=audio_path,
                        personnage="narrateur",
                        speaking_rate=payload.voice_speaking_rate,
                        voice_profile_id=payload.voice_profile_id,
                        user_id=user_id,
                    )
                    seg_dur = min(max(float(tpl_spec.get("scene_duration", 3.5)), v_dur + 0.25), max(1.5, max_allowed_dur - elapsed))

                    ov_png = os.path.join(work_dir, f"tpl_ov_{idx}.png")
                    await run_in_executor(
                        render_overlay_png,
                        out_png=ov_png,
                        width=vid_w,
                        height=vid_h,
                        subtitle_text=caption_txt if payload.show_subtitles else None,
                        subtitle_position=payload.subtitle_position,
                        overlay_title=payload.overlay_title if idx == 0 else None,
                        text_style_id=payload.text_style_id,
                        sticker_ids=payload.sticker_ids,
                        sticker_position=payload.sticker_position,
                        include_genia_badge=True,
                    )

                    out_seg = os.path.join(work_dir, f"tpl_seg_{idx}.mp4")
                    if item.media_type == "video":
                        await run_in_executor(
                            normalize_video_clip,
                            input_video_path=local_media,
                            out_mp4_path=out_seg,
                            width=vid_w,
                            height=vid_h,
                            target_duration=seg_dur,
                            zoom_factor=1.14,
                            filter_spec=filter_spec,
                            overlay_png_path=ov_png,
                            bgm_url=payload.bgm_url,
                            bgm_volume=payload.bgm_volume,
                            work_dir=work_dir,
                            voice_audio_path=audio_path,
                        )
                    else:
                        await run_in_executor(
                            build_animated_still_clip,
                            image_path=local_media,
                            audio_path=audio_path,
                            out_mp4_path=out_seg,
                            width=vid_w,
                            height=vid_h,
                            duration_sec=seg_dur,
                            motion="zoom_in" if idx % 2 == 0 else "zoom_out",
                            filter_spec=filter_spec,
                            overlay_png_path=ov_png,
                            bgm_url=payload.bgm_url,
                            bgm_volume=payload.bgm_volume,
                            work_dir=work_dir,
                        )

                    clips.append(out_seg)
                    elapsed += seg_dur

                await run_in_executor(concat_clips_and_thumb,clips,final_mp4,thumb_jpg,work_dir,transition_style=payload.transition_style)
                video_url = await run_in_executor(ensure_bucket_and_upload,final_mp4,f"free_templates/{user_id}/{job_id}.mp4",job_id)
                thumb_url = await run_in_executor(ensure_bucket_and_upload,thumb_jpg,f"free_templates/{user_id}/{job_id}.jpg",job_id)

                final_state = await get_job_store(job_id)
                if final_state and final_state.get("cancel_requested"):
                    await set_job_store(job_id,{"status":"cancelled","step":"Annulé"})
                    return
                await set_job_store(job_id, {
                    "status": "completed",
                    "step": "Terminé",
                    "mode": "template_apply",
                    "template_source": "google_search_grounded_inspiration" if tpl_spec.get("source_urls") else "gemini_editorial_idea_not_verified_trend",
                    "template_source_urls": tpl_spec.get("source_urls", []),
                    "free_tier": True,
                    "watermark_text": "Créé avec Genia",
                    "video_url": video_url,
                    "thumbnail_url": thumb_url,
                    "duration_sec": round(_probe_media_duration(final_mp4, default_sec=elapsed), 2),
                })
            except Exception as exc:
                await set_job_store(job_id, {"status": "failed", "step": "Échec", "error": str(exc)[:300]})
            finally:
                shutil.rmtree(work_dir, ignore_errors=True)

    @staticmethod
    async def process_photo_model_job(job_id: str, user_id: str, payload: PhotoModelApplyRequest, max_allowed_dur: float):
        async with RENDER_SEMAPHORE:
            work_dir = f"/tmp/apex_pm_{job_id}"
            os.makedirs(work_dir, exist_ok=True)
            final_mp4 = os.path.join(work_dir, f"pm_{job_id}.mp4")
            thumb_jpg = os.path.join(work_dir, f"pm_{job_id}.jpg")

            try:
                claimed = await claim_job_for_processing(job_id, user_id, "photo_model_free")
                if not claimed:
                    return

                vid_w, vid_h = get_dimensions(payload.aspect_ratio)
                filter_spec = get_filter_spec(payload.filter_id)
                clips: List[str] = []
                elapsed = 0.0

                for idx, purl in enumerate(payload.user_photo_urls):
                    current = await get_job_store(job_id)
                    if current and current.get("cancel_requested"): raise RuntimeError("Tâche annulée par l'utilisateur.")
                    if elapsed >= max_allowed_dur:
                        break
                    await set_job_store(job_id, {"step": f"Mise en scène photo {idx + 1}/{len(payload.user_photo_urls)}"})
                    raw_photo = os.path.join(work_dir, f"photo_{idx}.jpg")
                    await run_in_executor(download_remote_file,purl,raw_photo,job_id)

                    cap_txt = payload.captions[idx].strip() if idx < len(payload.captions) and payload.captions[idx].strip() else ""
                    generated_photo = os.path.join(work_dir, f"photo_ai_{idx}.png")
                    await generate_photo_edit_with_gemini(
                        photo_path=raw_photo, output_path=generated_photo,
                        insertion_mode=payload.insertion_mode, photo_model_id=payload.photo_model_id,
                        caption=cap_txt if payload.show_subtitles else None,
                    )
                    framed_png = os.path.join(work_dir, f"framed_{idx}.png")
                    await run_in_executor(
                        prepare_styled_photo_frame,
                        photo_path=generated_photo,
                        out_png_path=framed_png,
                        width=vid_w,
                        height=vid_h,
                        photo_model_id=payload.photo_model_id,
                        caption=cap_txt if payload.show_subtitles else None,
                        insertion_mode=payload.insertion_mode,
                    )

                    audio_file = None
                    seg_dur = 3.5
                    if payload.voice_enabled and cap_txt:
                        audio_file = os.path.join(work_dir, f"pm_voice_{idx}.mp3")
                        _, v_dur = await synthesize_voice_to_file(
                            text=cap_txt,
                            out_audio_path=audio_file,
                            personnage=payload.personnage,
                            speaking_rate=payload.voice_speaking_rate,
                            voice_profile_id=payload.voice_profile_id,
                            user_id=user_id,
                        )
                        seg_dur = max(2.2, v_dur + 0.3)

                    seg_dur = min(seg_dur, max(1.5, max_allowed_dur - elapsed))
                    ov_png = os.path.join(work_dir, f"pm_ov_{idx}.png")
                    await run_in_executor(
                        render_overlay_png,
                        out_png=ov_png,
                        width=vid_w,
                        height=vid_h,
                        subtitle_text=None,
                        overlay_title=payload.overlay_title if idx == 0 else None,
                        text_style_id=payload.text_style_id,
                        sticker_ids=payload.sticker_ids,
                        sticker_position=payload.sticker_position,
                        include_genia_badge=True,
                    )

                    seg_mp4 = os.path.join(work_dir, f"pm_seg_{idx}.mp4")
                    await run_in_executor(
                        build_animated_still_clip,
                        image_path=framed_png,
                        audio_path=audio_file,
                        out_mp4_path=seg_mp4,
                        width=vid_w,
                        height=vid_h,
                        duration_sec=seg_dur,
                        motion="zoom_in" if idx % 2 == 0 else "pan_right",
                        filter_spec=filter_spec,
                        overlay_png_path=ov_png,
                        bgm_url=payload.bgm_url,
                        bgm_volume=payload.bgm_volume,
                        work_dir=work_dir,
                    )
                    clips.append(seg_mp4)
                    elapsed += seg_dur

                await run_in_executor(concat_clips_and_thumb,clips,final_mp4,thumb_jpg,work_dir,transition_style=payload.transition_style)
                video_url = await run_in_executor(ensure_bucket_and_upload,final_mp4,f"free_photo_models/{user_id}/{job_id}.mp4",job_id)
                thumb_url = await run_in_executor(ensure_bucket_and_upload,thumb_jpg,f"free_photo_models/{user_id}/{job_id}.jpg",job_id)

                final_state = await get_job_store(job_id)
                if final_state and final_state.get("cancel_requested"):
                    await set_job_store(job_id,{"status":"cancelled","step":"Annulé"})
                    return
                await set_job_store(job_id, {
                    "status": "completed",
                    "step": "Terminé",
                    "mode": "photo_model_apply",
                    "photo_model_processing": "gemini_image_edit_then_pillow_layout",
                    "free_tier": True,
                    "watermark_text": "Créé avec Genia",
                    "video_url": video_url,
                    "thumbnail_url": thumb_url,
                    "duration_sec": round(_probe_media_duration(final_mp4, default_sec=elapsed), 2),
                })
            except Exception as exc:
                await set_job_store(job_id, {"status": "failed", "step": "Échec", "error": str(exc)[:300]})
            finally:
                shutil.rmtree(work_dir, ignore_errors=True)


class ApexCameraStudioEngine:
    """Applique zooms caméra, filtres, sous-titres et mention « Créé avec Genia » via FFmpeg."""

    @staticmethod
    async def process_recorded_video(job_id: str, user_id: str, payload: RecordStudioRequest, max_allowed_dur: float):
        async with RENDER_SEMAPHORE:
            work_dir = f"/tmp/apex_cam_{job_id}"
            os.makedirs(work_dir, exist_ok=True)
            src_video = os.path.join(work_dir, "recorded_src.mp4")
            final_mp4 = os.path.join(work_dir, f"cam_{job_id}.mp4")
            thumb_jpg = os.path.join(work_dir, f"cam_{job_id}.jpg")

            try:
                claimed = await claim_job_for_processing(job_id, user_id, "camera_studio_free")
                if not claimed:
                    return

                current = await get_job_store(job_id)
                if current and current.get("cancel_requested"):
                    await set_job_store(job_id,{"status":"cancelled","step":"Annulé"}); return
                await set_job_store(job_id, {"step": "Récupération de la vidéo filmée"})
                await run_in_executor(download_remote_file,payload.recorded_video_url,src_video,job_id)

                preset = CAMERA_PRESETS_CATALOG.get(payload.camera_preset_id, CAMERA_PRESETS_CATALOG["cam_zoom_hook"])
                vid_w, vid_h = get_dimensions(payload.aspect_ratio)
                filter_spec = get_filter_spec(payload.filter_id)

                ov_png = os.path.join(work_dir, "cam_ov.png")
                await run_in_executor(
                    render_overlay_png,
                    out_png=ov_png,
                    width=vid_w,
                    height=vid_h,
                    subtitle_text=payload.transcript_text if payload.show_subtitles else None,
                    subtitle_position=payload.subtitle_position,
                    overlay_title=payload.overlay_title,
                    text_style_id=payload.text_style_id,
                    sticker_ids=payload.sticker_ids,
                    sticker_position=payload.sticker_position,
                    include_genia_badge=True,
                )

                await set_job_store(job_id, {"step": "Application des zooms et filtres"})
                await run_in_executor(
                    normalize_video_clip,
                    input_video_path=src_video,
                    out_mp4_path=final_mp4,
                    width=vid_w,
                    height=vid_h,
                    target_duration=max_allowed_dur,
                    playback_speed=payload.playback_speed,
                    zoom_factor=float(preset.get("zoom_factor", 1.2)),
                    filter_spec=filter_spec,
                    overlay_png_path=ov_png,
                    bgm_url=payload.bgm_url,
                    bgm_volume=payload.bgm_volume,
                    work_dir=work_dir,
                )

                await run_in_executor(_run_cmd,["ffmpeg", "-y", "-i", final_mp4, "-ss", "00:00:00.400", "-vframes", "1", "-q:v", "3", thumb_jpg],label="cam_thumb")
                video_url = await run_in_executor(ensure_bucket_and_upload,final_mp4,f"free_camera/{user_id}/{job_id}.mp4",job_id)
                thumb_url = await run_in_executor(ensure_bucket_and_upload,thumb_jpg,f"free_camera/{user_id}/{job_id}.jpg",job_id)

                final_state = await get_job_store(job_id)
                if final_state and final_state.get("cancel_requested"):
                    await set_job_store(job_id,{"status":"cancelled","step":"Annulé"})
                    return
                await set_job_store(job_id, {
                    "status": "completed",
                    "step": "Terminé",
                    "mode": "camera_record_studio",
                    "camera_processing": "FFmpeg_zoom_crop_and_color_filters; no_beat_sync_or_motion_tracking",
                    "free_tier": True,
                    "watermark_text": "Créé avec Genia",
                    "video_url": video_url,
                    "thumbnail_url": thumb_url,
                    "duration_sec": round(_probe_media_duration(final_mp4, default_sec=10.0), 2),
                })
            except Exception as exc:
                await set_job_store(job_id, {"status": "failed", "step": "Échec", "error": str(exc)[:300]})
            finally:
                shutil.rmtree(work_dir, ignore_errors=True)


class ApexSongPhotoEngine:
    @staticmethod
    async def process_song_photo(job_id: str, user_id: str, payload: SongPhotoRenderRequest, max_allowed_dur: float):
        async with RENDER_SEMAPHORE:
            work_dir = f"/tmp/apex_song_{job_id}"
            os.makedirs(work_dir, exist_ok=True)
            photo_local = os.path.join(work_dir, "photo.jpg")
            song_local = os.path.join(work_dir, "song.mp3")
            final_mp4 = os.path.join(work_dir, f"song_{job_id}.mp4")
            thumb_jpg = os.path.join(work_dir, f"song_{job_id}.jpg")

            try:
                claimed = await claim_job_for_processing(job_id, user_id, "song_photo_free")
                if not claimed:
                    return

                current = await get_job_store(job_id)
                if current and current.get("cancel_requested"):
                    await set_job_store(job_id,{"status":"cancelled","step":"Annulé"}); return
                await set_job_store(job_id, {"step": "Téléchargement de la photo et de la chanson"})
                await run_in_executor(download_remote_file,payload.photo_url,photo_local,job_id)
                await run_in_executor(download_remote_file,payload.song_url,song_local,job_id)

                lyrics = payload.lyrics_text or ""
                if payload.auto_extract_lyrics and not lyrics.strip():
                    await set_job_store(job_id, {"step": "Extraction automatique des paroles"})
                    lyrics = await transcribe_song_lyrics(song_local, fallback_text=payload.lyrics_text)

                song_dur = min(max_allowed_dur, max(3.0, _probe_media_duration(song_local, default_sec=15.0)))
                vid_w, vid_h = get_dimensions(payload.aspect_ratio)
                filter_spec = get_filter_spec(payload.filter_id)

                await set_job_store(job_id, {"step": "Animation de la photo et synchronisation des paroles"})
                timed_segments = _build_timed_lyrics_segments(lyrics, song_dur, audio_path=song_local) if (payload.show_lyrics and lyrics.strip()) else []

                if len(timed_segments) > 1:
                    raw_video_no_ov = os.path.join(work_dir, f"song_base_{job_id}.mp4")
                    await run_in_executor(
                        build_animated_still_clip,
                        image_path=photo_local,
                        audio_path=song_local,
                        out_mp4_path=raw_video_no_ov,
                        width=vid_w,
                        height=vid_h,
                        duration_sec=song_dur,
                        motion=payload.motion,
                        filter_spec=filter_spec,
                        overlay_png_path=None,
                        bgm_url=payload.bgm_url,
                        bgm_volume=payload.bgm_volume,
                        work_dir=work_dir,
                    )

                    ov_inputs: List[str] = ["-i", raw_video_no_ov]
                    ov_chains: List[str] = []
                    prev_lbl = "[0:v]"
                    for seg_idx, (st_t, en_t, line_txt) in enumerate(timed_segments):
                        seg_ov_png = os.path.join(work_dir, f"song_ov_{seg_idx}.png")
                        await run_in_executor(
                            render_overlay_png,
                            out_png=seg_ov_png,
                            width=vid_w,
                            height=vid_h,
                            subtitle_text=line_txt,
                            subtitle_position=payload.lyrics_position,
                            overlay_title=payload.overlay_title,
                            text_style_id=payload.text_style_id,
                            sticker_ids=payload.sticker_ids,
                            sticker_position=payload.sticker_position,
                            include_genia_badge=True,
                        )
                        in_idx = seg_idx + 1
                        ov_inputs.extend(["-loop", "1", "-i", seg_ov_png])
                        out_lbl = "[vout]" if seg_idx == len(timed_segments) - 1 else f"[vs{seg_idx}]"
                        ov_chains.append(
                            f"{prev_lbl}[{in_idx}:v]overlay=0:0:enable='between(t,{st_t:.2f},{en_t:.2f})':eof_action=repeat:shortest=0{out_lbl}"
                        )
                        prev_lbl = out_lbl

                    await run_in_executor(
                        _run_cmd,
                        [
                            "ffmpeg",
                            "-y",
                            *ov_inputs,
                            "-filter_complex",
                            ";".join(ov_chains),
                            "-map",
                            "[vout]",
                            "-map",
                            "0:a",
                            "-t",
                            f"{song_dur:.2f}",
                            "-c:v",
                            "libx264",
                            "-preset",
                            "veryfast",
                            "-crf",
                            "23",
                            "-c:a",
                            "copy",
                            final_mp4,
                        ],
                        label="song_timed_lyrics_overlay",
                    )
                else:
                    ov_png = os.path.join(work_dir, "song_ov.png")
                    await run_in_executor(
                        render_overlay_png,
                        out_png=ov_png,
                        width=vid_w,
                        height=vid_h,
                        subtitle_text=lyrics if payload.show_lyrics else None,
                        subtitle_position=payload.lyrics_position,
                        overlay_title=payload.overlay_title,
                        text_style_id=payload.text_style_id,
                        sticker_ids=payload.sticker_ids,
                        sticker_position=payload.sticker_position,
                        include_genia_badge=True,
                    )
                    await run_in_executor(
                        build_animated_still_clip,
                        image_path=photo_local,
                        audio_path=song_local,
                        out_mp4_path=final_mp4,
                        width=vid_w,
                        height=vid_h,
                        duration_sec=song_dur,
                        motion=payload.motion,
                        filter_spec=filter_spec,
                        overlay_png_path=ov_png,
                        bgm_url=payload.bgm_url,
                        bgm_volume=payload.bgm_volume,
                        work_dir=work_dir,
                    )

                await run_in_executor(_run_cmd,["ffmpeg", "-y", "-i", final_mp4, "-ss", "00:00:00.400", "-vframes", "1", "-q:v", "3", thumb_jpg],label="song_thumb")
                video_url = await run_in_executor(ensure_bucket_and_upload,final_mp4,f"free_song_photo/{user_id}/{job_id}.mp4",job_id)
                thumb_url = await run_in_executor(ensure_bucket_and_upload,thumb_jpg,f"free_song_photo/{user_id}/{job_id}.jpg",job_id)

                final_state = await get_job_store(job_id)
                if final_state and final_state.get("cancel_requested"):
                    await set_job_store(job_id,{"status":"cancelled","step":"Annulé"})
                    return
                await set_job_store(job_id, {
                    "status": "completed",
                    "step": "Terminé",
                    "mode": "song_photo",
                    "free_tier": True,
                    "watermark_text": "Créé avec Genia",
                    "lyrics_extracted": lyrics,
                    "lyrics_timing_mode": "Google_Speech_word_timestamps" if _LYRICS_WORD_TIMESTAMPS.get(song_local) else "manual_or_unsynchronized_text",
                    "video_url": video_url,
                    "thumbnail_url": thumb_url,
                    "duration_sec": round(_probe_media_duration(final_mp4, default_sec=song_dur), 2),
                })
            except Exception as exc:
                await set_job_store(job_id, {"status": "failed", "step": "Échec", "error": str(exc)[:300]})
            finally:
                shutil.rmtree(work_dir, ignore_errors=True)


def _detect_scene_change_times(video_path: str) -> List[float]:
    """Détecte les changements visuels FFmpeg; ce n'est pas une prédiction de viralité."""
    try:
        proc=subprocess.run(["ffmpeg","-hide_banner","-i",video_path,"-vf","select='gt(scene,0.28)',showinfo","-an","-f","null","-"],
                            stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=180)
        return sorted({float(x) for x in re.findall(r"pts_time:([0-9]+(?:\.[0-9]+)?)",proc.stderr or "")})
    except Exception as exc:
        ApexCloudTelemetry.emit("WARNING","scene_detection_unavailable",error=str(exc)[:160])
        return []


def _choose_split_starts(total_duration: float, clip_duration: float, count: int, scene_times: List[float]) -> List[float]:
    if total_duration < count * 1.5:
        raise ValueError("La vidéo source est trop courte pour produire autant d'extraits distincts.")
    max_start=max(0.0,total_duration-clip_duration)
    if count==1: return [0.0]
    chosen=[]
    for i in range(count):
        target=max_start*(i/(count-1))
        low=max(0.0,target-clip_duration*0.45); high=min(max_start,target+clip_duration*0.45)
        candidates=[t for t in scene_times if low<=t<=high and all(abs(t-x)>=1.0 for x in chosen)]
        start=min(candidates,key=lambda t:abs(t-target)) if candidates else target
        if any(abs(start-x)<1.0 for x in chosen): start=target
        chosen.append(round(max(0.0,min(max_start,start)),3))
    return sorted(chosen)


async def execute_split_video_job(job_id: str, payload: SplitVideoRequest, user_id: str, charged_credits: int):
    async with RENDER_SEMAPHORE:
        work_dir = f"/tmp/apex_split_{job_id}"
        os.makedirs(work_dir, exist_ok=True)
        src_mp4 = os.path.join(work_dir, "source_long.mp4")

        try:
            claimed = await claim_job_for_processing(job_id, user_id, "split_video_pipeline")
            if not claimed:
                return

            await set_job_store(job_id, {"step": "Téléchargement de la vidéo longue"})
            await run_in_executor(download_remote_file,payload.source_video_url,src_mp4,job_id)
            total_src_dur = _probe_media_duration(src_mp4, default_sec=float(payload.num_clips * payload.clip_duration))
            hooks = await ApexManagedGoogleModels.generate_clip_hooks(payload.topic_context, payload.num_clips)
            scene_times = await run_in_executor(_detect_scene_change_times, src_mp4)
            ai_highlights = await ApexManagedGoogleModels.analyze_video_highlights(
                src_mp4, payload.topic_context, payload.num_clips, payload.clip_duration
            )
            selected_highlights = list(ai_highlights[:payload.num_clips])
            if len(selected_highlights) < payload.num_clips:
                max_fallback_start = max(0.0, total_src_dur - payload.clip_duration)
                grid_step = max(1.0, payload.clip_duration * 0.65)
                grid_starts = [min(max_fallback_start, i * grid_step) for i in range(int(max_fallback_start / grid_step) + 1)]
                candidate_starts = sorted(set(
                    [float(x) for x in scene_times if 0 <= float(x) <= max_fallback_start]
                    + [float(x) for x in _choose_split_starts(total_src_dur, payload.clip_duration, payload.num_clips, scene_times)]
                    + grid_starts
                ))
                for fallback_start in candidate_starts:
                    if len(selected_highlights) >= payload.num_clips:
                        break
                    fallback_end = min(total_src_dur, float(fallback_start) + payload.clip_duration)
                    if fallback_end - float(fallback_start) < min(1.0, payload.clip_duration * 0.5):
                        continue
                    overlaps = [
                        min(fallback_end, float(item["end_sec"])) - max(float(fallback_start), float(item["start_sec"]))
                        for item in selected_highlights
                    ]
                    if any(overlap > 0.25 for overlap in overlaps):
                        continue
                    selected_highlights.append({
                        "start_sec": round(float(fallback_start), 3),
                        "end_sec": round(float(fallback_end), 3),
                        "quality_score": None,
                        "reason": "Position de secours basée sur les changements de scène et la distribution temporelle; non évaluée comme moment fort par Gemini.",
                        "hook": "",
                        "selection_source": "scene_change_even_distribution_fallback",
                    })
            selected_highlights.sort(key=lambda item: float(item["start_sec"]))
            if len(selected_highlights) < payload.num_clips:
                raise ValueError(
                    "La vidéo source ne contient pas assez de segments distincts sans chevauchement pour le nombre de clips demandé. "
                    "Réduisez le nombre de clips ou leur durée."
                )
            split_starts = [float(x["start_sec"]) for x in selected_highlights]
            if any(x.get("selection_source") == "scene_change_even_distribution_fallback" for x in selected_highlights):
                analysis_processing = next((x.get("analysis_processing") for x in selected_highlights if x.get("analysis_processing")), "static")
                selection_method = f"gemini_3_8_{analysis_processing}_plus_scene_change_fallback" if ai_highlights else "scene_change_even_distribution_fallback"
            else:
                analysis_processing = next((x.get("analysis_processing") for x in selected_highlights if x.get("analysis_processing")), "static")
                selection_method = f"gemini_3_8_{analysis_processing}_video_content_highlights"

            clips_result: List[dict] = []
            vid_w, vid_h = get_dimensions("9:16")

            for i in range(payload.num_clips):
                current = await get_job_store(job_id)
                if current and current.get("cancel_requested"): raise RuntimeError("Tâche annulée par l'utilisateur.")
                await set_job_store(job_id, {"step": f"Extraction du clip {i + 1}/{payload.num_clips}"})
                start_sec = split_starts[i]
                if selected_highlights:
                    seg_dur = min(payload.clip_duration, max(1.0, selected_highlights[i]["end_sec"] - start_sec))
                else:
                    seg_dur = min(payload.clip_duration, max(1.0, total_src_dur - start_sec))
                raw_slice = os.path.join(work_dir, f"slice_{i}.mp4")

                await run_in_executor(
                    _run_cmd,
                    [
                        "ffmpeg",
                        "-y",
                        "-ss",
                        f"{start_sec:.2f}",
                        "-i",
                        src_mp4,
                        "-t",
                        f"{seg_dur:.2f}",
                        "-vf",
                        f"scale={vid_w}:{vid_h}:force_original_aspect_ratio=decrease,pad={vid_w}:{vid_h}:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1,fps=24,format=yuv420p",
                        "-c:v",
                        "libx264",
                        "-preset",
                        "veryfast",
                        "-crf",
                        "23",
                        "-c:a",
                        "aac",
                        "-b:a",
                        "128k",
                        raw_slice,
                    ],
                    label="split_slice",
                )

                hook_txt = (selected_highlights[i].get("hook") or hooks[i]) if selected_highlights and i < len(hooks) else (hooks[i] if i < len(hooks) else f"{payload.topic_context} #{i + 1}")
                ov_png = os.path.join(work_dir, f"hook_ov_{i}.png")
                await run_in_executor(
                    render_overlay_png,
                    out_png=ov_png,
                    width=vid_w,
                    height=vid_h,
                    subtitle_text=hook_txt,
                    subtitle_position="top",
                    include_genia_badge=False,
                )

                final_clip_path = os.path.join(work_dir, f"clip_final_{i}.mp4")
                if payload.add_hook_voice:
                    hook_audio = os.path.join(work_dir, f"hook_voice_{i}.mp3")
                    await synthesize_voice_to_file(hook_txt, hook_audio, personnage=payload.personnage,
                                                   voice_profile_id=payload.voice_profile_id, user_id=user_id)
                    if _media_has_audio(raw_slice):
                        fc = "[0:v][2:v]overlay=0:0:eof_action=repeat:shortest=0[vout];[0:a]aresample=48000[src];[1:a]aresample=48000[hook];[src][hook]amix=inputs=2:duration=first[aout]"
                    else:
                        fc = "[0:v][2:v]overlay=0:0:eof_action=repeat:shortest=0[vout];[1:a]aresample=48000[aout]"
                    await run_in_executor(_run_cmd,["ffmpeg","-y","-i",raw_slice,"-i",hook_audio,"-loop","1","-i",ov_png,
                              "-filter_complex",fc,"-map","[vout]","-map","[aout]","-c:v","libx264",
                              "-preset","veryfast","-crf","23","-c:a","aac","-b:a","128k",final_clip_path],
                             label="split_hook_mix")
                else:
                    await run_in_executor(
                        _run_cmd,
                        [
                            "ffmpeg",
                            "-y",
                            "-i",
                            raw_slice,
                            "-loop",
                            "1",
                            "-i",
                            ov_png,
                            "-filter_complex",
                            "[0:v][1:v]overlay=0:0:eof_action=repeat:shortest=0[vout]",
                            "-map",
                            "[vout]",
                            "-map",
                            "0:a?",
                            "-c:v",
                            "libx264",
                            "-preset",
                            "veryfast",
                            "-crf",
                            "23",
                            "-c:a",
                            "copy",
                            final_clip_path,
                        ],
                        label="split_hook_overlay",
                    )

                clip_url = await run_in_executor(ensure_bucket_and_upload,final_clip_path,f"splits/{user_id}/{job_id}/clip_{i}.mp4",job_id)
                highlight_meta = selected_highlights[i] if i < len(selected_highlights) else {}
                clips_result.append({
                    "part_index": i,
                    "hook_title": hook_txt,
                    "duration": round(_probe_media_duration(final_clip_path, default_sec=seg_dur), 2),
                    "video_url": clip_url,
                    "selection_source": highlight_meta.get("selection_source", "gemini_3_8_agentic_video_content_highlights"),
                    "highlight_quality_score": highlight_meta.get("quality_score"),
                    "selection_reason": highlight_meta.get("reason"),
                })

            first_url = clips_result[0]["video_url"] if clips_result else None
            final_state = await get_job_store(job_id)
            if final_state and final_state.get("cancel_requested"):
                if charged_credits > 0: await refund_credits(user_id,charged_credits,f"Annulation découpage {job_id}")
                await set_job_store(job_id,{"status":"cancelled","step":"Annulé"})
                return
            await set_job_store(job_id, {
                "status": "completed",
                "step": "Terminé",
                "mode": "split_video",
                "free_tier": False,
                "clips": clips_result,
                "selection_method": selection_method,
                "ai_highlights_found": len(ai_highlights),
                "selected_highlights": selected_highlights,
                "highlight_model": GEMINI_VIDEO_ANALYSIS_MODEL if ai_highlights else None,
                "detected_scene_changes": len(scene_times),
                "video_url": first_url,
            })
        except Exception as exc:
            if charged_credits > 0:
                await refund_credits(user_id, charged_credits, f"Échec découpage {job_id}")
            await set_job_store(job_id, {"status": "failed", "step": "Échec", "error": str(exc)[:300]})
        finally:
            shutil.rmtree(work_dir, ignore_errors=True)


# =========================================================================
# PERSISTANCE DES MODÈLES GÉNÉRÉS (FIRESTORE)
# =========================================================================
async def persist_templates(items: List[dict]) -> None:
    if not firestore_client:
        if REQUIRE_CLOUD_STATE: raise HTTPException(status_code=503, detail="Firestore indisponible.")
        _LOCAL_TEMPLATES_STORE[:0] = items
        return
    def _write():
        batch = firestore_client.batch()
        col = firestore_client.collection(FIRESTORE_COLLECTION_TEMPLATES)
        for item in items:
            batch.set(col.document(item["template_id"]), {**item,"updated_at":_utc_now_iso()}, merge=True)
        batch.commit()
    await run_in_executor(_write)


async def list_persisted_templates(limit: int = 30) -> List[dict]:
    if not firestore_client:
        if REQUIRE_CLOUD_STATE: raise HTTPException(status_code=503, detail="Firestore indisponible.")
        return [*_LOCAL_TEMPLATES_STORE, *DEFAULT_TEMPLATES]
    def _read():
        docs = firestore_client.collection(FIRESTORE_COLLECTION_TEMPLATES).order_by("updated_at", direction=firestore.Query.DESCENDING).limit(limit).stream()
        return [d.to_dict() for d in docs]
    saved = await run_in_executor(_read)
    by_id = {x.get("template_id"):x for x in saved}
    for item in DEFAULT_TEMPLATES: by_id.setdefault(item["template_id"],item)
    return list(by_id.values())[:limit]


async def get_template_by_id(template_id: str) -> Optional[dict]:
    for item in DEFAULT_TEMPLATES:
        if item["template_id"] == template_id: return item
    if firestore_client:
        snap = await run_in_executor(firestore_client.collection(FIRESTORE_COLLECTION_TEMPLATES).document(template_id).get)
        return snap.to_dict() if snap.exists else None
    return next((x for x in _LOCAL_TEMPLATES_STORE if x.get("template_id")==template_id),None)


# =========================================================================
# FILE DE TÂCHES GOOGLE CLOUD (Cloud Tasks -> Cloud Run)
# =========================================================================
async def _fail_queued_job(job_id: str, reason: str) -> None:
    job=await get_job_store(job_id) or {}
    await set_job_store(job_id,{"status":"failed","queue_error":reason[:250],"step":"Échec de mise en file"})
    charged=int(job.get("credits_charged",0)); owner=job.get("owner")
    if charged and owner: await refund_credits(owner,charged,f"Échec Cloud Tasks {job_id}")
    if job.get("free_tier") and owner: await release_free_quota(owner)


async def enqueue_render_task(job_id: str) -> None:
    if not cloud_tasks_client or not CLOUD_TASKS_SERVICE_URL or not CLOUD_TASKS_SERVICE_ACCOUNT:
        reason="Cloud Tasks non configuré : file, URL Cloud Run ou compte de service manquant."
        await _fail_queued_job(job_id,reason)
        raise HTTPException(status_code=503, detail=reason)
    parent=cloud_tasks_client.queue_path(GCP_PROJECT_ID,CLOUD_TASKS_LOCATION,CLOUD_TASKS_QUEUE)
    url=f"{CLOUD_TASKS_SERVICE_URL}/api/v1/internal/tasks/{job_id}"
    task={"dispatch_deadline":{"seconds":1800},"http_request":{"http_method":tasks_v2.HttpMethod.POST,"url":url,
           "headers":{"Content-Type":"application/json"},"body":json.dumps({"job_id":job_id}).encode(),
           "oidc_token":{"service_account_email":CLOUD_TASKS_SERVICE_ACCOUNT,"audience":CLOUD_TASKS_SERVICE_URL}}}
    task["name"]=cloud_tasks_client.task_path(GCP_PROJECT_ID,CLOUD_TASKS_LOCATION,CLOUD_TASKS_QUEUE,job_id)
    try:
        await run_in_executor(cloud_tasks_client.create_task,parent=parent,task=task)
    except Exception as exc:
        # Un doublon est idempotent; les autres erreurs sont remontées et le job reste visible comme queued.
        if "ALREADY" not in str(exc).upper():
            await _fail_queued_job(job_id,str(exc))
            raise HTTPException(status_code=503,detail="Impossible d'ajouter le rendu à Google Cloud Tasks.") from exc


async def release_free_quota(user_id: str) -> None:
    if not firestore_client: return
    day=_utc_now().strftime("%Y-%m-%d")
    ref=firestore_client.collection("genia_free_usage").document(f"{user_id}_{day}")
    def _release():
        tx=firestore_client.transaction()
        @firestore.transactional
        def _apply(transaction):
            snap=ref.get(transaction=transaction)
            if snap.exists:
                count=max(0,int((snap.to_dict() or {}).get("count",0))-1)
                transaction.set(ref,{"count":count,"updated_at":_utc_now_iso()},merge=True)
        _apply(tx)
    await run_in_executor(_release)


@app.post("/api/v1/internal/tasks/{job_id}")
async def process_internal_cloud_task(job_id: str, request: Request):
    """Point d'entrée réservé à Cloud Tasks via jeton OIDC du compte de service."""
    if not CLOUD_TASKS_SERVICE_ACCOUNT or not CLOUD_TASKS_SERVICE_URL:
        raise HTTPException(status_code=503,detail="Cloud Tasks worker non configuré.")
    auth=request.headers.get("authorization","")
    if not auth.startswith("Bearer "):
        raise HTTPException(status_code=401,detail="Jeton Cloud Tasks manquant.")
    try:
        claims=id_token.verify_oauth2_token(auth.split(" ",1)[1],GoogleAuthRequest(),audience=CLOUD_TASKS_SERVICE_URL)
        if claims.get("email") != CLOUD_TASKS_SERVICE_ACCOUNT or not claims.get("email_verified"):
            raise ValueError("Compte de service inattendu")
    except Exception as exc:
        raise HTTPException(status_code=401,detail="Identité Cloud Tasks invalide.") from exc
    # Cloud Run can scale to zero. The API may be ready before the background model
    # bootstrap has restored all weights from GCS; return 503 so Cloud Tasks retries
    # instead of marking a paid render as failed during warm-up.
    try:
        worker_req=urllib.request.Request(
            GENIA_LOCAL_AI_URL+"/health/deep", headers=_local_ai_headers(), method="GET")
        with urllib.request.urlopen(worker_req, timeout=12) as worker_resp:
            worker_state=json.loads(worker_resp.read().decode("utf-8"))
        if worker_state.get("status") != "ok" or not worker_state.get("gcs_access_verified"):
            detail="Les moteurs Genia Apex ne sont pas encore prêts; Cloud Tasks réessaiera automatiquement."
            if worker_state.get("bootstrap_failed"):
                detail="Le téléchargement ou la restauration des modèles a échoué. Consulte les journaux Cloud Run."
            raise HTTPException(status_code=503, detail=detail)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=503,detail="Le worker GPU démarre encore; Cloud Tasks réessaiera.") from exc
    job=await get_job_store(job_id)
    if not job: raise HTTPException(status_code=404,detail="Tâche inconnue.")
    if job.get("status") in ("completed", "failed", "cancelled"):
        return {"status":job.get("status"),"job_id":job_id}
    if job.get("status")=="processing" and job.get("worker_claimed_at"):
        try:
            claimed=datetime.fromisoformat(job["worker_claimed_at"])
            if claimed.tzinfo is None: claimed=claimed.replace(tzinfo=timezone.utc)
            if (_utc_now()-claimed).total_seconds()<1200:
                raise HTTPException(status_code=503,detail="Un worker traite déjà cette tâche; Cloud Tasks doit réessayer.")
        except HTTPException: raise
        except Exception: raise HTTPException(status_code=503,detail="Verrou de tâche à vérifier; réessayez.")
    user_id=job.get("owner")
    payload_data=job.get("task_payload") or {}
    mode=job.get("mode")
    if not user_id: raise HTTPException(status_code=400,detail="Propriétaire de tâche manquant.")
    if mode=="avatar": await execute_master_pipeline(job_id,payload_data,user_id)
    elif mode=="template_apply": await ApexTemplateAndPhotoEngine.process_template_job(job_id,user_id,TemplateApplyRequest(**payload_data),float(payload_data.get("_max_allowed_dur",FREE_TIER_MAX_DURATION_SEC)))
    elif mode=="photo_model_apply": await ApexTemplateAndPhotoEngine.process_photo_model_job(job_id,user_id,PhotoModelApplyRequest(**payload_data),float(payload_data.get("_max_allowed_dur",FREE_TIER_MAX_DURATION_SEC)))
    elif mode=="camera_record_studio": await ApexCameraStudioEngine.process_recorded_video(job_id,user_id,RecordStudioRequest(**payload_data),float(payload_data.get("_max_allowed_dur",FREE_TIER_MAX_DURATION_SEC)))
    elif mode=="song_photo": await ApexSongPhotoEngine.process_song_photo(job_id,user_id,SongPhotoRenderRequest(**payload_data),float(payload_data.get("_max_allowed_dur",FREE_TIER_MAX_DURATION_SEC)))
    elif mode=="split_video": await execute_split_video_job(job_id,SplitVideoRequest(**payload_data),user_id,int(job.get("credits_charged",0)))
    else: raise HTTPException(status_code=400,detail="Type de tâche inconnu.")
    final=await get_job_store(job_id)
    if final and final.get("status") in ("failed", "cancelled") and final.get("free_tier") and not final.get("free_quota_released"):
        await release_free_quota(user_id)
        await set_job_store(job_id,{"free_quota_released":True})
    # Les pipelines consignent eux-mêmes les échecs et remboursent les crédits payants;
    # on répond 200 pour éviter une relance facturable sans fin.
    return {"status":(final or {}).get("status","processing"),"job_id":job_id}


# =========================================================================
# ROUTES HTTP
# =========================================================================
def _check_binary_available(bin_name: str) -> bool:
    return shutil.which(bin_name) is not None


@app.get("/api/v1/system/readiness")
async def system_readiness():
    checks={"ffmpeg":_check_binary_available("ffmpeg"),"ffprobe":_check_binary_available("ffprobe"),
            "local_ai_worker_configured":bool(GENIA_LOCAL_AI_URL),
            "vertex_ai_client_initialized":bool(genai_client),"firestore_client_initialized":bool(firestore_client),
            "storage_client_initialized":bool(storage_client),"tts_client_initialized":bool(tts_client),
            "speech_client_initialized":bool(stt_client),"cloud_tasks_client_initialized":bool(cloud_tasks_client),
            "gemini_voice_replication_initialized":bool(voice_genai_client),
            "google_search_grounding_client_initialized":bool(search_genai_client),
            "gemini_omni_native_avatar_enabled":bool(ENABLE_GEMINI_OMNI_NATIVE_AVATAR),
            "gemini_live_avatar_enabled":bool(ENABLE_GEMINI_LIVE_AVATAR),
            "gemini_live_avatar_model":GEMINI_LIVE_AVATAR_MODEL,
            "gemini_omni_video_model":GEMINI_OMNI_VIDEO_MODEL,
            "gemini_video_analysis_model":GEMINI_VIDEO_ANALYSIS_MODEL,
            "gemini_virality_model":GEMINI_VIRALITY_MODEL,
            "jwt_secret_configured":bool(GENIA_AUTH_SECRET),
            "self_healing_engine_enabled":True,
            "self_healing_engine":ApexSelfHealingEngine.status()}
    try:
        worker_req=urllib.request.Request(GENIA_LOCAL_AI_URL+"/health/deep",headers=_local_ai_headers(),method="GET")
        with urllib.request.urlopen(worker_req,timeout=8) as worker_resp:
            worker_health=json.loads(worker_resp.read().decode("utf-8"))
        checks["local_ai_worker_reachable"]=worker_resp.status==200
        checks["wan_worker_ready"]=bool(worker_health.get("wan_repo_present") and worker_health.get("wan_weights_present"))
        checks["openvoice_worker_ready"]=bool(worker_health.get("openvoice_present"))
        checks["latentsync_worker_ready"]=bool(worker_health.get("latentsync_present"))
        checks["qwen_worker_ready"]=bool(worker_health.get("qwen_present"))
        checks["kokoro_worker_ready"]=bool(worker_health.get("kokoro_present"))
        checks["whisper_worker_ready"]=bool(worker_health.get("whisper_present"))
        checks["sdxl_worker_ready"]=bool(worker_health.get("sdxl_present"))
        checks["worker_gcs_configured"]=bool(worker_health.get("gcs_access_verified"))
    except Exception as worker_error:
        checks["local_ai_worker_reachable"]=False
        checks["worker_health_error"]=str(worker_error)[:220]
        checks["wan_worker_ready"]=False; checks["openvoice_worker_ready"]=False
        checks["latentsync_worker_ready"]=False
        checks["qwen_worker_ready"]=False; checks["kokoro_worker_ready"]=False
        checks["whisper_worker_ready"]=False; checks["sdxl_worker_ready"]=False
        checks["worker_gcs_configured"]=False
    if firestore_client:
        try:
            await run_in_executor(firestore_client.collection("genia_health").document("ping").get)
            checks["firestore_connectivity"]=True
        except Exception: checks["firestore_connectivity"]=False
    else: checks["firestore_connectivity"]=False
    if storage_client:
        try:
            checks["gcs_bucket_exists"]=await run_in_executor(storage_client.bucket(GCS_BUCKET_NAME).exists)
        except Exception: checks["gcs_bucket_exists"]=False
    else: checks["gcs_bucket_exists"]=False
    if cloud_tasks_client and CLOUD_TASKS_SERVICE_ACCOUNT and CLOUD_TASKS_SERVICE_URL:
        try:
            parent=cloud_tasks_client.queue_path(GCP_PROJECT_ID,CLOUD_TASKS_LOCATION,CLOUD_TASKS_QUEUE)
            await run_in_executor(cloud_tasks_client.get_queue,name=parent)
            checks["cloud_tasks_queue_exists"]=True
        except Exception: checks["cloud_tasks_queue_exists"]=False
    else: checks["cloud_tasks_queue_exists"]=False
    required=["ffmpeg","ffprobe","firestore_connectivity","gcs_bucket_exists",
              "cloud_tasks_queue_exists","jwt_secret_configured","local_ai_worker_reachable",
              "wan_worker_ready","openvoice_worker_ready","latentsync_worker_ready",
              "qwen_worker_ready","kokoro_worker_ready","whisper_worker_ready","sdxl_worker_ready",
              "worker_gcs_configured"]
    return {"status":"configured" if all(checks.get(k,False) for k in required) else "degraded", "checks":checks,
            "project_id":GCP_PROJECT_ID,"location":GCP_LOCATION}


@app.get("/api/v1/media/gcs/{blob_name:path}")
async def serve_gcs_media(blob_name: str, exp: int, sig: str):
    if not storage_client or not GENIA_AUTH_SECRET: raise HTTPException(status_code=503,detail="Service média indisponible.")
    clean=urllib.parse.unquote(blob_name).lstrip("/")
    if ".." in clean.split("/") or int(exp) < int(time.time()) or int(exp) > int(time.time())+7*24*3600+60:
        raise HTTPException(status_code=403,detail="Lien média invalide ou expiré.")
    expected=hmac.new(GENIA_AUTH_SECRET.encode(),f"{clean}:{int(exp)}".encode(),hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected,sig): raise HTTPException(status_code=403,detail="Signature média invalide.")
    blob=storage_client.bucket(GCS_BUCKET_NAME).blob(clean)
    if not await run_in_executor(blob.exists): raise HTTPException(status_code=404,detail="Média introuvable.")
    try:
        url=await run_in_executor(blob.generate_signed_url,version="v4",expiration=timedelta(minutes=15),method="GET")
    except Exception as exc:
        raise HTTPException(status_code=503,detail="Impossible de signer le média GCS; vérifiez IAM signBlob.") from exc
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url=url,status_code=307,headers={"Cache-Control":"private, no-store"})


@app.get("/api/v1/render/media-url/{job_id}")
async def refresh_render_media_url(job_id: str, user_id: str = Depends(extract_user_id)):
    job=await get_job_store(job_id)
    if not job or job.get("owner") != user_id: raise HTTPException(status_code=404,detail="Rendu introuvable.")
    current=job.get("video_url") or ""
    parsed=urllib.parse.urlparse(current)
    marker="/api/v1/media/gcs/"
    if marker not in parsed.path: raise HTTPException(status_code=404,detail="URL GCS du rendu indisponible.")
    blob_name=urllib.parse.unquote(parsed.path.split(marker,1)[1])
    if not GENIA_AUTH_SECRET: raise HTTPException(status_code=503,detail="Secret média absent.")
    exp=int(time.time())+7*24*3600
    sig=hmac.new(GENIA_AUTH_SECRET.encode(),f"{blob_name}:{exp}".encode(),hashlib.sha256).hexdigest()
    url=f"{PUBLIC_BASE_URL}/api/v1/media/gcs/{urllib.parse.quote(blob_name,safe='/')}?exp={exp}&sig={sig}"
    await set_job_store(job_id,{"video_url":url})
    return {"video_url":url,"expires_at":exp}


@app.get("/api/v1/media/{file_path:path}")
async def serve_local_media(file_path: str, user_id: str = Depends(extract_user_id)):
    normalized = os.path.normpath(file_path).lstrip("/")
    if not normalized or normalized.startswith("..") or user_id not in normalized.replace("\\", "/").split("/"):
        raise HTTPException(status_code=403, detail="Accès média refusé.")
    full_path = os.path.realpath(os.path.join(LOCAL_MEDIA_ROOT, normalized))
    vault_real = os.path.realpath(LOCAL_MEDIA_ROOT)
    if not full_path.startswith(vault_real + os.sep) or not os.path.isfile(full_path):
        raise HTTPException(status_code=404, detail="Fichier média introuvable.")
    ext = os.path.splitext(full_path)[1].lower()
    types = {".mp4":"video/mp4",".webm":"video/webm",".mov":"video/quicktime",".jpg":"image/jpeg",".jpeg":"image/jpeg",".png":"image/png",".mp3":"audio/mpeg",".wav":"audio/wav"}
    return FileResponse(full_path, media_type=types.get(ext,"application/octet-stream"))


@app.get("/health")
async def health_check():
    """Liveness only. Detailed external dependency checks are reported by /system/readiness."""
    return {"status":"alive","service":"Genia Apex Studio","version":app.version}


@app.get("/api/v1/billing/wallet")
async def get_billing_wallet(user_id: str = Depends(extract_user_id)):
    wallet = await get_or_create_wallet(user_id)
    return {"wallet": wallet, "plans": PLANS_CONFIG}


@app.post("/api/v1/billing/activate-plan")
async def activate_billing_plan(payload: ActivatePlanRequest, user_id: str = Depends(extract_user_id)):
    if not GENIA_AUTH_SECRET:
        raise HTTPException(status_code=503, detail="Secret de validation de paiement non configuré.")
    signed = f"{user_id}:{payload.plan_id}:{payload.payment_reference}".encode()
    expected = hmac.new(GENIA_AUTH_SECRET.encode(), signed, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, payload.payment_proof):
        raise HTTPException(status_code=403, detail="Preuve de paiement Base44 invalide.")
    if not firestore_client:
        raise HTTPException(status_code=503, detail="Firestore indisponible : activation suspendue.")
    cfg = PLANS_CONFIG[payload.plan_id]
    purchase_id = hashlib.sha256(f"{user_id}:{payload.payment_reference}".encode()).hexdigest()
    def _activate():
        wallet_ref = firestore_client.collection(FIRESTORE_COLLECTION_WALLETS).document(user_id)
        payment_ref = firestore_client.collection("genia_payments").document(purchase_id)
        tx = firestore_client.transaction()
        @firestore.transactional
        def _apply(transaction):
            old = payment_ref.get(transaction=transaction)
            if old.exists:
                return wallet_ref.get(transaction=transaction).to_dict()
            snap = wallet_ref.get(transaction=transaction)
            wallet = snap.to_dict() if snap.exists else {"user_id":user_id,"credits_balance":0}
            wallet.update({"plan_id":cfg["plan_id"],"credits_balance":int(wallet.get("credits_balance",0))+int(cfg["credits"]),
                           "max_duration_sec":cfg["max_duration_sec"],"expires_at":(_utc_now()+timedelta(days=CREDIT_VALIDITY_DAYS)).isoformat(),
                           "updated_at":_utc_now_iso()})
            transaction.set(wallet_ref,wallet,merge=True)
            transaction.create(payment_ref,{"user_id":user_id,"plan_id":payload.plan_id,"payment_reference":payload.payment_reference,"credits":cfg["credits"],"created_at":_utc_now_iso()})
            return wallet
        return _apply(tx)
    wallet = await run_in_executor(_activate)
    return {"status":"activated","wallet":wallet,"plan":cfg}


@app.post("/api/v1/voices/clone", status_code=status.HTTP_201_CREATED)
async def create_voice_clone_endpoint(
    source_audio: UploadFile = File(...),
    consent_audio: UploadFile = File(...),
    display_name: str = Form("Ma voix"),
    user_id: str = Depends(extract_user_id),
):
    """Crée un profil vocal OpenVoice V2 après réception de l'échantillon et du consentement."""
    if not display_name.strip():
        raise HTTPException(status_code=400, detail="Le nom de la voix est obligatoire.")
    source = await _read_upload_limited(source_audio, VOICE_SOURCE_MAX_BYTES)
    consent = await _read_upload_limited(consent_audio, 8 * 1024 * 1024)
    result = await create_openvoice_voice_profile(user_id, source, consent, display_name.strip())
    return result


@app.get("/api/v1/voices")
async def list_voice_profiles(user_id: str = Depends(extract_user_id)):
    if not firestore_client:
        raise HTTPException(status_code=503, detail="Firestore indisponible.")
    def _list():
        docs = firestore_client.collection("genia_voice_profiles").where("owner", "==", user_id).stream()
        return [{"voice_profile_id": d.id, "display_name": (d.to_dict() or {}).get("display_name"),
                 "status": (d.to_dict() or {}).get("status"), "created_at": (d.to_dict() or {}).get("created_at")}
                for d in docs]
    return {"voices": await run_in_executor(_list)}


@app.get("/api/v1/avatars")
async def list_avatars():
    return {"avatars": list(AVATAR_MODELS_CATALOG.values())}


@app.get("/api/v1/camera/presets")
async def list_camera_presets():
    return {"camera_presets": list(CAMERA_PRESETS_CATALOG.values())}


@app.get("/api/v1/photo-models")
async def list_photo_models():
    return {"photo_models": list(PHOTO_MODELS_CATALOG.values())}


@app.get("/api/v1/filters")
async def list_filters():
    return {"filters": list(FILTERS_CATALOG.values())}


@app.get("/api/v1/stickers")
async def list_stickers():
    return {"stickers": list(STICKERS_CATALOG.values())}


@app.get("/api/v1/templates")
async def list_templates(limit: int = 30):
    combined = await list_persisted_templates(max(1,min(100,limit)))
    return {"templates": combined[:max(1,min(100,limit))]}


@app.post("/api/v1/templates/generate-daily")
async def generate_daily_templates_endpoint(count: int = 3, user_id: str = Depends(extract_user_id)):
    safe_count = max(1, min(8, int(count)))
    generated = await ApexManagedGoogleModels.generate_daily_templates(count=safe_count)
    await persist_templates(generated)
    grounded = any(bool(x.get("source_urls")) for x in generated)
    return {"status": "google_search_grounded_trends" if grounded else "gemini_editorial_ideas_not_verified_trends", "templates": generated}


@app.post("/api/v1/render/start", status_code=status.HTTP_202_ACCEPTED)
async def start_avatar_render(payload: VideoRenderRequest, user_id: str = Depends(extract_user_id)):
    if payload.text_style_id not in ("pop_sticker_box", "neon_glow", "gradient_fire"): raise HTTPException(status_code=400, detail="Style de texte inconnu.")
    if payload.filter_id and payload.filter_id not in FILTERS_CATALOG: raise HTTPException(status_code=400, detail="Filtre inconnu.")
    if any(x not in STICKERS_CATALOG for x in payload.sticker_ids): raise HTTPException(status_code=400, detail="Sticker inconnu.")
    if payload.avatar_id and payload.avatar_id not in AVATAR_MODELS_CATALOG:
        raise HTTPException(status_code=400, detail="Avatar inconnu.")
    if payload.filter_id and payload.filter_id not in FILTERS_CATALOG:
        raise HTTPException(status_code=400, detail="Filtre inconnu.")
    wallet = await get_or_create_wallet(user_id)
    plan_id = wallet.get("plan_id", "plan_20")
    credits_needed, clamped_dur = compute_video_credit_cost(plan_id, payload.max_total_duration_sec)
    job_id = str(uuid.uuid4())
    updated_wallet = await charge_credits_atomic(user_id, credits_needed, f"Rendu Avatar ({clamped_dur}s)", idempotency_key=job_id)
    req_data = payload.model_dump()
    req_data["max_total_duration_sec"] = clamped_dur
    req_data["_charged_credits"] = credits_needed

    await set_job_store(job_id, {
        "status": "queued",
        "step": "En attente dans la file de rendu",
        "owner": user_id,
        "mode": "avatar",
        "free_tier": False,
        "credits_charged": credits_needed,
        "task_payload": req_data,
        "created_at": _utc_now_iso(),
    })

    await enqueue_render_task(job_id)
    return {
        "status": "processing",
        "job_id": job_id,
        "credits_charged": credits_needed,
        "credits_balance": updated_wallet.get("credits_balance", 0),
    }


@app.post("/api/v1/templates/apply", status_code=status.HTTP_202_ACCEPTED)
async def apply_template_endpoint(payload: TemplateApplyRequest, user_id: str = Depends(extract_user_id)):
    if payload.text_style_id not in ("pop_sticker_box", "neon_glow", "gradient_fire"): raise HTTPException(status_code=400, detail="Style de texte inconnu.")
    if payload.filter_id and payload.filter_id not in FILTERS_CATALOG: raise HTTPException(status_code=400, detail="Filtre inconnu.")
    if any(x not in STICKERS_CATALOG for x in payload.sticker_ids): raise HTTPException(status_code=400, detail="Sticker inconnu.")
    if not await get_template_by_id(payload.template_id): raise HTTPException(status_code=404, detail="Modèle vidéo introuvable.")
    quota = await enforce_free_quota_and_rate_limit(user_id)
    job_id = str(uuid.uuid4())
    await set_job_store(job_id, {
        "status": "queued",
        "step": "Préparation du template gratuit",
        "owner": user_id,
        "mode": "template_apply",
        "free_tier": True,
        "watermark_text": "Créé avec Genia",
        "credits_charged": 0,
        "task_payload": {**payload.model_dump(), "_max_allowed_dur": float(quota["max_duration_sec"])},
        "created_at": _utc_now_iso(),
    })
    await enqueue_render_task(job_id)
    return {"status": "processing", "job_id": job_id, "free_tier": True, "credits_charged": 0}


@app.post("/api/v1/photo-models/apply", status_code=status.HTTP_202_ACCEPTED)
async def apply_photo_model_endpoint(payload: PhotoModelApplyRequest, user_id: str = Depends(extract_user_id)):
    if payload.text_style_id not in ("pop_sticker_box", "neon_glow", "gradient_fire"): raise HTTPException(status_code=400, detail="Style de texte inconnu.")
    if payload.photo_model_id not in PHOTO_MODELS_CATALOG: raise HTTPException(status_code=400, detail="Modèle photo inconnu.")
    if payload.filter_id and payload.filter_id not in FILTERS_CATALOG: raise HTTPException(status_code=400, detail="Filtre inconnu.")
    if any(x not in STICKERS_CATALOG for x in payload.sticker_ids): raise HTTPException(status_code=400, detail="Sticker inconnu.")
    quota = await enforce_free_quota_and_rate_limit(user_id)
    job_id = str(uuid.uuid4())
    await set_job_store(job_id, {
        "status": "queued",
        "step": "Préparation du modèle photo gratuit",
        "owner": user_id,
        "mode": "photo_model_apply",
        "free_tier": True,
        "watermark_text": "Créé avec Genia",
        "credits_charged": 0,
        "task_payload": {**payload.model_dump(), "_max_allowed_dur": float(quota["max_duration_sec"])},
        "created_at": _utc_now_iso(),
    })
    await enqueue_render_task(job_id)
    return {"status": "processing", "job_id": job_id, "free_tier": True, "credits_charged": 0}


@app.post("/api/v1/camera/upload-recording")
async def upload_camera_recording(file: UploadFile = File(...), user_id: str = Depends(extract_user_id)):
    raw_name = file.filename or "recording.mp4"
    ext = os.path.splitext(raw_name)[1].lower()
    if ext not in (".webm", ".mp4", ".mov", ".m4v"):
        raise HTTPException(status_code=415, detail="Format vidéo non pris en charge.")
    rec_id = str(uuid.uuid4())
    temp_path = f"/tmp/rec_{rec_id}{ext}"
    total = 0
    try:
        with open(temp_path,"wb") as out:
            while True:
                chunk = await file.read(1024*1024)
                if not chunk: break
                total += len(chunk)
                if total > MAX_DOWNLOAD_BYTES: raise HTTPException(status_code=413, detail="Fichier vidéo trop volumineux.")
                out.write(chunk)
        if total == 0: raise HTTPException(status_code=400, detail="Fichier vidéo vide.")
        # FFprobe vérifie le contenu réel; l'extension seule n'est pas considérée comme une preuve.
        duration = _probe_media_duration(temp_path, default_sec=0)
        if duration <= 0: raise HTTPException(status_code=415, detail="Le fichier ne contient pas de vidéo lisible.")
        video_url = await run_in_executor(ensure_bucket_and_upload,temp_path,f"recordings/{user_id}/{rec_id}{ext}",rec_id)
        return {"status":"uploaded","recording_id":rec_id,"video_url":video_url}
    finally:
        if os.path.exists(temp_path): os.remove(temp_path)


@app.post("/api/v1/camera/record-studio", status_code=status.HTTP_202_ACCEPTED)
async def camera_record_studio_endpoint(payload: RecordStudioRequest, user_id: str = Depends(extract_user_id)):
    if payload.text_style_id not in ("pop_sticker_box", "neon_glow", "gradient_fire"): raise HTTPException(status_code=400, detail="Style de texte inconnu.")
    if payload.camera_preset_id not in CAMERA_PRESETS_CATALOG: raise HTTPException(status_code=400, detail="Préréglage caméra inconnu.")
    if payload.filter_id and payload.filter_id not in FILTERS_CATALOG: raise HTTPException(status_code=400, detail="Filtre inconnu.")
    if any(x not in STICKERS_CATALOG for x in payload.sticker_ids): raise HTTPException(status_code=400, detail="Sticker inconnu.")
    quota = await enforce_free_quota_and_rate_limit(user_id)
    job_id = str(uuid.uuid4())
    await set_job_store(job_id, {
        "status": "queued",
        "step": "Préparation des zooms et filtres",
        "owner": user_id,
        "mode": "camera_record_studio",
        "free_tier": True,
        "watermark_text": "Créé avec Genia",
        "credits_charged": 0,
        "task_payload": {**payload.model_dump(), "_max_allowed_dur": float(quota["max_duration_sec"])},
        "created_at": _utc_now_iso(),
    })
    await enqueue_render_task(job_id)
    return {"status": "processing", "job_id": job_id, "free_tier": True, "credits_charged": 0}


@app.post("/api/v1/song-photo/render", status_code=status.HTTP_202_ACCEPTED)
async def song_photo_render_endpoint(payload: SongPhotoRenderRequest, user_id: str = Depends(extract_user_id)):
    if payload.text_style_id not in ("pop_sticker_box", "neon_glow", "gradient_fire"): raise HTTPException(status_code=400, detail="Style de texte inconnu.")
    if payload.filter_id and payload.filter_id not in FILTERS_CATALOG: raise HTTPException(status_code=400, detail="Filtre inconnu.")
    if any(x not in STICKERS_CATALOG for x in payload.sticker_ids): raise HTTPException(status_code=400, detail="Sticker inconnu.")
    quota = await enforce_free_quota_and_rate_limit(user_id)
    job_id = str(uuid.uuid4())
    await set_job_store(job_id, {
        "status": "queued",
        "step": "Préparation Photo + Chanson",
        "owner": user_id,
        "mode": "song_photo",
        "free_tier": True,
        "watermark_text": "Créé avec Genia",
        "credits_charged": 0,
        "task_payload": {**payload.model_dump(), "_max_allowed_dur": float(quota["max_duration_sec"])},
        "created_at": _utc_now_iso(),
    })
    await enqueue_render_task(job_id)
    return {"status": "processing", "job_id": job_id, "free_tier": True, "credits_charged": 0}


@app.post("/api/v1/video/split-scenes", status_code=status.HTTP_202_ACCEPTED)
async def split_video_endpoint(payload: SplitVideoRequest, user_id: str = Depends(extract_user_id)):
    wallet = await get_or_create_wallet(user_id)
    plan_id = wallet.get("plan_id", "plan_20")
    total_est_dur = payload.num_clips * payload.clip_duration
    credits_needed, _ = compute_video_credit_cost(plan_id, total_est_dur)
    job_id = str(uuid.uuid4())
    await charge_credits_atomic(user_id, credits_needed, f"Découpage {payload.num_clips} extraits", idempotency_key=job_id)
    await set_job_store(job_id, {
        "status": "queued",
        "step": "Préparation du découpage",
        "owner": user_id,
        "mode": "split_video",
        "free_tier": False,
        "credits_charged": credits_needed,
        "task_payload": payload.model_dump(),
        "created_at": _utc_now_iso(),
    })
    await enqueue_render_task(job_id)
    return {"status": "processing", "job_id": job_id, "num_clips": payload.num_clips, "credits_charged": credits_needed}


@app.post("/api/v1/video/estimate-views")
async def estimate_views_endpoint(payload: ViewPotentialRequest, user_id: str = Depends(extract_user_id)):
    result = await ApexManagedGoogleModels.estimate_views_potential(payload)
    if payload.job_id:
        job = await get_job_store(payload.job_id)
        if not job or job.get("owner") != user_id:
            raise HTTPException(status_code=404, detail="Travail introuvable.")
        await set_job_store(payload.job_id, {"views_estimation": result})
    return result


@app.get("/api/v1/render/status/{job_id}")
async def get_render_status(job_id: str, user_id: str = Depends(extract_user_id)):
    job = await get_job_store(job_id)
    if not job or job.get("owner") != user_id:
        raise HTTPException(status_code=404, detail="Travail introuvable.")
    return job


@app.post("/api/v1/render/cancel/{job_id}")
async def cancel_render_job(job_id: str, user_id: str = Depends(extract_user_id)):
    job = await get_job_store(job_id)
    if not job or job.get("owner") != user_id:
        raise HTTPException(status_code=404, detail="Travail introuvable.")
    if job.get("status") not in ("completed", "failed", "cancelled"):
        await set_job_store(job_id, {"cancel_requested": True, "step": "Annulation demandée"})
        return {"status": "cancellation_requested", "job_id": job_id}
    return {"status": job.get("status"), "job_id": job_id}


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    ApexCloudTelemetry.emit("ERROR", "unhandled_http_error", path=str(request.url.path), error=str(exc)[:260])
    return JSONResponse(status_code=500, content={"detail": "Erreur interne du moteur Genia Apex."})