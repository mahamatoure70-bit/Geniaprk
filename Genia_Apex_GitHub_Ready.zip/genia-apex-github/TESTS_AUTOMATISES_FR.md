# Tests automatisés Genia Apex

Depuis ce dossier, exécuter :

```bash
python3 tests/validate_pack.py
python3 -m py_compile Genia_Apex_GoogleCloud_Base44.py genia_local_worker.py
bash -n start_genia_one_service.sh bootstrap_models.sh deploy_genia_one_service.sh
```

Ces tests valident la syntaxe, la présence des fichiers Docker, la correspondance des routes internes et le nom de la fonction Base44. Ils ne remplacent pas un build Docker, le chargement des poids sur un GPU L4, ni un test de bout en bout sur les comptes Google Cloud et Base44 réels.
