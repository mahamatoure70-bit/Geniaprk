#!/usr/bin/env bash
# Guided deployment: builds ONE container and deploys ONE Cloud Run GPU service.
set -euo pipefail

if ! command -v gcloud >/dev/null 2>&1; then
  echo "Ouvre Google Cloud Shell dans la console Google Cloud, puis relance ce script."
  exit 1
fi

read -rp "Google Cloud Project ID : " PROJECT_ID
read -rp "Région Cloud Run (défaut us-central1) : " REGION
REGION="${REGION:-us-central1}"
read -rp "Nom du bucket GCS (défaut ${PROJECT_ID}-genia-media) : " BUCKET
BUCKET="${BUCKET:-${PROJECT_ID}-genia-media}"
read -rp "Nom du service Cloud Run (défaut genia-apex) : " SERVICE
SERVICE="${SERVICE:-genia-apex}"
read -rp "Disque modèles (défaut 100Gi, quota Google requis) : " MODEL_DISK_SIZE
MODEL_DISK_SIZE="${MODEL_DISK_SIZE:-100Gi}"
if [[ ! "$MODEL_DISK_SIZE" =~ ^([1-9][0-9]?|100)Gi$ ]]; then
  echo "Taille invalide. Utilise une valeur entre 1Gi et 100Gi, par exemple 50Gi." >&2
  exit 2
fi
read -rp "URL publique Base44 (ex. https://mon-app.base44.app) : " BASE44_ORIGIN
BASE44_ORIGIN="${BASE44_ORIGIN%/}"
if [[ -z "$PROJECT_ID" || -z "$BASE44_ORIGIN" ]]; then echo "Project ID et URL Base44 obligatoires."; exit 2; fi

REPO="genia-apex"
RUNTIME_SA_NAME="genia-apex-runtime"
RUNTIME_SA="${RUNTIME_SA_NAME}@${PROJECT_ID}.iam.gserviceaccount.com"
QUEUE="genia-render-queue"
IMAGE="${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO}/genia-apex:one-service"

printf '\n[1/8] Projet et APIs Google Cloud...\n'
gcloud config set project "$PROJECT_ID" >/dev/null
gcloud services enable run.googleapis.com cloudbuild.googleapis.com artifactregistry.googleapis.com \
  secretmanager.googleapis.com cloudtasks.googleapis.com firestore.googleapis.com storage.googleapis.com \
  --project "$PROJECT_ID"

printf '\n[2/8] Bucket GCS et base Firestore...\n'
if ! gcloud storage buckets describe "gs://${BUCKET}" --project "$PROJECT_ID" >/dev/null 2>&1; then
  gcloud storage buckets create "gs://${BUCKET}" --location="$REGION" --uniform-bucket-level-access --project "$PROJECT_ID"
fi
if ! gcloud firestore databases describe --database='(default)' --project "$PROJECT_ID" >/dev/null 2>&1; then
  gcloud firestore databases create --database='(default)' --location="$REGION" --type=firestore-native --project "$PROJECT_ID"
fi

printf '\n[3/8] Compte de service et permissions...\n'
if ! gcloud iam service-accounts describe "$RUNTIME_SA" --project "$PROJECT_ID" >/dev/null 2>&1; then
  gcloud iam service-accounts create "$RUNTIME_SA_NAME" --display-name="Genia Apex one-service runtime" --project "$PROJECT_ID"
fi
for ROLE in roles/datastore.user roles/cloudtasks.enqueuer; do
  gcloud projects add-iam-policy-binding "$PROJECT_ID" --member="serviceAccount:${RUNTIME_SA}" --role="$ROLE" --quiet >/dev/null
done
# The runtime identity creates Cloud Tasks carrying its own OIDC identity.
gcloud iam service-accounts add-iam-policy-binding "$RUNTIME_SA" \
  --member="serviceAccount:${RUNTIME_SA}" --role=roles/iam.serviceAccountUser \
  --project "$PROJECT_ID" --quiet >/dev/null
gcloud storage buckets add-iam-policy-binding "gs://${BUCKET}" --member="serviceAccount:${RUNTIME_SA}" --role=roles/storage.objectAdmin --project "$PROJECT_ID" --quiet >/dev/null
PROJECT_NUMBER="$(gcloud projects describe "$PROJECT_ID" --format="value(projectNumber)")"
BUILD_SA="$(gcloud builds get-default-service-account --project "$PROJECT_ID" 2>/dev/null || true)"
if [[ -z "$BUILD_SA" ]]; then BUILD_SA="${PROJECT_NUMBER}-compute@developer.gserviceaccount.com"; fi
gcloud projects add-iam-policy-binding "$PROJECT_ID" --member="serviceAccount:${BUILD_SA}" --role=roles/artifactregistry.writer --quiet >/dev/null

printf '\n[4/8] Registre Docker, secret Base44 et file Cloud Tasks...\n'
if ! gcloud artifacts repositories describe "$REPO" --location "$REGION" --project "$PROJECT_ID" >/dev/null 2>&1; then
  gcloud artifacts repositories create "$REPO" --repository-format=docker --location "$REGION" --project "$PROJECT_ID"
fi
if gcloud secrets describe genia-auth-secret --project "$PROJECT_ID" >/dev/null 2>&1; then
  JWT_SECRET="$(gcloud secrets versions access latest --secret=genia-auth-secret --project "$PROJECT_ID")"
else
  JWT_SECRET="$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')"
  printf '%s' "$JWT_SECRET" | gcloud secrets create genia-auth-secret --replication-policy=automatic --data-file=- --project "$PROJECT_ID" >/dev/null
fi
gcloud secrets add-iam-policy-binding genia-auth-secret --member="serviceAccount:${RUNTIME_SA}" --role=roles/secretmanager.secretAccessor --project "$PROJECT_ID" --quiet >/dev/null
if ! gcloud tasks queues describe "$QUEUE" --location "$REGION" --project "$PROJECT_ID" >/dev/null 2>&1; then
  gcloud tasks queues create "$QUEUE" --location "$REGION" --project "$PROJECT_ID"
fi
# Keep jobs retryable while Cloud Run wakes and downloads/restores the large model set.
gcloud tasks queues update "$QUEUE" --location "$REGION" --project "$PROJECT_ID" \
  --max-attempts=100 --max-retry-duration=86400s --min-backoff=10s \
  --max-backoff=300s --max-doublings=5 --max-concurrent-dispatches=1 \
  --max-dispatches-per-second=1

printf '\n[5/8] Construction du conteneur unique API + worker GPU...\n'
gcloud builds submit --tag "$IMAGE" --project "$PROJECT_ID" .

printf '\n[6/8] Déploiement du service Cloud Run avec GPU L4 et disque cache modèles...\n'
echo "Disque demandé : ${MODEL_DISK_SIZE}.
Les poids durables sont conservés dans GCS ; ce disque est le cache local d'exécution.
Le quota Cloud Run standard peut être inférieur : demande l'augmentation nécessaire avant le déploiement.
Wan 2.2 TI2V-5B seul occupe environ 34,2 GB ; les autres modèles s'ajoutent."
gcloud run deploy "$SERVICE" --image "$IMAGE" --region "$REGION" --project "$PROJECT_ID" \
  --platform managed --execution-environment gen2 --gpu 1 --gpu-type nvidia-l4 --no-gpu-zonal-redundancy \
  --cpu 8 --memory 32Gi --concurrency 1 --timeout 3600 --min 0 --max 1 --no-cpu-throttling \
  --add-volume=name=genia-model-cache,type=ephemeral-disk,size="${MODEL_DISK_SIZE}" \
  --add-volume-mount=volume=genia-model-cache,mount-path=/opt/genia-models \
  --service-account "$RUNTIME_SA" --allow-unauthenticated \
  --set-env-vars="GCP_PROJECT_ID=${PROJECT_ID},GCP_LOCATION=${REGION},GCS_BUCKET_NAME=${BUCKET},GENIA_LOCAL_AI_URL=http://127.0.0.1:8090,GENIA_LOCAL_AI_TIMEOUT=3600,GENIA_MODEL_CACHE=/opt/genia-models,QWEN_MODEL_PATH=/opt/genia-models/Qwen2.5-3B-Instruct,SDXL_MODEL_PATH=/opt/genia-models/stable-diffusion-xl-base-1.0,WHISPER_MODEL_PATH=/opt/genia-models/faster-whisper-small,KOKORO_MODEL_PATH=/opt/genia-models/Kokoro-82M,CORS_ALLOWED_ORIGINS=${BASE44_ORIGIN},CLOUD_TASKS_QUEUE=${QUEUE},CLOUD_TASKS_LOCATION=${REGION},CLOUD_TASKS_SERVICE_ACCOUNT=${RUNTIME_SA},REQUIRE_CLOUD_STATE=true,MAX_VIDEO_DURATION_SEC=30,FREE_TIER_MAX_DURATION_SEC=30,MAX_CONCURRENT_RENDERS=1" \
  --set-secrets="GENIA_AUTH_SECRET=genia-auth-secret:latest"

SERVICE_URL="$(gcloud run services describe "$SERVICE" --region "$REGION" --project "$PROJECT_ID" --format='value(status.url)')"
if [[ -z "$SERVICE_URL" ]]; then echo "Cloud Run n'a pas retourné l'URL du service." >&2; exit 1; fi

printf '\n[7/8] Raccordement de Cloud Tasks au même service...\n'
gcloud run services add-iam-policy-binding "$SERVICE" --region "$REGION" --project "$PROJECT_ID" \
  --member="serviceAccount:${RUNTIME_SA}" --role=roles/run.invoker --quiet >/dev/null
gcloud run services update "$SERVICE" --region "$REGION" --project "$PROJECT_ID" \
  --update-env-vars="CLOUD_TASKS_SERVICE_URL=${SERVICE_URL},PUBLIC_BASE_URL=${SERVICE_URL}" --quiet

printf '\n[8/8] Terminé : un seul service Cloud Run est déployé.\n'
cat <<SUMMARY

URL Genia Apex : ${SERVICE_URL}
URL Base44 autorisée : ${BASE44_ORIGIN}
Diagnostic : ${SERVICE_URL}/api/v1/system/readiness
Bucket : gs://${BUCKET}
Service unique : ${SERVICE}

SECRET À COPIER DANS LES SECRETS SERVEUR BASE44 (GENIA_AUTH_SECRET) :
${JWT_SECRET}

URL À RENSEIGNER DANS BASE44 (GENIA_APEX_API_URL) :
${SERVICE_URL}

Le worker GPU est privé à l'intérieur du même conteneur : 127.0.0.1:8090.
Le service peut revenir à zéro instance pour limiter les frais GPU au repos; au réveil,
les poids sont restaurés depuis GCS et Cloud Tasks attend la disponibilité des moteurs.
Les poids Wan, OpenVoice V2, LatentSync, Qwen, SDXL, Whisper-small et Kokoro sont téléchargés au premier démarrage puis sauvegardés dans GCS.
Attends que /api/v1/system/readiness indique les moteurs prêts avant de lancer une génération.
SUMMARY
