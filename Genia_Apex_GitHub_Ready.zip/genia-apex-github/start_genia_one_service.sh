#!/usr/bin/env bash
set -euo pipefail

# One private loopback worker and one public FastAPI backend in a single Cloud Run service.
export GENIA_LOCAL_AI_URL="${GENIA_LOCAL_AI_URL:-http://127.0.0.1:8090}"
if [ -z "${GENIA_LOCAL_AI_TOKEN:-}" ]; then
  export GENIA_LOCAL_AI_TOKEN="$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')"
fi

# Model weights are fetched into the container's writable model cache after startup.
# The HTTP servers start immediately; model-backed endpoints report 503 while warming.
rm -f /tmp/genia-model-bootstrap.status
(/opt/bootstrap_models.sh > /tmp/genia-model-bootstrap.log 2>&1 || { echo "MODEL_BOOTSTRAP_FAILED" > /tmp/genia-model-bootstrap.status; tail -n 80 /tmp/genia-model-bootstrap.log >&2; }) &
BOOTSTRAP_PID=$!

python3 -m uvicorn genia_local_worker:APP --app-dir /opt --host 127.0.0.1 --port 8090 \
  > /tmp/genia-local-worker.log 2>&1 &
WORKER_PID=$!

cleanup() {
  kill "$WORKER_PID" 2>/dev/null || true
  kill "$BOOTSTRAP_PID" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

# Wait only for the worker HTTP process, not for multi-GB model downloads.
for i in $(seq 1 60); do
  if curl -fsS http://127.0.0.1:8090/health >/dev/null 2>&1; then break; fi
  if ! kill -0 "$WORKER_PID" 2>/dev/null; then
    cat /tmp/genia-local-worker.log >&2 || true
    exit 1
  fi
  sleep 1
done
if ! curl -fsS http://127.0.0.1:8090/health >/dev/null 2>&1; then
  echo "Local inference worker did not start" >&2
  cat /tmp/genia-local-worker.log >&2 || true
  exit 1
fi

python3 -m uvicorn main:app --app-dir /app --host 0.0.0.0 --port "${PORT:-8080}" &
API_PID=$!
wait "$API_PID"
