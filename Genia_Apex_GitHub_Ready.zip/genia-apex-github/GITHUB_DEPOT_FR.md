# Déposer Genia Apex dans GitHub

## Contenu à envoyer

Téléverse le contenu de ce dossier `genia_delivery` à la racine d'un dépôt GitHub privé nommé par exemple `genia-apex`. Le `Dockerfile`, `deploy_genia_one_service.sh`, `start_genia_one_service.sh`, `bootstrap_models.sh`, le backend et le worker doivent être à la racine du dépôt.

## Fichiers à ne jamais envoyer

Le `.gitignore` exclut les secrets, fichiers de compte de service, environnements Python, caches et poids de modèles. Ne dépose jamais `GENIA_AUTH_SECRET`, une clé JSON Google, `.env` ou des poids de modèles dans GitHub.

## Déploiement depuis GitHub

Après avoir envoyé les fichiers, ouvre Google Cloud Shell et exécute :

```bash
git clone https://github.com/TON_COMPTE/genia-apex.git
cd genia-apex
bash deploy_genia_one_service.sh
```

Remplace `TON_COMPTE` par ton identifiant GitHub. Le script configure les APIs, le bucket GCS, Firestore, le compte de service, Secret Manager, Cloud Tasks, construit l'image Docker et déploie le service Cloud Run GPU L4.

## Première mise en route

Le premier démarrage télécharge les modèles depuis Hugging Face et les sauvegarde dans GCS. Il peut prendre longtemps. Le service est configuré pour pouvoir revenir à zéro instance afin de limiter les frais GPU au repos. Les tâches de génération sont mises en attente et réessayées pendant le téléchargement/restauration des poids.

Vérifie ensuite `https://URL-CLOUD-RUN/api/v1/system/readiness`. Ne lance pas de production payante tant que les moteurs requis ne sont pas indiqués prêts et qu'une génération complète de test n'a pas réussi.

## Prérequis Google Cloud

- Facturation active et quota Cloud Run GPU NVIDIA L4 dans la région choisie.
- Quota de disque éphémère suffisant : 100 Gio demandés par défaut (quota standard souvent inférieur).
- Accès réseau sortant à Hugging Face au premier téléchargement.
- Le bucket GCS doit pouvoir stocker plusieurs dizaines de Gio de poids de modèles, en plus des médias générés.
