# Modèles et stockage — Genia Apex

Le bootstrap télécharge automatiquement Wan 2.2 TI2V-5B, OpenVoice V2, LatentSync 1.5, Qwen 2.5 3B, SDXL, Faster-Whisper small et Kokoro. Les snapshots sont conservés dans le bucket GCS sous `genia-model-cache/` et restaurés dans le disque local Cloud Run au démarrage suivant. Les sorties générées restent également stockées dans GCS.

Le disque demandé par défaut est 100Gi. Le modèle Wan 2.2 TI2V-5B représente environ 34,2 GB à lui seul ; les autres modèles s'ajoutent. Le quota Cloud Run par défaut peut être inférieur et doit être augmenté par le propriétaire du projet si nécessaire.

Le ZIP ne contient pas les poids de modèles (plusieurs dizaines de Go). Le premier démarrage les télécharge automatiquement depuis Hugging Face puis les sauvegarde dans GCS. Cela nécessite une facturation Google Cloud active, un compte de service autorisé sur le bucket et un accès réseau sortant.

Ce pack n'a pas été exécuté sur un GPU L4 réel dans cet environnement. La génération vidéo finale et les dépendances natives doivent encore être validées sur le projet Cloud réel. La réussite des tests statiques ne certifie pas une génération en production.


Le téléchargement/restauration de chaque dépôt est retenté jusqu'à trois fois en cas d'erreur transitoire. Si le bootstrap échoue définitivement (modèle inaccessible, droits Hugging Face, quota ou IAM), le diagnostic signale l'échec et les journaux Cloud Run indiquent le modèle concerné.
