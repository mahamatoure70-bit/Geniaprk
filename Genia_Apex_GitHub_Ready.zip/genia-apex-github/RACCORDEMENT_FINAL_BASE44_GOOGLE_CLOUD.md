# Raccordement final Genia Apex — Base44 + Google Cloud Run

## Contenu ajouté / ajusté

- La fonction serveur Base44 `base44/functions/genia-apex-token/entry.ts` est un composant requis à créer et déployer dans ton projet existant ; elle n’est pas incluse dans cette archive car son SDK/runtime doit être confirmé dans ton projet.
- `Base44GeniaApexPage.tsx` : adaptateur React qui appelle la fonction Base44 et transmet le jeton au studio.
- `GeniaApexStudio.tsx` : interface conservée ; le traitement Camera Studio passe maintenant par le gestionnaire d'état/erreur commun.
- `geniaApexApi.ts` : refuse maintenant de démarrer si l'URL du moteur est vide.
- `Genia_Apex_GoogleCloud_Base44.py`, `Dockerfile`, `requirements_Genia_Apex.txt` : moteur et déploiement Cloud Run conservés.

## 1. Ajouter les fichiers dans l'application Base44 existante

1. Copier `GeniaApexStudio.tsx` dans `src/components/genia-apex/GeniaApexStudio.tsx`.
2. Copier `geniaApexApi.ts` dans le même dossier.
3. Copier `Base44GeniaApexPage.tsx` dans le dossier des pages, puis vérifier l'import du composant si le projet utilise un autre alias.
4. Créer la fonction serveur `base44/functions/genia-apex-token/entry.ts` selon le runtime Base44 de ton projet, puis la déployer. Elle doit lire la session vérifiée côté serveur, signer le JWT HS256 avec le secret serveur et refuser les appels sans session.
5. Ajouter la page à la navigation/route existante sans remplacer les autres pages.
6. Vérifier que `lucide-react` est déjà installé ; l'ajouter seulement s'il manque.

Le client Base44 est importé depuis `@/api/base44Client`, chemin standard des projets Base44. Si ton projet utilise un autre chemin, adapte uniquement cet import.

## 2. Secrets et variables Base44

Dans les paramètres serveur / secrets de Base44 :

- `GENIA_AUTH_SECRET` : secret aléatoire d'au moins 32 caractères (utiliser exactement la même valeur dans Cloud Run).
- `VITE_GENIA_APEX_API_URL` : URL HTTPS publique du service Cloud Run, par exemple `https://NOM-SERVICE-xxxxx-uc.a.run.app`.

`VITE_GENIA_APEX_API_URL` est une URL publique, pas un secret. Ne mets jamais `GENIA_AUTH_SECRET` dans une variable `VITE_` ni dans le code navigateur.

## 3. Variables Cloud Run

Configurer au minimum :

- `GENIA_AUTH_SECRET` : même secret que dans Base44.
- `GENIA_JWT_ISSUER=base44`
- `GENIA_JWT_AUDIENCE=genia-apex`
- `GCP_PROJECT_ID` : identifiant du projet Google Cloud.
- `GCP_LOCATION` : région Vertex AI / Google Cloud choisie.
- `GCS_BUCKET_NAME` : bucket média privé.
- `GENIA_LOCAL_AI_URL` : `http://127.0.0.1:8090` (worker interne au même conteneur).
- `GENIA_LOCAL_AI_TOKEN` : secret partagé backend/worker, à stocker dans Secret Manager.
- `CLOUD_TASKS_SERVICE_URL` : URL HTTPS du service Cloud Run.
- `CLOUD_TASKS_SERVICE_ACCOUNT` : adresse du compte de service utilisé par Cloud Tasks.
- `CLOUD_TASKS_QUEUE` et `CLOUD_TASKS_LOCATION` : file et région Cloud Tasks.
- `CORS_ALLOWED_ORIGINS` : origine exacte de l'application Base44 publiée (sans chemin).

Activer les API Google nécessaires et accorder au compte de service backend les permissions IAM adaptées pour Firestore, Cloud Storage, Cloud Tasks et la signature des URL GCS. Les chemins Gemini/Vertex de cette version sont désactivés : Vertex AI n'est pas requis pour les générations locales. Le compte de service Cloud Tasks doit pouvoir invoquer Cloud Run ; son jeton OIDC est vérifié par le moteur.

## 4. Flux d'authentification

1. L'utilisateur se connecte normalement à Base44.
2. `GeniaApexPage` appelle `genia-apex-token`.
3. La fonction appelle `base44.auth.me()` ; elle n'accepte aucun identifiant utilisateur fourni par le navigateur.
4. La fonction signe un JWT HS256 contenant `sub`, `iss`, `aud`, `iat` et `exp` (15 minutes).
5. Le client API transmet ce jeton dans `Authorization: Bearer ...`.
6. Le moteur vérifie la signature, l'émetteur, l'audience et l'expiration.

Le secret n'est jamais renvoyé au navigateur.

## 5. Médias et crédits

- Le moteur conserve ses propres routes de stockage GCS et de traitement.
- Les champs URL des modules doivent recevoir des URLs réellement accessibles au moteur. Pour les fichiers gérés par Base44, utiliser le système d'upload média déjà présent dans l'application puis transmettre l'URL retournée.
- Ne pas créer une route d'upload Base44 fictive.
- Ne pas appeler `activatePlan` depuis une action utilisateur non autorisée. Conserver les paiements et le portefeuille de l'application existante ; toute preuve de paiement doit être produite et validée côté serveur après confirmation du prestataire.

## 6. Contrôles effectués sur les archives fournies

- Le code Python du moteur est identique dans les deux ZIP d'origine.
- Le moteur Python passe l'analyse syntaxique Python.
- Les routes utilisées par `geniaApexApi.ts` existent dans le moteur.
- Le Dockerfile copie le moteur sous `main.py` et démarre Uvicorn sur le port Cloud Run.
- Le client API n'accepte plus une URL vide silencieusement.
- Le Camera Studio remonte maintenant ses erreurs et son état de chargement via le même gestionnaire que les autres actions.

## 7. Vérifications à faire après raccordement

- Déployer le service Cloud Run et vérifier `/health`.
- Vérifier `/api/v1/system/readiness` : `configured` est requis pour l'état complet ; `degraded` signifie qu'une ou plusieurs dépendances manquent.
- Tester la fonction Base44 en étant connecté, puis vérifier qu'un appel sans session renvoie 401.
- Vérifier que le JWT expire après 15 minutes.
- Tester un rendu réel, son suivi, puis son téléchargement.
- Tester sur téléphone et ordinateur.
- Vérifier que le solde affiché provient du portefeuille existant et qu'aucun crédit n'est créé par le seul affichage de l'interface.

## Limites importantes

Ce pack prépare le code de raccordement ; il ne peut pas créer les secrets, les ressources IAM, la file Cloud Tasks, le bucket, ni publier le service dans tes comptes Google Cloud/Base44. Ces opérations doivent être réalisées dans tes consoles avec tes accès.

## Déploiement Cloud Run en un seul service

Le mode livré dans cette archive regroupe le backend et le worker GPU dans un seul conteneur. Dans `genia_delivery`, exécuter `bash deploy_genia_one_service.sh`. Le script construit le `Dockerfile` unique, déploie un seul service Cloud Run L4, configure les ressources Google Cloud et affiche l'URL API ainsi que le secret à ajouter dans Base44.

Le worker écoute en interne sur `127.0.0.1:8090`; il ne faut pas créer un deuxième service GPU ni utiliser les anciennes instructions de déploiement séparé. Le cache local de modèles demande 100 Gio par défaut; le quota Cloud Run peut devoir être augmenté. Les poids sont sauvegardés durablement dans GCS puis restaurés si l'instance est remplacée.
