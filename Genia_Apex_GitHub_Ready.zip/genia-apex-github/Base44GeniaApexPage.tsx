import React, { useCallback } from "react";
import { base44 } from "@/api/base44Client";
import GeniaApexStudio from "@/components/genia-apex/GeniaApexStudio";

export default function GeniaApexPage() {
  const getAccessToken = useCallback(async () => {
    const response = await base44.functions.invoke("genia-apex-token", {});
    const token = response?.data?.token;
    if (!token) {
      throw new Error(response?.data?.error || "Base44 n'a pas fourni de jeton Genia Apex.");
    }
    return token as string;
  }, []);

  const apiBaseUrl = (import.meta as any).env?.VITE_GENIA_APEX_API_URL || "";

  return (
    <GeniaApexStudio
      apiBaseUrl={apiBaseUrl}
      getAccessToken={getAccessToken}
    />
  );
}
