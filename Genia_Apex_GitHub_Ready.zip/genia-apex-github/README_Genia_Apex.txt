GENIA APEX — MOTEURS OUVERTS ET INFRASTRUCTURE GOOGLE CLOUD

Base44 = application SaaS et interface utilisateur.
Google Cloud = API FastAPI, worker GPU L4, stockage GCS, Firestore et file Cloud Tasks.

MOTEURS LOCAUX CONFIGURÉS
- Wan 2.2 TI2V-5B : génération vidéo à partir de texte ou image.
- Qwen 2.5 3B Instruct : compréhension et préparation de prompts.
- OpenVoice V2 + MeloTTS : synthèse vocale et transfert de timbre avec consentement.
- LatentSync 1.5 : synchronisation lèvres/voix.
- SDXL : génération et édition d'images.
- Faster-Whisper small : transcription locale.
- Kokoro 82M : synthèse vocale locale.

Les chemins Gemini/Live/Omni et Google Search grounding sont désactivés dans cette configuration.
Les appels Google Cloud actifs servent principalement à l'infrastructure, au stockage et à l'orchestration; l'API ne lance pas une génération Veo/Gemini à chaque vidéo.

Les poids des modèles ne sont pas versionnés dans GitHub ni intégrés au ZIP. Au premier démarrage, le bootstrap les télécharge depuis Hugging Face puis les sauvegarde dans le bucket GCS. Le cache local Cloud Run est temporaire; GCS est la copie durable.

La configuration de déploiement limite chaque rendu à 30 secondes et à une génération simultanée.
Lire README.md, GITHUB_DEPOT_FR.md et DEPLOIEMENT_UN_SEUL_SERVICE_FR.txt avant le déploiement.
