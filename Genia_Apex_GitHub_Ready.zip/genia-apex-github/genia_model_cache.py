#!/usr/bin/env python3
"""GCS-backed Hugging Face model snapshot cache for Genia Apex."""
from __future__ import annotations
import argparse, os
from pathlib import Path
from google.cloud import storage
from huggingface_hub import snapshot_download

def ensure_snapshot(repo_id: str, destination: str, prefix: str, allow_patterns: list[str] | None = None) -> None:
    dest = Path(destination)
    marker = dest / ".genia_snapshot_complete"
    if marker.is_file():
        print(f"[cache] local snapshot ready: {repo_id}", flush=True)
        return
    bucket_name = os.environ.get("GCS_BUCKET_NAME", "").strip()
    if not bucket_name:
        raise RuntimeError("GCS_BUCKET_NAME is required for durable model storage")
    client = storage.Client(project=os.environ.get("GCP_PROJECT_ID") or None)
    bucket = client.bucket(bucket_name)
    prefix = prefix.strip("/") + "/"
    complete_blob = bucket.blob(prefix + "_GENIA_COMPLETE")
    dest.mkdir(parents=True, exist_ok=True)
    if complete_blob.exists(client):
        print(f"[cache] restoring {repo_id} from GCS", flush=True)
        for blob in client.list_blobs(bucket, prefix=prefix):
            rel = blob.name[len(prefix):]
            if not rel or rel == "_GENIA_COMPLETE":
                continue
            target = (dest / rel).resolve()
            if not target.is_relative_to(dest.resolve()):
                raise RuntimeError(f"Unsafe GCS object path in model cache: {blob.name}")
            target.parent.mkdir(parents=True, exist_ok=True)
            blob.download_to_filename(str(target))
    else:
        print(f"[cache] downloading {repo_id} from Hugging Face", flush=True)
        snapshot_download(repo_id=repo_id, local_dir=str(dest), allow_patterns=allow_patterns)
        print(f"[cache] persisting {repo_id} to GCS", flush=True)
        for item in dest.rglob("*"):
            if not item.is_file() or item.is_symlink():
                continue
            rel = item.relative_to(dest).as_posix()
            if rel == ".genia_snapshot_complete" or rel.startswith(".cache/huggingface/"):
                continue
            bucket.blob(prefix + rel).upload_from_filename(str(item))
        complete_blob.upload_from_string(repo_id + "\n", content_type="text/plain")
    files = [p for p in dest.rglob("*") if p.is_file() and not p.is_symlink()]
    if not files:
        raise RuntimeError(f"Snapshot {repo_id} is empty after download/restore")
    marker.write_text(repo_id + "\n", encoding="utf-8")
    print(f"[cache] ready: {repo_id} ({len(files)} files)", flush=True)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--destination", required=True)
    parser.add_argument("--prefix", required=True)
    parser.add_argument("--allow", action="append", default=None)
    args = parser.parse_args()
    ensure_snapshot(args.repo, args.destination, args.prefix, args.allow)

if __name__ == "__main__":
    main()
