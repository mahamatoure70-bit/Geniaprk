import { createClientFromRequest } from "npm:@base44/sdk@0.8.20";
import { secrets } from "base44:runtime";

const encoder = new TextEncoder();

function base64UrlEncode(bytes: Uint8Array): string {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}

function encodeJson(value: unknown): string {
  return base64UrlEncode(encoder.encode(JSON.stringify(value)));
}

async function signHs256(signingInput: string, secret: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const signature = await crypto.subtle.sign("HMAC", key, encoder.encode(signingInput));
  return base64UrlEncode(new Uint8Array(signature));
}

export default async function (req: Request): Promise<Response> {
  if (req.method !== "POST") {
    return Response.json({ error: "Méthode non autorisée." }, { status: 405 });
  }

  try {
    // The user identity is derived from the authenticated Base44 session only.
    // Any user_id sent in the request body is deliberately ignored.
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch(() => null);
    if (!user) {
      return Response.json({ error: "Authentification Base44 requise." }, { status: 401 });
    }

    const userId = String(user.id ?? user._id ?? "").trim();
    if (!/^[A-Za-z0-9_@.+-]{1,120}$/.test(userId)) {
      return Response.json({ error: "Identifiant utilisateur Base44 absent ou non pris en charge." }, { status: 401 });
    }

    const secret = secrets.get("GENIA_AUTH_SECRET");
    if (!secret || secret.length < 32) {
      return Response.json({ error: "Le secret serveur GENIA_AUTH_SECRET doit contenir au moins 32 caractères." }, { status: 503 });
    }

    const now = Math.floor(Date.now() / 1000);
    const header = encodeJson({ alg: "HS256", typ: "JWT" });
    const payload = encodeJson({
      sub: userId,
      iss: "base44",
      aud: "genia-apex",
      iat: now,
      exp: now + 15 * 60,
    });
    const signingInput = `${header}.${payload}`;
    const signature = await signHs256(signingInput, secret);
    const token = `${signingInput}.${signature}`;

    return Response.json(
      { token, expires_at: now + 15 * 60 },
      { headers: { "Cache-Control": "no-store, private" } },
    );
  } catch (_error) {
    return Response.json({ error: "Impossible d'émettre le jeton Genia Apex." }, { status: 500 });
  }
}
