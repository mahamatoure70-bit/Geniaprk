# Genia Apex — raccordement des moteurs locaux

## Moteurs raccordés dans cette version

- **Wan 2.2 TI2V-5B** : génération des scènes vidéo à partir d'un prompt et, lorsque disponible, d'une image de référence. Les durées de scène sont converties en nombre d'images Wan (`4n + 1`), puis les scènes sont assemblées par le backend.
- **Qwen2.5-3B-Instruct** : développement des scripts en scènes, génération de modèles éditoriaux, accroches et score éditorial. Le score n'est jamais présenté comme une prédiction de vues.
- **Kokoro 82M** : voix française standard.
- **OpenVoice V2 + MeloTTS FR** : création d'un profil vocal à partir d'un échantillon fourni avec consentement, sauvegarde de l'empreinte dans GCS, contrôle du propriétaire du profil dans Firestore et synthèse personnalisée dans les rendus.
- **faster-whisper** : transcription audio locale et horodatage des mots.
- **Stable Diffusion XL** : génération et édition d'images, y compris l'image de référence de l'avatar.
- **LatentSync 1.5** : synchronisation audio/lèvres sur les scènes vidéo d'avatar, après le rendu Wan et la création de la piste vocale. Le moteur est installé dans un environnement Python séparé pour éviter les conflits de dépendances.
- **FFmpeg** : composition, sous-titres, filtres, musique, assemblage et export MP4.

Les anciennes initialisations Gemini/Vertex, Gemini Live, Gemini Omni et la réplication vocale Google sont désactivées dans le backend livré. Les fonctions principales de génération passent par `GENIA_LOCAL_AI_URL`.

## Clonage vocal — fonctionnement

1. Le client envoie un échantillon vocal d'au moins 6 secondes (10 à 30 secondes conseillées) et le fichier de consentement à `POST /api/v1/voices/clone`.
2. Le backend vérifie la session Base44, la taille des fichiers et la présence du consentement.
3. Le worker crée l'empreinte OpenVoice V2 et la dépose dans le bucket GCS.
4. Firestore conserve l'identifiant du propriétaire, le nom du profil, l'URI GCS de l'empreinte et l'empreinte SHA-256 du fichier de consentement.
5. À chaque rendu, le backend vérifie que le profil appartient à l'utilisateur avant d'envoyer l'URI au worker.

Le fichier source vocal et le fichier de consentement ne sont pas conservés par cette route. Le hash du consentement est conservé pour l'audit; il ne prouve pas à lui seul l'identité de la personne. Il faut obtenir l'autorisation explicite de la personne dont la voix est clonée.

## Synchronisation labiale — fonctionnement

Le backend génère l'audio, produit une scène Wan avec l'image de référence de l'avatar, puis envoie la vidéo et l'audio au point `/v1/videos/lipsync`. LatentSync 1.5 produit une nouvelle vidéo; le worker remuxe la piste audio originale avant de la publier dans GCS. Si le moteur échoue, le rendu échoue au lieu de prétendre que les lèvres sont synchronisées.

LatentSync synchronise la bouche d'un visage visible dans une vidéo existante. Il ne garantit pas l'identité parfaite du visage, la qualité de tous les plans Wan, ni des gestes corporels naturels. Il faut valider le rendu avec des échantillons réels.

## Analyse de clips et score éditorial

- Le score éditorial utilise Qwen local sur le script ou les sous-titres. Il n'est pas une estimation de vues.
- La sélection automatique des passages utilise faster-whisper pour transcrire l'audio, puis Qwen sélectionne des plages à partir des horodatages réels. Cette version n'effectue pas d'analyse visuelle multimodale complète des actions à l'écran.

## Déploiement centralisé en un seul service Cloud Run

Le mode livré dans ce pack utilise **un seul conteneur et un seul service Cloud Run** :
- l'API FastAPI écoute sur le port public `8080`;
- le worker de modèles écoute sur `127.0.0.1:8090`, sans exposition Internet;
- `GENIA_LOCAL_AI_URL` est fixé à `http://127.0.0.1:8090` dans le conteneur;
- l'API et le worker partagent le même compte de service et les accès GCS;
- le script crée ou vérifie le bucket, Firestore par défaut, Artifact Registry, Secret Manager et Cloud Tasks.

Dans `genia_delivery`, lancer le script guidé :

```bash
bash deploy_genia_one_service.sh
```

Le script demande le projet, la région, le bucket et le nom du service. Il génère le secret JWT, le conserve dans Secret Manager et l'affiche à la fin pour le saisir dans les secrets serveur Base44. Il construit l'image depuis le `Dockerfile` unique et déploie l'API et le worker ensemble. Il n'y a pas de second service GPU à créer.

Le service utilise un GPU NVIDIA L4, 8 CPU, 32 Gio de mémoire, une instance minimale et un disque local de cache des modèles de 100 Gio par défaut monté sur `/opt/genia-models`, avec sauvegarde durable des poids dans GCS. Le projet doit disposer du quota GPU L4 et d'un quota de disque éphémère suffisant. Google Cloud accorde par défaut 10 Gio par instance pour le disque éphémère; une demande d'augmentation de quota peut donc être nécessaire avant ce déploiement. Le disque est temporaire : si l'instance est remplacée, les poids seront téléchargés à nouveau.

Après déploiement, ajouter dans les secrets serveur Base44 la valeur affichée pour `GENIA_AUTH_SECRET`, puis configurer `GENIA_APEX_API_URL` avec l'URL Cloud Run. Attendre la fin du téléchargement initial des modèles et vérifier `/api/v1/system/readiness` avant les tests de génération.

Le script ne peut pas modifier l'application Base44 à votre place. Le build Docker, les téléchargements des poids et les inférences GPU doivent encore être testés dans le projet réel.

### Coûts

Le déploiement proposé utilise `--min 1` pour éviter de retélécharger plusieurs dizaines de gigaoctets de modèles à chaque réveil. Cela signifie qu'une instance L4 reste allouée même sans génération et continue d'être facturée. Le compte de facturation Google Cloud paie cette infrastructure, le stockage et le réseau. Les poids ouverts téléchargés ne facturent pas une redevance par génération, mais le GPU et l'infrastructure, eux, sont facturés. Supprimer ou réduire le service quand il n'est pas utilisé réduit les coûts mais implique un nouveau démarrage et le rechargement des modèles.

## Licences et points à vérifier

- OpenVoice V2 : MIT selon le dépôt officiel.
- LatentSync : code Apache-2.0; poids du modèle publiés sous OpenRAIL++ avec conditions d'utilisation à examiner avant commercialisation.
- Wan 2.2 TI2V-5B : Apache-2.0 selon le dépôt officiel.
- SDXL : vérifier les conditions Stability AI applicables à la distribution et à l'usage commercial.
- Les licences des modèles et des dépendances doivent être conservées avec les versions utilisées.

## État des vérifications

Les fichiers Python et scripts shell de cette archive ont été vérifiés syntaxiquement. Cette vérification ne remplace pas un build Docker, le téléchargement des poids, une exécution GPU, des tests de qualité vocale, des tests de synchronisation sur de vrais visages, ni un déploiement dans le compte Google Cloud du propriétaire. Ne pas annoncer une disponibilité commerciale « 100 % validée » avant ces essais de bout en bout.
