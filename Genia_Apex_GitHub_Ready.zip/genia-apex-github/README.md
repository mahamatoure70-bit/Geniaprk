# Genia Apex — Interface Base44 (noir premium / violet électrique)

Ce pack fournit une page React/TypeScript d'interface et un client API qui utilisent les routes réellement présentes dans `Genia_Apex_GoogleCloud_Base44.py`.

## Contenu
- `GeniaApexStudio.tsx` : interface responsive, navigation, formulaires de création, suivi d'une tâche, catalogues, portefeuille, diagnostic système et Self-Healing.
- `geniaApexApi.ts` : client HTTP vers le backend FastAPI.
- `BASE44_PROMPT_FR.txt` : instructions à coller dans le chat d'édition Base44 pour intégrer la page dans l'application existante.

## Important — accès Base44
Ce pack n'a pas modifié ni publié votre application Base44 : cette conversation ne dispose pas d'une connexion d'édition à votre projet Base44. Importez les deux fichiers dans le code de l'application existante et suivez `BASE44_PROMPT_FR.txt`. Ne créez pas une nouvelle application.

## Dépendance UI
Le composant utilise `lucide-react` et les classes Tailwind CSS. Si l'application ne l'a pas déjà :
`npm install lucide-react`

## Montage du composant
Le composant attend deux props :
- `apiBaseUrl` : URL publique HTTPS du service Genia Apex sur Cloud Run.
- `getAccessToken` : fonction qui demande à une fonction serveur Base44 un JWT court pour l'utilisateur actuellement connecté.

Exemple de montage (adapter l'authentification à l'API Base44 réellement installée dans votre projet) :

```tsx
<GeniaApexStudio
  apiBaseUrl={import.meta.env.VITE_GENIA_APEX_API_URL}
  getAccessToken={async () => {
    // Appeler ici une fonction serveur Base44 qui signe un JWT pour l'utilisateur connecté.
    // Ne jamais signer le JWT dans le navigateur et ne jamais exposer GENIA_AUTH_SECRET.
    const result = await base44.functions.invoke("genia-apex-token", {});
    return result.data.token;
  }}
/>
```

## Contrat JWT exigé par le backend actuel
Le backend vérifie un JWT HS256 avec :
- `sub` : identifiant de l'utilisateur Base44 (1 à 120 caractères parmi A-Z, a-z, 0-9, `_@.+-`)
- `iss` : valeur de `GENIA_JWT_ISSUER` (défaut `base44`)
- `aud` : valeur de `GENIA_JWT_AUDIENCE` (défaut `genia-apex`)
- `exp` : expiration future, au maximum une heure après l'émission
- signature HS256 avec `GENIA_AUTH_SECRET` (minimum 32 caractères)

La fonction serveur Base44 doit utiliser l'identité réelle de la session côté serveur. Le secret doit exister uniquement dans les secrets serveur Base44 et dans l'environnement Cloud Run, avec la même valeur. Ne pas accepter un `user_id` fourni par le navigateur comme identité.

## Routes réellement consommées
- `GET /api/v1/system/readiness`
- `GET /api/v1/billing/wallet`
- `GET /api/v1/avatars`, `/voices`, `/camera/presets`, `/photo-models`, `/filters`, `/stickers`, `/templates`
- `POST /api/v1/render/start`
- `POST /api/v1/templates/apply`
- `POST /api/v1/photo-models/apply`
- `POST /api/v1/camera/upload-recording` puis `POST /api/v1/camera/record-studio`
- `POST /api/v1/song-photo/render`
- `POST /api/v1/video/split-scenes`
- `POST /api/v1/video/estimate-views`
- `GET /api/v1/render/status/{job_id}`
- `POST /api/v1/render/cancel/{job_id}`
- `POST /api/v1/templates/generate-daily`
- `POST /api/v1/voices/clone`

## Limites conservées volontairement
- Les médias des écrans Template, Photo, Song + Photo et Split Video sont fournis sous forme d'URL. Le backend ne possède pas de route générique d'upload pour ces modules dans cette version. Utiliser l'upload média déjà présent dans l'application Base44 et transmettre son URL.
- La route `GET /api/v1/render/status/{job_id}` ne liste pas tout l'historique : le pack suit la dernière tâche envoyée et permet de la rafraîchir ou de l'annuler.
- Le statut Self-Healing est lu depuis `/api/v1/system/readiness`. Il ne permet pas de déclencher des réparations manuelles.
- Le formulaire de génération vidéo utilise les paramètres réellement présents dans `VideoRenderRequest`. Les options supplémentaires non exposées par le backend ne sont pas ajoutées artificiellement.
- Les catalogues sont rendus à partir des données de l'API, pas d'une liste statique inventée.

## Sécurité
- Ne pas mettre `GENIA_AUTH_SECRET`, les clés Google ou les clés de service dans le code frontend.
- Ne pas désactiver la validation JWT.
- Le backend actuel accepte les durées selon sa configuration serveur et le plan utilisateur. L'interface propose 3–30 secondes pour respecter le réglage produit envisagé, mais la règle d'autorisation reste côté backend.
\n\nVoir `MIGRATION_MODELES_OUVERTS.md` pour la migration locale et les limites restantes. Worker: `genia_local_worker.py`.\n
## Moteurs locaux et déploiement unique

OpenVoice V2, LatentSync 1.5 et Wan 2.2 sont exécutés par le worker local dans le même conteneur que l'API. Le worker écoute uniquement sur `127.0.0.1:8090`; seul le backend FastAPI est exposé sur le port `8080`. Les profils vocaux sont conservés dans Firestore/GCS et le backend vérifie le propriétaire avant leur utilisation.

---

## Déploiement simplifié : un seul service Cloud Run

Ce pack inclut désormais un conteneur unique qui démarre l'API Genia Apex et le worker GPU dans le même service Cloud Run. Le worker écoute uniquement sur `127.0.0.1:8090`; l'API publique écoute sur le port `8080`.

Pour le déploiement centralisé, suivre `DEPLOIEMENT_UN_SEUL_SERVICE_FR.txt` et utiliser `bash deploy_genia_one_service.sh`. Le script unique construit et déploie les deux processus dans le même service.


## Dépôt GitHub

Pour envoyer ce pack dans un dépôt GitHub sans y exposer les secrets ni les poids des modèles, suis `GITHUB_DEPOT_FR.md`. Le `.gitignore` exclut les fichiers sensibles et les checkpoints volumineux.

Le déploiement Cloud Run est configuré avec `min=0` pour limiter les frais GPU au repos. Les tâches Cloud Tasks attendent la disponibilité réelle des modèles et sont réessayées pendant le warm-up.
