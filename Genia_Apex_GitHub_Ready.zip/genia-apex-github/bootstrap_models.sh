#!/usr/bin/env bash
set -euo pipefail
MODEL_ROOT="${GENIA_MODEL_CACHE:-/opt/genia-models}"
LATENTSYNC_CKPT="${LATENTSYNC_CKPT_DIR:-$MODEL_ROOT/LatentSync/checkpoints}"
: "${GCS_BUCKET_NAME:?GCS_BUCKET_NAME is required for durable model storage}"
mkdir -p "$MODEL_ROOT" "$MODEL_ROOT/.bootstrap" /opt

cache_model() {
  local attempt=1
  while [ "$attempt" -le 3 ]; do
    if python3 /opt/genia_model_cache.py "$@"; then
      return 0
    fi
    echo "[bootstrap] échec du téléchargement/cache (tentative ${attempt}/3); nouvel essai..." >&2
    sleep $((attempt * 20))
    attempt=$((attempt + 1))
  done
  echo "[bootstrap] abandon après 3 tentatives pour le modèle : $*" >&2
  return 1
}

cache_model --repo "${WAN_MODEL_ID:-Wan-AI/Wan2.2-TI2V-5B}" \
  --destination "$MODEL_ROOT/Wan2.2-TI2V-5B" --prefix "genia-model-cache/wan2.2-ti2v-5b" \
  --allow "*.json" --allow "*.safetensors" --allow "*.pth" --allow "*.txt" --allow "*.model"
touch "$MODEL_ROOT/Wan2.2-TI2V-5B/.download_complete"

cache_model --repo "${OPENVOICE_MODEL_ID:-myshell-ai/OpenVoiceV2}" \
  --destination "$MODEL_ROOT/OpenVoiceV2" --prefix "genia-model-cache/openvoice-v2" \
  --allow "converter/**" --allow "base_speakers/**" --allow "*.json" --allow "*.pth"
mkdir -p "$MODEL_ROOT/OpenVoiceV2/checkpoints_v2"
[ ! -d "$MODEL_ROOT/OpenVoiceV2/converter" ] || cp -an "$MODEL_ROOT/OpenVoiceV2/converter" "$MODEL_ROOT/OpenVoiceV2/checkpoints_v2/" 2>/dev/null || true
[ ! -d "$MODEL_ROOT/OpenVoiceV2/base_speakers" ] || cp -an "$MODEL_ROOT/OpenVoiceV2/base_speakers" "$MODEL_ROOT/OpenVoiceV2/checkpoints_v2/" 2>/dev/null || true

cache_model --repo "${LATENTSYNC_MODEL_ID:-ByteDance/LatentSync-1.5}" \
  --destination "$LATENTSYNC_CKPT" --prefix "genia-model-cache/latentsync-1.5" \
  --allow "*.pt" --allow "*.pth" --allow "*.yaml" --allow "*.json" --allow "*.safetensors"

cache_model --repo "${QWEN_MODEL_ID:-Qwen/Qwen2.5-3B-Instruct}" \
  --destination "$MODEL_ROOT/Qwen2.5-3B-Instruct" --prefix "genia-model-cache/qwen2.5-3b-instruct" \
  --allow "*.json" --allow "*.safetensors" --allow "*.model" --allow "*.txt" --allow "tokenizer*" --allow "merges.txt" --allow "vocab.json"
touch "$MODEL_ROOT/.bootstrap/qwen.complete"

cache_model --repo "${SDXL_MODEL_ID:-stabilityai/stable-diffusion-xl-base-1.0}" \
  --destination "$MODEL_ROOT/stable-diffusion-xl-base-1.0" --prefix "genia-model-cache/sdxl-base-1.0" \
  --allow "*.json" --allow "*.safetensors" --allow "*.txt"
touch "$MODEL_ROOT/.bootstrap/sdxl.complete"

cache_model --repo "${WHISPER_MODEL_REPO:-Systran/faster-whisper-small}" \
  --destination "$MODEL_ROOT/faster-whisper-small" --prefix "genia-model-cache/faster-whisper-small" \
  --allow "*.json" --allow "*.bin" --allow "*.txt"
touch "$MODEL_ROOT/.bootstrap/whisper.complete"

cache_model --repo "${KOKORO_MODEL_ID:-hexgrad/Kokoro-82M}" \
  --destination "$MODEL_ROOT/Kokoro-82M" --prefix "genia-model-cache/kokoro-82m" \
  --allow "*.json" --allow "*.pth" --allow "voices/*.pt"
touch "$MODEL_ROOT/.bootstrap/kokoro.complete"

echo "Genia model bootstrap completed; snapshots are durable in GCS."
