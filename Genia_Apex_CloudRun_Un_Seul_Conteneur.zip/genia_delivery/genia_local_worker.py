"""Genia Apex local inference worker.
Runs open-weight models locally; no hosted inference API is called.
Models are downloaded on first use into HF_HOME / GENIA_MODEL_CACHE.
Wan2.2 official repository is installed separately by the bootstrap script.
"""
import os, uuid, json, subprocess, shutil, tempfile, time
from google.cloud import storage
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, Header, HTTPException, Request
from fastapi.responses import JSONResponse

APP=FastAPI(title="Genia Apex Local Models", version="1.0.0")
CACHE=Path(os.getenv("GENIA_MODEL_CACHE", "/opt/genia-models")); CACHE.mkdir(parents=True, exist_ok=True)
WORK=Path(os.getenv("GENIA_WORK_DIR", "/tmp/genia-local-worker")); WORK.mkdir(parents=True, exist_ok=True)
TOKEN=os.getenv("GENIA_LOCAL_AI_TOKEN", "")
GCS_BUCKET_NAME=os.getenv("GCS_BUCKET_NAME", "")
GCP_PROJECT_ID=os.getenv("GCP_PROJECT_ID", os.getenv("GOOGLE_CLOUD_PROJECT", ""))
QWEN_ID=os.getenv("QWEN_MODEL_ID", "Qwen/Qwen2.5-3B-Instruct")
KOKORO_ID=os.getenv("KOKORO_MODEL_ID", "hexgrad/Kokoro-82M")
WHISPER_ID=os.getenv("WHISPER_MODEL_ID", "small")
SDXL_ID=os.getenv("SDXL_MODEL_ID", "stabilityai/stable-diffusion-xl-base-1.0")
WAN_REPO=os.getenv("WAN_REPO_DIR", "/opt/Wan2.2")
WAN_CKPT=os.getenv("WAN_CKPT_DIR", "/opt/genia-models/Wan2.2-TI2V-5B")
OPENVOICE_REPO=os.getenv("OPENVOICE_REPO_DIR", "/opt/OpenVoice")
OPENVOICE_CKPT=os.getenv("OPENVOICE_CKPT_DIR", "/opt/genia-models/OpenVoiceV2/checkpoints_v2")
LATENTSYNC_REPO=os.getenv("LATENTSYNC_REPO_DIR", "/opt/LatentSync")
LATENTSYNC_CKPT=os.getenv("LATENTSYNC_CKPT_DIR", "/opt/genia-models/LatentSync/checkpoints")
LATENTSYNC_PYTHON=os.getenv("LATENTSYNC_PYTHON", "/opt/latentsync-venv/bin/python")

_models={}
def _auth(auth: Optional[str]):
    if not TOKEN:
        raise HTTPException(503,"GENIA_LOCAL_AI_TOKEN is not configured")
    if auth != f"Bearer {TOKEN}":
        raise HTTPException(401,"Unauthorized")
def _publish_file(path: Path, content_type: str, prefix: str="genia-local-model-output") -> dict:
    if not GCS_BUCKET_NAME:
        raise HTTPException(500, "GCS_BUCKET_NAME must be configured for shared worker outputs")
    client=storage.Client(project=GCP_PROJECT_ID or None)
    blob_name=f"{prefix}/{time.strftime('%Y/%m/%d')}/{uuid.uuid4().hex}_{path.name}"
    blob=client.bucket(GCS_BUCKET_NAME).blob(blob_name)
    blob.upload_from_filename(str(path), content_type=content_type)
    return {"gcs_uri":f"gs://{GCS_BUCKET_NAME}/{blob_name}"}

def _free(name):
    obj=_models.pop(name,None)
    del obj
    try:
        import torch, gc
        gc.collect()
        if torch.cuda.is_available(): torch.cuda.empty_cache()
    except Exception: pass

def _qwen():
    if "qwen" not in _models:
        import torch
        from transformers import AutoTokenizer, AutoModelForCausalLM
        tok=AutoTokenizer.from_pretrained(QWEN_ID, cache_dir=str(CACHE))
        model=AutoModelForCausalLM.from_pretrained(QWEN_ID, torch_dtype="auto", device_map="auto", cache_dir=str(CACHE))
        _models["qwen"]=(tok,model)
    return _models["qwen"]

@APP.get("/health")
def health():
    wan_repo=Path(WAN_REPO).exists(); wan_weights=Path(WAN_CKPT).exists()
    openvoice=(Path(OPENVOICE_REPO).exists() and Path(OPENVOICE_CKPT,"converter","checkpoint.pth").exists()
               and Path(OPENVOICE_CKPT,"base_speakers","ses","fr.pth").exists())
    latentsync=(Path(LATENTSYNC_REPO,"scripts","inference.py").exists()
                and Path(LATENTSYNC_CKPT,"latentsync_unet.pt").exists()
                and Path(LATENTSYNC_CKPT,"whisper","tiny.pt").exists())
    gcs=bool(GCS_BUCKET_NAME)
    return {"status":"ok" if wan_repo and wan_weights and openvoice and latentsync and gcs else "warming",
            "provider":"local-open-models","wan_repo_present":wan_repo,"wan_weights_present":wan_weights,
            "openvoice_present":openvoice,"latentsync_present":latentsync,"gcs_configured":gcs}

@APP.get("/health/deep")
def deep_health(authorization: Optional[str]=Header(default=None)):
    _auth(authorization)
    data=health()
    try:
        if not GCS_BUCKET_NAME: raise RuntimeError("GCS_BUCKET_NAME missing")
        blob=storage.Client(project=GCP_PROJECT_ID or None).bucket(GCS_BUCKET_NAME).blob(
            f"genia-health-check/{uuid.uuid4().hex}.txt")
        blob.upload_from_string("genia-worker-gcs-check",content_type="text/plain")
        blob.delete()
        data["gcs_access_verified"]=True
    except Exception as exc:
        data["gcs_access_verified"]=False
        data["gcs_access_error"]=str(exc)[:240]
    return data

@APP.post("/v1/chat/completions")
def chat(payload: dict, authorization: Optional[str]=Header(default=None)):
    _auth(authorization)
    tok,model=_qwen(); messages=payload.get("messages") or []
    prompt=tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    inputs=tok([prompt], return_tensors="pt").to(model.device)
    out=model.generate(**inputs, max_new_tokens=int(payload.get("max_tokens",1500)), temperature=max(.05,float(payload.get("temperature",.4))), do_sample=True)
    gen=out[0][inputs.input_ids.shape[1]:]
    content=tok.decode(gen,skip_special_tokens=True).strip()
    return {"choices":[{"message":{"role":"assistant","content":content}}],"model":QWEN_ID}

def _openvoice_components():
    if "openvoice_components" not in _models:
        import torch
        from openvoice.api import ToneColorConverter
        from melo.api import TTS
        device="cuda:0" if torch.cuda.is_available() else "cpu"
        ckpt=Path(OPENVOICE_CKPT)
        converter=ToneColorConverter(str(ckpt/"converter"/"config.json"), device=device)
        converter.load_ckpt(str(ckpt/"converter"/"checkpoint.pth"))
        # MeloTTS supplies the French linguistic/prosodic base; OpenVoice transfers
        # the consenting speaker's tone color onto that generated speech.
        base_tts=TTS(language="FR", device=device)
        source_se_path=ckpt/"base_speakers"/"ses"/"fr.pth"
        if not source_se_path.exists():
            raise RuntimeError(f"OpenVoice French base speaker embedding absent: {source_se_path}")
        source_se=torch.load(str(source_se_path), map_location=device, weights_only=False)
        _models["openvoice_components"]=(torch,converter,base_tts,source_se,device)
    return _models["openvoice_components"]

@APP.post("/v1/audio/clone")
def clone_voice(file: UploadFile=File(...), authorization: Optional[str]=Header(default=None)):
    _auth(authorization)
    if not file.filename: raise HTTPException(400,"Missing source audio filename")
    from openvoice import se_extractor
    torch,converter,_,_,device=_openvoice_components()
    raw=WORK/f"voice_source_{uuid.uuid4().hex}{Path(file.filename).suffix or '.wav'}"
    normalized=WORK/f"voice_source_norm_{uuid.uuid4().hex}.wav"
    with raw.open("wb") as f: shutil.copyfileobj(file.file,f)
    try:
        subprocess.run(["ffmpeg","-y","-i",str(raw),"-ac","1","-ar","16000","-vn",str(normalized)],check=True,capture_output=True,timeout=180)
        if normalized.stat().st_size < 2048: raise RuntimeError("Source voice audio is too short or invalid")
        target_se,_=se_extractor.get_se(str(normalized),converter, vad=True)
        emb=WORK/f"voice_embedding_{uuid.uuid4().hex}.pth"
        torch.save(target_se, str(emb))
        result=_publish_file(emb,"application/octet-stream",prefix="genia-voice-profiles")
        emb.unlink(missing_ok=True)
        return {**result,"model":"OpenVoice V2","embedding_format":"pytorch_state","device":device}
    except Exception as exc:
        raise HTTPException(422,f"OpenVoice voice enrollment failed: {str(exc)[:1200]}") from exc
    finally:
        raw.unlink(missing_ok=True); normalized.unlink(missing_ok=True)

@APP.post("/v1/audio/speech")
def speech(payload: dict, authorization: Optional[str]=Header(default=None)):
    _auth(authorization)
    text=str(payload.get("input") or "").strip()
    voice=str(payload.get("voice") or "ff_siwis")
    speed=max(.75,min(1.45,float(payload.get("speed",1.0))))
    profile_uri=str(payload.get("voice_profile_gcs_uri") or "")
    if not text: raise HTTPException(400,"Missing input text")
    output=WORK/f"speech_{uuid.uuid4().hex}.wav"
    if profile_uri:
        if not profile_uri.startswith("gs://"): raise HTTPException(400,"Invalid voice profile URI")
        try:
            import torch
            torch,converter,base_tts,source_se,device=_openvoice_components()
            parsed=profile_uri[5:].split("/",1)
            if len(parsed)!=2: raise ValueError("Malformed GCS URI")
            emb_path=WORK/f"voice_embedding_{uuid.uuid4().hex}.pth"
            storage.Client(project=GCP_PROJECT_ID or None).bucket(parsed[0]).blob(parsed[1]).download_to_filename(str(emb_path))
            target_se=torch.load(str(emb_path),map_location=device,weights_only=False)
            src=WORK/f"base_speech_{uuid.uuid4().hex}.wav"
            speaker_ids=base_tts.hps.data.spk2id
            speaker_id=speaker_ids.get("FR", next(iter(speaker_ids.values())))
            base_tts.tts_to_file(text,speaker_id,str(src),speed=speed)
            converter.convert(audio_src_path=str(src),src_se=source_se,tgt_se=target_se,output_path=str(output),message="Genia Apex OpenVoice V2")
            src.unlink(missing_ok=True); emb_path.unlink(missing_ok=True)
            if not output.exists() or output.stat().st_size<1024: raise RuntimeError("OpenVoice produced an empty file")
            published=_publish_file(output,"audio/wav")
            output.unlink(missing_ok=True)
            return {**published,"model":"OpenVoice V2 + MeloTTS FR"}
        except Exception as exc:
            raise HTTPException(500,f"OpenVoice speech synthesis failed: {str(exc)[:1200]}") from exc
    from kokoro import KPipeline
    import soundfile as sf
    key="kokoro_fr"
    if key not in _models: _models[key]=KPipeline(lang_code="f")
    pipeline=_models[key]
    chunks=[]
    for _,_,audio in pipeline(text,voice=voice,speed=speed):
        if audio is not None: chunks.append(audio)
    if not chunks: raise HTTPException(500,"Kokoro returned no audio")
    import numpy as np
    sf.write(str(output),np.concatenate(chunks),24000)
    published=_publish_file(output,"audio/wav")
    output.unlink(missing_ok=True)
    return {**published,"model":KOKORO_ID}

@APP.post("/v1/audio/transcriptions")
def transcription(file: UploadFile=File(...), language: str=Form("fr"), word_timestamps: str=Form("true"), authorization: Optional[str]=Header(default=None)):
    _auth(authorization)
    from faster_whisper import WhisperModel
    key="whisper"
    if key not in _models:
        device="cuda" if __import__("torch").cuda.is_available() else "cpu"
        _models[key]=WhisperModel(WHISPER_ID, device=device, compute_type="float16" if device=="cuda" else "int8", download_root=str(CACHE))
    raw=WORK/f"audio_{uuid.uuid4().hex}{Path(file.filename or 'audio.wav').suffix}"
    with raw.open("wb") as f: shutil.copyfileobj(file.file,f)
    segs,info=_models[key].transcribe(str(raw), language=language, word_timestamps=(word_timestamps.lower()=="true"), vad_filter=True)
    out=[]; text=[]
    for seg in segs:
        words=[]
        for w in (seg.words or []): words.append({"start":w.start,"end":w.end,"word":w.word})
        out.append({"start":seg.start,"end":seg.end,"text":seg.text,"words":words}); text.append(seg.text)
    raw.unlink(missing_ok=True)
    return {"text":" ".join(text).strip(),"segments":out,"language":info.language,"model":WHISPER_ID}

@APP.post("/v1/images/generations")
def image_generation(payload: dict, authorization: Optional[str]=Header(default=None)):
    _auth(authorization)
    import torch
    from diffusers import StableDiffusionXLPipeline
    key="sdxl"
    if key not in _models:
        pipe=StableDiffusionXLPipeline.from_pretrained(SDXL_ID, torch_dtype=torch.float16, use_safetensors=True, cache_dir=str(CACHE))
        pipe.enable_model_cpu_offload(); _models[key]=pipe
    pipe=_models[key]
    result=pipe(str(payload["prompt"]),width=int(payload.get("width",768)),height=int(payload.get("height",1024)),num_inference_steps=25).images[0]
    out=WORK/f"image_{uuid.uuid4().hex}.png"; result.save(out)
    published=_publish_file(out, "image/png")
    out.unlink(missing_ok=True)
    return {**published,"model":SDXL_ID}

@APP.post("/v1/images/edits")
def image_edit(prompt: str=Form(...), strength: float=Form(.35), image: UploadFile=File(...), authorization: Optional[str]=Header(default=None)):
    _auth(authorization)
    import torch
    from diffusers import StableDiffusionXLImg2ImgPipeline
    from PIL import Image
    key="sdxl_img2img"
    if key not in _models:
        pipe=StableDiffusionXLImg2ImgPipeline.from_pretrained(SDXL_ID, torch_dtype=torch.float16, use_safetensors=True, cache_dir=str(CACHE))
        pipe.enable_model_cpu_offload(); _models[key]=pipe
    raw=WORK/f"input_{uuid.uuid4().hex}.png"
    with raw.open("wb") as f: shutil.copyfileobj(image.file,f)
    with Image.open(raw) as im: source=im.convert("RGB").resize((768,1024))
    result=_models[key](prompt=prompt,image=source,strength=max(.1,min(.8,float(strength))),num_inference_steps=25).images[0]
    out=WORK/f"edit_{uuid.uuid4().hex}.png"; result.save(out); raw.unlink(missing_ok=True)
    published=_publish_file(out, "image/png")
    out.unlink(missing_ok=True)
    return {**published,"model":SDXL_ID}

@APP.post("/v1/artifacts/delete")
def delete_temporary_artifact(payload: dict, authorization: Optional[str]=Header(default=None)):
    _auth(authorization)
    uri=str(payload.get("gcs_uri") or "")
    if not uri.startswith(f"gs://{GCS_BUCKET_NAME}/genia-local-model-output/"):
        raise HTTPException(400,"Only temporary Genia worker artifacts can be deleted")
    blob_name=uri.split(f"gs://{GCS_BUCKET_NAME}/",1)[1]
    storage.Client(project=GCP_PROJECT_ID or None).bucket(GCS_BUCKET_NAME).blob(blob_name).delete()
    return {"deleted":True}

@APP.post("/v1/videos/lipsync")
async def video_lipsync(video: UploadFile=File(...), audio: UploadFile=File(...),
                        inference_steps: int=Form(20), guidance_scale: float=Form(1.5),
                        authorization: Optional[str]=Header(default=None)):
    _auth(authorization)
    repo=Path(LATENTSYNC_REPO); ckpt=Path(LATENTSYNC_CKPT)
    if not (repo/"scripts"/"inference.py").exists() or not (ckpt/"latentsync_unet.pt").exists() or not Path(LATENTSYNC_PYTHON).exists():
        raise HTTPException(503,"LatentSync 1.5 is not installed; run the GPU worker bootstrap")
    raw_video=WORK/f"lipsync_in_{uuid.uuid4().hex}.mp4"
    raw_audio=WORK/f"lipsync_audio_{uuid.uuid4().hex}.wav"
    norm_audio=WORK/f"lipsync_audio_norm_{uuid.uuid4().hex}.wav"
    norm_video=WORK/f"lipsync_video_norm_{uuid.uuid4().hex}.mp4"
    output=WORK/f"lipsync_out_{uuid.uuid4().hex}.mp4"
    muxed=WORK/f"lipsync_mux_{uuid.uuid4().hex}.mp4"
    try:
        with raw_video.open("wb") as f: shutil.copyfileobj(video.file,f)
        with raw_audio.open("wb") as f: shutil.copyfileobj(audio.file,f)
        subprocess.run(["ffmpeg","-y","-i",str(raw_audio),"-ac","1","-ar","16000","-vn",str(norm_audio)],check=True,capture_output=True,timeout=180)
        # LatentSync's published preprocessing expects 25 fps and a separate audio track.
        subprocess.run(["ffmpeg","-y","-i",str(raw_video),"-an","-vf","fps=25","-c:v","libx264","-preset","veryfast","-crf","20",str(norm_video)],check=True,capture_output=True,timeout=240)
        # Release cached local models before the diffusion lip-sync pass on a 24 GB L4.
        _free("qwen"); _free("sdxl"); _free("sdxl_img2img"); _free("openvoice_components"); _free("whisper"); _free("kokoro_fr")
        cmd=[LATENTSYNC_PYTHON, "-m", "scripts.inference",
             "--unet_config_path", "configs/unet/stage2.yaml",
             "--inference_ckpt_path", str(ckpt/"latentsync_unet.pt"),
             "--inference_steps", str(max(20,min(50,int(inference_steps)))),
             "--guidance_scale", str(max(1.0,min(3.0,float(guidance_scale)))),
             "--video_path", str(norm_video), "--audio_path", str(norm_audio),
             "--video_out_path", str(output)]
        proc=subprocess.run(cmd,cwd=str(repo),capture_output=True,text=True,timeout=2400)
        if proc.returncode or not output.exists() or output.stat().st_size<2048:
            raise RuntimeError((proc.stderr or proc.stdout)[-4000:] or "LatentSync returned no output")
        # Ensure the final output uses the requested voice audio, not a stale source track.
        subprocess.run(["ffmpeg","-y","-i",str(output),"-i",str(raw_audio),"-map","0:v:0","-map","1:a:0","-c:v","copy","-c:a","aac","-b:a","160k","-shortest","-movflags","+faststart",str(muxed)],check=True,capture_output=True,timeout=240)
        return {**_publish_file(muxed,"video/mp4"),"model":"LatentSync 1.5","inference_steps":max(20,min(50,int(inference_steps)))}
    except Exception as exc:
        raise HTTPException(500,f"LatentSync failed: {str(exc)[:1600]}") from exc
    finally:
        for item in (raw_video,raw_audio,norm_audio,norm_video,output,muxed): item.unlink(missing_ok=True)

@APP.post("/v1/videos/generations")
async def video_generation(request: Request, authorization: Optional[str]=Header(default=None)):
    _auth(authorization)
    ctype = request.headers.get("content-type", "")
    if "multipart/form-data" in ctype:
        form = await request.form()
        prompt = str(form.get("prompt") or "")
        duration_seconds = int(form.get("duration_seconds") or 8)
        aspect_ratio = str(form.get("aspect_ratio") or "9:16")
        job_id = str(form.get("job_id") or "")
        image = form.get("image")
    else:
        payload = await request.json()
        prompt = str(payload.get("prompt") or "")
        duration_seconds = int(payload.get("duration_seconds") or 8)
        aspect_ratio = str(payload.get("aspect_ratio") or "9:16")
        job_id = str(payload.get("job_id") or "")
        image = None
    if not prompt.strip(): raise HTTPException(400, "Missing prompt")
    if not Path(WAN_REPO,"generate.py").exists() or not Path(WAN_CKPT).exists():
        raise HTTPException(503,"Wan 2.2 not installed; run the supplied Google Cloud bootstrap deployment")
    duration=max(3,min(8,int(duration_seconds)))
    # Wan expects frame_num = 4n + 1. Keep the generated scene duration close to the request.
    frame_num=max(49,min(193,(duration*24//4)*4+1))
    # TI2V-5B's published 720p presets are portrait 704x1280 and landscape 1280x704.
    # Square outputs are cropped by the main FFmpeg composition after generation.
    width,height=(1280,704) if aspect_ratio=="16:9" else (704,1280)
    out=WORK/f"wan_{uuid.uuid4().hex}.mp4"
    _free("qwen"); _free("sdxl"); _free("sdxl_img2img"); _free("openvoice_components"); _free("whisper"); _free("kokoro_fr")
    cmd=["python",str(Path(WAN_REPO)/"generate.py"),"--task","ti2v-5B","--size",f"{width}*{height}","--frame_num",str(frame_num),"--ckpt_dir",WAN_CKPT,"--offload_model","True","--convert_model_dtype","--t5_cpu","--prompt",prompt,"--save_file",str(out)]
    if image is not None:
        ref=WORK/f"ref_{uuid.uuid4().hex}{Path(image.filename or 'ref.png').suffix}"
        with ref.open("wb") as f: shutil.copyfileobj(image.file,f)
        cmd.extend(["--image",str(ref)])
    proc=subprocess.run(cmd,capture_output=True,text=True,timeout=1500)
    if proc.returncode or not out.exists() or out.stat().st_size<1024:
        raise HTTPException(500,"Wan generation failed: "+(proc.stderr or proc.stdout)[-3000:])
    result={**_publish_file(out, "video/mp4"),"model":"Wan2.2-TI2V-5B","duration_requested":duration,"frame_num":frame_num}
    out.unlink(missing_ok=True)
    if image is not None:
        ref.unlink(missing_ok=True)
    return result
