#!/usr/bin/env bash
set -euo pipefail

MODEL_ROOT="${GENIA_MODEL_CACHE:-/opt/genia-models}"
LATENTSYNC_CKPT="${LATENTSYNC_CKPT_DIR:-$MODEL_ROOT/LatentSync/checkpoints}"
mkdir -p "$MODEL_ROOT" /opt

# Wan 2.2 TI2V-5B
if [ ! -f "$MODEL_ROOT/Wan2.2-TI2V-5B/.download_complete" ]; then
  python3 - <<'PY'
from huggingface_hub import snapshot_download
snapshot_download(repo_id="Wan-AI/Wan2.2-TI2V-5B", local_dir="/opt/genia-models/Wan2.2-TI2V-5B")
PY
  touch "$MODEL_ROOT/Wan2.2-TI2V-5B/.download_complete"
fi

# OpenVoice V2 + MeloTTS French base speaker. Voice embeddings are stored in GCS per user.
if [ ! -d /opt/OpenVoice ]; then git clone --depth 1 https://github.com/myshell-ai/OpenVoice.git /opt/OpenVoice; fi
python3 - <<'PY'
from huggingface_hub import snapshot_download
snapshot_download(repo_id="myshell-ai/OpenVoiceV2", local_dir="/opt/genia-models/OpenVoiceV2")
PY
mkdir -p /opt/genia-models/OpenVoiceV2/checkpoints_v2
# HF repository files are copied into the layout expected by the official OpenVoice V2 API.
if [ -d /opt/genia-models/OpenVoiceV2/converter ]; then
  cp -an /opt/genia-models/OpenVoiceV2/converter /opt/genia-models/OpenVoiceV2/checkpoints_v2/ 2>/dev/null || true
fi
if [ -d /opt/genia-models/OpenVoiceV2/base_speakers ]; then
  cp -an /opt/genia-models/OpenVoiceV2/base_speakers /opt/genia-models/OpenVoiceV2/checkpoints_v2/ 2>/dev/null || true
fi

# LatentSync is isolated in its own venv because its pinned dependency set conflicts
# with the Wan/Qwen/Kokoro runtime used by the API worker.
if [ ! -d /opt/LatentSync ]; then git clone --depth 1 https://github.com/bytedance/LatentSync.git /opt/LatentSync; fi
if [ ! -x /opt/latentsync-venv/bin/python ]; then python3 -m venv /opt/latentsync-venv; fi
mkdir -p "$LATENTSYNC_CKPT"
LATENTSYNC_CKPT="$LATENTSYNC_CKPT" /opt/latentsync-venv/bin/python - <<'PY'
import os
from huggingface_hub import snapshot_download
snapshot_download(repo_id="ByteDance/LatentSync-1.5", local_dir=os.environ["LATENTSYNC_CKPT"])
PY

# Qwen, Kokoro, Whisper and SDXL remain lazily cached on first request.
echo "Genia model bootstrap completed."
