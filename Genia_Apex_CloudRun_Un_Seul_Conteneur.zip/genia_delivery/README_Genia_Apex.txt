GENIA APEX — BACKEND GOOGLE CLOUD / BASE44

Fichiers :
- Genia_Apex_GoogleCloud_Base44.py : backend FastAPI et moteurs Google Cloud.
- requirements_Genia_Apex.txt : dépendances Python.
- CONFIGURATION_GENIA_BASE44_GOOGLE_CLOUD.md : configuration Google Cloud et intégration Base44.

Moteurs ajoutés/renforcés : Gemini Omni 1.2 Flash (audio/vidéo natifs synchronisés), Gemini 3.8 Flash (analyse vidéo agentique et score éditorial), Gemini 3.8 Live Avatar (avatar + voix personnalisés, accès Google restreint).

Architecture : Base44 = SaaS / frontend ; Google Cloud = IA, stockage, données et exécution. Aucun fournisseur IA tiers n'est ajouté.

IMPORTANT : ENABLE_GEMINI_LIVE_AVATAR reste false tant que Google n'a pas autorisé le projet pour les avatars et voix personnalisés. Les scores éditoriaux ne prédisent pas les vues. Une validation de bout en bout exige les identifiants, quotas, autorisations et API activées du projet Google Cloud.

Lire le guide avant déploiement.


CORRECTIONS DE CETTE VERSION
- Synchronisation audio/vidéo native : Gemini Omni 1.2 Flash via `lip_sync_mode=native_omni`; Gemini 3.8 Live Avatar pour avatar + voix personnalisés lorsque Google a autorisé le projet. Le mode auto conserve les presets vocaux existants par défaut.
- Cohérence de l'avatar : image de référence unique réutilisée entre scènes; statut explicite, sans promesse d'identité parfaite.
- Score : score éditorial Gemini 3.8 uniquement; aucune estimation de vues fabriquée. Sans données analytics connectées, les champs de vues restent null.
- Découpage : Gemini 3.8 Flash analyse les moments; les segments de secours sont marqués comme détection de scène/distribution et ne reçoivent pas de score fictif.

VÉRIFICATIONS LOCALES
- Compilation syntaxique Python et analyse AST.
- Vérification des routes et des doublons de chemins.
- Tests FFmpeg de remux MP4 fragmenté, overlay, audio natif et mixage BGM.
- Aucun test de bout en bout Google Cloud n'a été possible dans l'environnement de préparation : les identifiants, quotas et autorisations du projet de production sont nécessaires.

MODULE AUTO-DIAGNOSTIC & SELF-HEALING
------------------------------------
Le moteur comprend ApexSelfHealingEngine, appelé automatiquement par ApexResilienceGuard.
Il classe les erreurs, journalise le diagnostic et relance uniquement les erreurs reconnues
comme transitoires (avec temporisation exponentielle et nombre de tentatives plafonné).
Les erreurs d'autorisation, de quota, de facturation ou de données invalides sont signalées
sans modification risquée. Des réparations spécifiques peuvent être ajoutées par le développeur
avec register_repair(), puis sont vérifiées par une nouvelle exécution de l'opération.
Aucune réparation arbitraire du code, des modèles, des données ou des paramètres cloud n'est faite.
L'état et les compteurs sont exposés dans /api/v1/system/readiness.
