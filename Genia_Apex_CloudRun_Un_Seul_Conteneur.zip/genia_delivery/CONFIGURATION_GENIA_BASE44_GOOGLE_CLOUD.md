# Configuration Genia Apex — Base44 + backend Cloud Run + worker GPU

> Cette configuration remplace les anciennes instructions Gemini/Vertex de ce fichier. Les chemins Gemini Live, Omni, Voice Replication, Veo et Gemini Video Analysis sont désactivés dans la version locale livrée.

## Architecture

- **Base44** : comptes, session utilisateur, crédits et interface existante.
- **Backend FastAPI Cloud Run** : authentification JWT Base44, règles de crédits, Firestore, Cloud Tasks, GCS, composition FFmpeg et orchestration des moteurs.
- **Worker GPU local dans le même conteneur Cloud Run** : Wan 2.2 TI2V-5B, Qwen2.5-3B-Instruct, Kokoro, OpenVoice V2 + MeloTTS FR, faster-whisper, SDXL et LatentSync 1.5. Il écoute uniquement sur `127.0.0.1:8090`.
- **GCS** : médias générés, sorties temporaires et empreintes vocales privées.
- **Firestore** : jobs, portefeuilles, modèles et profils vocaux avec contrôle du propriétaire.

## API Google à activer

Activer au minimum :
- Cloud Run API
- Cloud Build API
- Artifact Registry API
- Secret Manager API
- Cloud Firestore API
- Cloud Storage API
- Cloud Tasks API

Vertex AI, Gemini, Cloud Text-to-Speech et Cloud Speech-to-Text ne sont pas requis par les chemins de génération locaux de cette version.

## Variables du backend Cloud Run

- `GENIA_AUTH_SECRET` : secret JWT HS256 partagé avec la fonction serveur Base44.
- `GENIA_JWT_ISSUER=base44`
- `GENIA_JWT_AUDIENCE=genia-apex`
- `GCP_PROJECT_ID` : identifiant du projet.
- `GCP_LOCATION` : région Google Cloud.
- `GCS_BUCKET_NAME` : bucket privé des médias et profils vocaux.
- `GENIA_LOCAL_AI_URL` : `http://127.0.0.1:8090` (worker interne au même conteneur).
- `GENIA_LOCAL_AI_TOKEN` : jeton interne généré au démarrage du conteneur et partagé entre les deux processus.
- `GENIA_LOCAL_AI_TIMEOUT=3600`
- `MAX_CONCURRENT_RENDERS=1` pour une seule instance GPU L4.
- `CLOUD_TASKS_SERVICE_URL`, `CLOUD_TASKS_SERVICE_ACCOUNT`, `CLOUD_TASKS_QUEUE`, `CLOUD_TASKS_LOCATION` selon la file de rendu existante.
- `CORS_ALLOWED_ORIGINS` : origine exacte de l'application Base44 publiée.

Le backend doit avoir accès en lecture au bucket GCS (`roles/storage.objectViewer`) pour récupérer les sorties temporaires du worker. Le worker doit avoir accès en écriture/suppression (`roles/storage.objectAdmin`) au bucket pour publier les sorties et gérer les fichiers temporaires.

## Déploiement unique Cloud Run

Dans `genia_delivery`, lancer `bash deploy_genia_one_service.sh`. Le script prépare les APIs, le bucket GCS, Firestore, le compte de service, Artifact Registry, Secret Manager et Cloud Tasks; il construit ensuite le `Dockerfile` unique et déploie un seul service Cloud Run GPU L4. Il configure le worker local sur `127.0.0.1:8090` et l'API publique sur le port `8080`.

Le script exige un quota GPU L4 disponible et un quota de disque éphémère suffisant pour le cache de 50 Gio. Le quota de disque par instance est de 10 Gio par défaut; il peut être nécessaire de demander son augmentation dans Google Cloud avant le déploiement.

## Base44

Conserver l'application Base44 existante. Les fichiers `GeniaApexStudio.tsx`, `geniaApexApi.ts`, `Base44GeniaApexPage.tsx` et la fonction serveur `genia-apex-token` restent les composants de raccordement. Ne jamais placer `GENIA_AUTH_SECRET` ou `GENIA_LOCAL_AI_TOKEN` dans le navigateur.

La fonction serveur Base44 doit continuer à émettre un JWT signé depuis l'identité réelle de la session. Le navigateur ne doit jamais fournir lui-même le `user_id` à signer.

## Fonctionnement des trois raccordements demandés

### Clonage vocal

`POST /api/v1/voices/clone` reçoit un échantillon vocal et un fichier de consentement. Le backend appelle `/v1/audio/clone`; OpenVoice V2 crée une empreinte vocale qui est conservée dans GCS sous `genia-voice-profiles/`. Firestore conserve le propriétaire, le nom du profil et l'URI. Lors d'une synthèse, le backend vérifie l'appartenance du profil avant de transmettre l'URI au worker. Les fichiers audio source et de consentement ne sont pas conservés par cette route.

### Avatar et synchronisation labiale

Le backend produit l'audio local, génère une scène Wan avec une image de référence, puis envoie la vidéo et la piste audio à `/v1/videos/lipsync`. LatentSync 1.5 traite une vidéo existante; le worker remuxe la piste audio d'origine et publie le MP4 dans GCS. Un échec du moteur interrompt le rendu au lieu de déclarer une synchronisation réussie.

La synchronisation labiale suppose un visage visible et suffisamment net. Elle ne garantit pas une identité parfaite ni des gestes corporels humains réalistes.

### Analyse et sélection de clips

Qwen local donne un score éditorial sur le texte; il ne prédit pas le nombre de vues. La sélection de passages s'appuie sur les segments horodatés par faster-whisper et Qwen. L'analyse visuelle multimodale complète n'est pas incluse dans cette migration.

## Coûts

Les modèles à poids ouverts ne facturent pas de frais par génération via un fournisseur d'inférence hébergé. Google Cloud facture cependant le GPU L4, les CPU, la mémoire, le stockage, les requêtes GCS, le réseau et les autres ressources. Le script déploie `--min 1` afin de garder les poids chargés : le GPU reste facturé même lorsqu'il n'y a aucun rendu. Le cache de 50 Gio est un disque éphémère; si l'instance est remplacée, les modèles doivent être téléchargés à nouveau. Réduire ou supprimer l'instance diminue les coûts mais entraîne un rechargement des modèles au prochain démarrage.

## Licences et tests

- OpenVoice V2 : MIT selon le dépôt officiel.
- LatentSync : code Apache-2.0; poids publiés sous OpenRAIL++ avec conditions à examiner avant commercialisation.
- Wan 2.2 TI2V-5B : Apache-2.0 selon le dépôt officiel.
- SDXL : vérifier les conditions Stability AI applicables.

Les scripts Python et shell ont été vérifiés syntaxiquement. Le build Docker, le téléchargement des poids, les rendus GPU, le clonage vocal, la synchronisation sur de vrais visages et le déploiement dans le compte du propriétaire restent à tester sur Google Cloud. La syntaxe valide ne constitue pas une certification de production.
