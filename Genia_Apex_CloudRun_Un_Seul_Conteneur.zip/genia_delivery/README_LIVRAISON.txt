GENIA APEX — PACK DE DÉPLOIEMENT CENTRALISÉ

Le pack contient un conteneur Cloud Run unique :
- API Genia Apex sur le port public 8080;
- worker GPU local sur 127.0.0.1:8090, non exposé sur Internet;
- Wan 2.2, OpenVoice V2, LatentSync 1.5, Qwen, Kokoro, faster-whisper et SDXL;
- Firestore, Cloud Storage et Cloud Tasks;
- cache des poids sur un disque éphémère Cloud Run.

FICHIERS PRINCIPAUX :
- Dockerfile : construction du conteneur unique API + worker GPU;
- start_genia_one_service.sh : démarrage des deux processus;
- deploy_genia_one_service.sh : préparation Google Cloud, build et déploiement du service unique;
- Genia_Apex_GoogleCloud_Base44.py : backend principal;
- genia_local_worker.py : moteur local des modèles;
- bootstrap_models.sh : téléchargement initial des poids;
- DEPLOIEMENT_UN_SEUL_SERVICE_FR.txt : procédure de déploiement.

DÉPLOIEMENT :
Dans Google Cloud Shell, décompresser le pack, entrer dans le dossier genia_delivery puis lancer :
bash deploy_genia_one_service.sh

Le script guide la configuration et déploie un seul service Cloud Run. Il affiche à la fin l'URL de l'API et le secret JWT à copier dans les secrets serveur Base44.

PRÉREQUIS ET LIMITES :
- Facturation Google Cloud active, quota GPU NVIDIA L4 disponible.
- Le disque éphémère Cloud Run est configuré à 50 Gio. Le quota par instance est de 10 Gio par défaut; une augmentation peut être nécessaire.
- Le bucket GCS est créé s'il n'existe pas; Firestore par défaut est créé s'il n'existe pas.
- Les modèles sont téléchargés au premier démarrage; cela peut prendre du temps.
- Une instance GPU minimale est maintenue active et reste facturée même sans génération.
- Le cache modèle est éphémère et sera retéléchargé si l'instance est remplacée.
- Le script ne publie pas les modifications dans Base44. Il faut renseigner GENIA_AUTH_SECRET et GENIA_APEX_API_URL dans les secrets/paramètres serveur Base44.
- Les scripts Python et shell ont été vérifiés syntaxiquement; le build Docker et les inférences GPU n'ont pas été exécutés dans le compte Google Cloud du propriétaire.
